@echo off
setlocal
title RUS Config Donetsk update
cd /d "%~dp0"
echo RUS Config Donetsk update
echo.
echo A progress window should appear. Do not close this window.
echo If the update fails, this window will stay open and show update.log.
echo.
set "request=%~dp0update-request.json"
if not "%~1"=="" set "request=%~1"
echo Request: %request%
echo.
set "RCD_UPDATE_REQUEST=%request%"
set "RCD_UPDATE_APPROOT=%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $request=$env:RCD_UPDATE_REQUEST; $appRoot=$env:RCD_UPDATE_APPROOT.TrimEnd('\'); $data=[ordered]@{}; if (Test-Path -LiteralPath $request) { try { $json=Get-Content -LiteralPath $request -Raw | ConvertFrom-Json; foreach ($property in $json.PSObject.Properties) { $data[$property.Name]=$property.Value } } catch {} }; $data['AppRoot']=$appRoot; $data['ExePath']=(Join-Path $appRoot 'RUS Config Donetsk.exe'); if (-not $data.Contains('CallerProcessId')) { $data['CallerProcessId']=0 }; [System.IO.File]::WriteAllText($request, (($data | ConvertTo-Json -Depth 5) + [Environment]::NewLine), [System.Text.UTF8Encoding]::new($false))"
if not "%ERRORLEVEL%"=="0" (
  echo Could not refresh update-request.json.
  pause
  exit /b %ERRORLEVEL%
)
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0rus-config-donetsk-updater.ps1" -RequestFile "%request%"
set "code=%ERRORLEVEL%"
if not "%code%"=="0" (
  echo.
  echo Update failed with code %code%.
  echo.
  if exist "%~dp0update.log" (
    type "%~dp0update.log"
  ) else (
    echo update.log was not created.
  )
  echo.
  pause
)
exit /b %code%
