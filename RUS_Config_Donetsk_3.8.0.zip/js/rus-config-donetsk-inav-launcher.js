(function () {
    'use strict';

    const CONFIGURATORS = {
        7: {
            version: 7,
            label: 'INAV Configurator v7',
            bundledExe: 'INAV\\7\\inav-configurator.exe',
            fallbackExes: [
                'D:\\Конфигуратор для Молнии\\INAV-Configurator v 7\\inav-configurator.exe',
            ],
        },
        8: {
            version: 8,
            label: 'INAV Configurator v8',
            bundledExe: 'INAV\\8\\inav-configurator.exe',
            fallbackExes: [
                'D:\\Конфигуратор для Молнии\\Inav 8\\inav-configurator.exe',
            ],
        },
        9: {
            version: 9,
            label: 'INAV Configurator v9',
            bundledExe: 'INAV\\9\\inav-configurator.exe',
            fallbackExes: [
                'D:\\Конфигуратор для Молнии\\inav-configurator v 9.0.1\\app-9.0.2\\inav-configurator.exe',
            ],
        },
    };

    const state = {
        lastAutoLaunchKey: '',
        lastAutoLaunchAt: 0,
    };

    function getRequire() {
        if (typeof nw !== 'undefined' && nw.require) {
            return nw.require.bind(nw);
        }

        if (typeof window !== 'undefined' && window.nw && window.nw.require) {
            return window.nw.require.bind(window.nw);
        }

        if (typeof require === 'function') {
            return require;
        }

        return null;
    }

    function getPathModule() {
        const nodeRequire = getRequire();
        return nodeRequire ? nodeRequire('path') : null;
    }

    function getAppRoot() {
        const path = getPathModule();

        if (!path) {
            return '';
        }

        try {
            if (typeof process !== 'undefined' && process.execPath) {
                return path.dirname(process.execPath);
            }
        } catch (error) {
        }

        try {
            if (typeof process !== 'undefined' && typeof process.cwd === 'function') {
                return process.cwd();
            }
        } catch (error) {
        }

        return '';
    }

    function normalizeIdentifier(identifier) {
        return String(identifier || '').trim().toUpperCase();
    }

    function isInavIdentifier(identifier) {
        return normalizeIdentifier(identifier) === 'INAV';
    }

    function getFirmwareMajor(firmwareVersion) {
        const match = String(firmwareVersion || '').match(/^(\d+)/);
        return match ? Number(match[1]) : 0;
    }

    function getConfiguratorForFirmware(firmwareVersion) {
        const major = getFirmwareMajor(firmwareVersion);

        if (major === 7) {
            return CONFIGURATORS[7];
        }

        if (major === 8) {
            return CONFIGURATORS[8];
        }

        if (major >= 9) {
            return CONFIGURATORS[9];
        }

        return null;
    }

    function getConfigurator(version) {
        return CONFIGURATORS[Number(version)] || null;
    }

    function fileExists(filePath) {
        try {
            const nodeRequire = getRequire();
            return Boolean(nodeRequire && nodeRequire('fs').existsSync(filePath));
        } catch (error) {
            console.warn('[RUS Config INAV] Не удалось проверить файл:', error);
            return false;
        }
    }

    function getExeCandidates(configurator) {
        const path = getPathModule();
        const appRoot = getAppRoot();
        const candidates = [];

        if (configurator && configurator.bundledExe && path && appRoot) {
            candidates.push(path.join(appRoot, configurator.bundledExe));
        }

        if (configurator && configurator.exe) {
            candidates.push(configurator.exe);
        }

        (configurator && configurator.fallbackExes ? configurator.fallbackExes : []).forEach(function (exe) {
            candidates.push(exe);
        });

        return candidates.filter(function (exe, index) {
            return exe && candidates.indexOf(exe) === index;
        });
    }

    function resolveConfiguratorExe(configurator) {
        const candidates = getExeCandidates(configurator);

        for (let index = 0; index < candidates.length; index += 1) {
            if (fileExists(candidates[index])) {
                return candidates[index];
            }
        }

        return '';
    }

    function showDialog(title, html) {
        const body = `<strong>${title}</strong><br>${html}`;
        const dialog = document.querySelector('.dialogConnectWarning');
        const content = document.querySelector('.dialogConnectWarning-content');
        const closeButton = document.querySelector('.dialogConnectWarning-closebtn');

        if (dialog && content) {
            content.innerHTML = body;

            if (closeButton) {
                closeButton.onclick = function (event) {
                    event.preventDefault();
                    dialog.close();
                };
            }

            if (!dialog.open) {
                dialog.showModal();
            }

            return;
        }

        console.log(`[RUS Config INAV] ${title}: ${html.replace(/<[^>]+>/g, ' ')}`);
    }

    function closeStarterConfigurator() {
        window.setTimeout(function () {
            try {
                if (typeof nw !== 'undefined' && nw.App && typeof nw.App.quit === 'function') {
                    nw.App.quit();
                    return;
                }

                if (typeof window !== 'undefined' && window.nw && window.nw.App && typeof window.nw.App.quit === 'function') {
                    window.nw.App.quit();
                    return;
                }

                window.close();
            } catch (error) {
                console.warn('[RUS Config INAV] Не удалось закрыть RUS Config:', error);
            }
        }, 700);
    }

    function launch(configurator, options) {
        const launchOptions = options || {};
        const delayMs = Number.isFinite(launchOptions.delayMs) ? launchOptions.delayMs : 0;
        const shouldCloseStarter = launchOptions.closeStarter !== false;

        if (!configurator) {
            showDialog(
                'INAV не запущен',
                'Не удалось подобрать конфигуратор под эту версию прошивки. Откройте нужную версию вручную.'
            );
            return false;
        }

        const exePath = resolveConfiguratorExe(configurator);

        if (!exePath) {
            const candidates = getExeCandidates(configurator)
                .map(function (candidate) { return `<code>${candidate}</code>`; })
                .join('<br>');

            showDialog(
                'INAV не запущен',
                `Файл не найден. Проверенные пути:<br>${candidates}`
            );
            return false;
        }

        window.setTimeout(function () {
            try {
                const nodeRequire = getRequire();
                const path = getPathModule();
                const childProcess = nodeRequire('child_process');
                const cwd = path ? path.dirname(exePath) : undefined;
                const child = childProcess.spawn(exePath, [], {
                    cwd,
                    detached: true,
                    stdio: 'ignore',
                    windowsHide: false,
                });

                child.unref();
                console.log(`[RUS Config INAV] Запущен ${configurator.label}: ${exePath}`);

                if (shouldCloseStarter) {
                    closeStarterConfigurator();
                }
            } catch (error) {
                console.error('[RUS Config INAV] Ошибка запуска:', error);
                showDialog('INAV не запущен', `Ошибка запуска: ${String(error.message || error)}`);
            }
        }, Math.max(0, delayMs));

        return true;
    }

    function handleDetectedFirmware(info) {
        const firmwareInfo = info || {};

        if (!isInavIdentifier(firmwareInfo.identifier)) {
            return false;
        }

        const version = String(firmwareInfo.firmwareVersion || '').trim();
        const configurator = getConfiguratorForFirmware(version);
        const key = `${firmwareInfo.identifier}:${version}:${firmwareInfo.port || ''}`;
        const now = Date.now();

        if (state.lastAutoLaunchKey === key && now - state.lastAutoLaunchAt < 10000) {
            return true;
        }

        state.lastAutoLaunchKey = key;
        state.lastAutoLaunchAt = now;

        if (!configurator) {
            showDialog(
                'Обнаружена прошивка INAV',
                `Версия прошивки: <strong>${version || 'не определена'}</strong>.<br>` +
                'Для этой версии не задан конфигуратор. Используйте кнопки INAV на стартовой странице.'
            );
            return true;
        }

        showDialog(
            'Обнаружена прошивка INAV',
            `Прошивка: <strong>${version || 'не определена'}</strong>.<br>` +
            `Запускаю <strong>${configurator.label}</strong> и закрываю стартовый конфигуратор.`
        );

        launch(configurator, { delayMs: 1200, closeStarter: true });
        return true;
    }

    function injectStyles() {
        if (document.getElementById('rus-config-donetsk-inav-launcher-style')) {
            return;
        }

        const style = document.createElement('style');
        style.id = 'rus-config-donetsk-inav-launcher-style';
        style.textContent = `
.rus-inav-launcher {
  box-sizing: border-box;
  grid-column: 1 / -1;
  width: 100%;
  margin: 14px 0 0;
  border: 1px solid rgba(255, 191, 0, 0.52);
  border-radius: 6px;
  background: #252927;
  color: #f4f4f4;
  padding: 14px;
}
.rus-inav-launcher__title {
  color: #ffbf00;
  font-size: 15px;
  font-weight: 900;
  margin-bottom: 6px;
}
.rus-inav-launcher__text {
  color: #e9e2d2;
  font-size: 12px;
  line-height: 1.45;
  margin-bottom: 12px;
}
.rus-inav-launcher__buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
.rus-inav-launcher__button {
  min-height: 34px;
  border: 1px solid rgba(255, 191, 0, 0.86);
  border-radius: 5px;
  background: #ffbf00;
  color: #151515;
  cursor: pointer;
  font-size: 13px;
  font-weight: 900;
  padding: 0 12px;
}
.rus-inav-launcher__button.secondary {
  background: #303532;
  color: #ffbf00;
}
`;
        document.head.appendChild(style);
    }

    function injectLandingPanel() {
        const landing = document.querySelector('.tab-landing .content_mid');

        if (!landing || landing.querySelector('.rus-inav-launcher')) {
            return;
        }

        injectStyles();

        const panel = document.createElement('div');
        panel.className = 'rus-inav-launcher';
        panel.innerHTML = `
            <div class="rus-inav-launcher__title">INAV из RUS Config</div>
            <div class="rus-inav-launcher__text">
                При подключении полётника INAV программа сама определит версию прошивки, откроет встроенный INAV Configurator и закроет стартовый конфигуратор.
            </div>
            <div class="rus-inav-launcher__buttons">
                <button class="rus-inav-launcher__button" type="button" data-inav-version="7">INAV 7</button>
                <button class="rus-inav-launcher__button" type="button" data-inav-version="8">INAV 8</button>
                <button class="rus-inav-launcher__button" type="button" data-inav-version="9">INAV 9</button>
            </div>
        `;

        panel.addEventListener('click', function (event) {
            const button = event.target.closest('[data-inav-version]');

            if (!button) {
                return;
            }

            const configurator = getConfigurator(button.getAttribute('data-inav-version'));

            if (launch(configurator, { closeStarter: true })) {
                showDialog('Запуск INAV', `Открываю <strong>${configurator.label}</strong> и закрываю RUS Config.`);
            }
        });

        landing.insertBefore(panel, landing.firstElementChild);
    }

    function startLandingObserver() {
        injectLandingPanel();

        const observer = new MutationObserver(function () {
            injectLandingPanel();
        });

        observer.observe(document.body, { childList: true, subtree: true });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', startLandingObserver);
    } else {
        startLandingObserver();
    }

    window.RusConfigDonetskINAV = {
        CONFIGURATORS,
        getConfigurator,
        getConfiguratorForFirmware,
        getExeCandidates,
        handleDetectedFirmware,
        isInavIdentifier,
        launch,
        resolveConfiguratorExe,
    };
}());
