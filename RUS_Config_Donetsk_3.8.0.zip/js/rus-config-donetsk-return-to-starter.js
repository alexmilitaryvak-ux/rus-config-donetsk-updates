(function () {
    'use strict';

    const FALLBACK_STARTER_EXE = 'D:\\RUS Config Donetsk\\RUS Config Donetsk.exe';
    let cachedStarterExe = '';

    function getRequire() {
        if (typeof nw !== 'undefined' && nw.require) {
            return nw.require.bind(nw);
        }

        if (typeof window !== 'undefined' && window.nw && window.nw.require) {
            return window.nw.require.bind(window.nw);
        }

        if (typeof require === 'function') {
            return require;
        }

        if (typeof window !== 'undefined' && typeof window.require === 'function') {
            return window.require;
        }

        return null;
    }

    function getStarterExe() {
        if (cachedStarterExe) {
            return cachedStarterExe;
        }

        const nodeRequire = getRequire();

        if (nodeRequire) {
            try {
                const fs = nodeRequire('fs');
                const path = nodeRequire('path');
                const base = (typeof process !== 'undefined' && process.execPath)
                    ? path.dirname(process.execPath)
                    : ((typeof process !== 'undefined' && typeof process.cwd === 'function') ? process.cwd() : '');
                const candidates = [
                    path.resolve(base, '..', '..', 'RUS Config Donetsk.exe'),
                    path.resolve(base, '..', '..', '..', 'RUS Config Donetsk.exe'),
                    FALLBACK_STARTER_EXE,
                ];

                for (let index = 0; index < candidates.length; index += 1) {
                    if (fs.existsSync(candidates[index])) {
                        cachedStarterExe = candidates[index];
                        return cachedStarterExe;
                    }
                }
            } catch (error) {
                console.warn('[RUS Config Donetsk Return] Не удалось определить путь к стартовому конфигуратору:', error);
            }
        }

        cachedStarterExe = FALLBACK_STARTER_EXE;
        return cachedStarterExe;
    }

    function launchStarter() {
        const starterExe = getStarterExe();

        if (typeof window !== 'undefined' &&
            window.electronAPI &&
            typeof window.electronAPI.rusConfigOpenStarter === 'function') {
            window.electronAPI.rusConfigOpenStarter(starterExe).then(function (result) {
                if (result !== true) {
                    alert('Не удалось открыть стартовый конфигуратор:\n' + starterExe + '\n\n' + result);
                }
            }).catch(function (error) {
                alert('Не удалось открыть стартовый конфигуратор:\n' + starterExe + '\n\n' + String(error && error.message ? error.message : error));
            });

            return true;
        }

        if (typeof nw !== 'undefined' && nw.Shell && typeof nw.Shell.openItem === 'function') {
            nw.Shell.openItem(starterExe);
            return true;
        }

        if (typeof window !== 'undefined' && window.nw && window.nw.Shell && typeof window.nw.Shell.openItem === 'function') {
            window.nw.Shell.openItem(starterExe);
            return true;
        }

        const nodeRequire = getRequire();

        if (!nodeRequire) {
            return false;
        }

        try {
            const electron = nodeRequire('electron');

            if (electron && electron.shell && typeof electron.shell.openPath === 'function') {
                electron.shell.openPath(starterExe);
                return true;
            }
        } catch (error) {
            console.warn('[RUS Config Donetsk Return] Electron shell недоступен:', error);
        }

        try {
            const childProcess = nodeRequire('child_process');
            const path = nodeRequire('path');
            const child = childProcess.spawn(starterExe, [], {
                cwd: path.dirname(starterExe),
                detached: true,
                stdio: 'ignore',
                windowsHide: false,
            });

            child.unref();
            return true;
        } catch (error) {
            console.error('[RUS Config Donetsk Return] Не удалось запустить стартовый конфигуратор:', error);
            return false;
        }
    }

    function closeThisConfigurator() {
        window.setTimeout(function () {
            try {
                if (typeof nw !== 'undefined' && nw.App && typeof nw.App.quit === 'function') {
                    nw.App.quit();
                    return;
                }

                if (typeof window !== 'undefined' && window.nw && window.nw.App && typeof window.nw.App.quit === 'function') {
                    window.nw.App.quit();
                    return;
                }
            } catch (error) {
                console.warn('[RUS Config Donetsk Return] NW close failed:', error);
            }

            const nodeRequire = getRequire();

            if (nodeRequire) {
                try {
                    const remote = nodeRequire('@electron/remote');

                    if (remote && remote.app && typeof remote.app.quit === 'function') {
                        remote.app.quit();
                        return;
                    }

                    if (remote && typeof remote.getCurrentWindow === 'function') {
                        remote.getCurrentWindow().close();
                        return;
                    }
                } catch (error) {
                    console.warn('[RUS Config Donetsk Return] Electron remote недоступен:', error);
                }

                try {
                    const electron = nodeRequire('electron');

                    if (electron && electron.remote && electron.remote.app && typeof electron.remote.app.quit === 'function') {
                        electron.remote.app.quit();
                        return;
                    }
                } catch (error) {
                    console.warn('[RUS Config Donetsk Return] Electron close failed:', error);
                }
            }

            try {
                window.close();
            } catch (error) {
                console.warn('[RUS Config Donetsk Return] window.close failed:', error);
            }
        }, 500);
    }

    function returnToStarter() {
        const launched = launchStarter();

        if (launched) {
            closeThisConfigurator();
            return;
        }

        alert('Не удалось открыть стартовый конфигуратор:\n' + getStarterExe());
    }

    function injectStyles() {
        if (document.getElementById('rus-config-donetsk-return-style')) {
            return;
        }

        const style = document.createElement('style');
        style.id = 'rus-config-donetsk-return-style';
        style.textContent = `
.rus-config-return {
  box-sizing: border-box;
  width: calc(100% - 20px);
  margin: 12px auto 16px;
  padding: 16px;
  border: 1px solid rgba(255, 255, 255, 0.84);
  border-radius: 6px;
  background:
    linear-gradient(180deg, rgba(255, 255, 255, 0.94) 0%, rgba(255, 255, 255, 0.94) 33.333%, rgba(0, 57, 166, 0.94) 33.333%, rgba(0, 57, 166, 0.94) 66.666%, rgba(213, 43, 30, 0.94) 66.666%, rgba(213, 43, 30, 0.94) 100%);
  color: #ffffff;
  text-align: center;
  box-shadow: inset 0 0 0 1px rgba(0, 0, 0, 0.22);
}
.rus-config-return__title {
  margin-bottom: 10px;
  color: #111111;
  font-size: 15px;
  font-weight: 900;
  text-shadow: 0 1px 0 rgba(255, 255, 255, 0.65);
}
.rus-config-return__button {
  min-height: 36px;
  border: 1px solid rgba(255, 191, 0, 0.9);
  border-radius: 5px;
  background: #ffbf00;
  color: #151515;
  cursor: pointer;
  font-size: 13px;
  font-weight: 900;
  padding: 0 14px;
}
.rus-config-return__slogan {
  margin-top: 10px;
  color: #ffffff;
  font-size: 18px;
  font-weight: 900;
  line-height: 1.2;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.72);
}
`;
        document.head.appendChild(style);
    }

    function createPanel() {
        const panel = document.createElement('div');
        panel.className = 'rus-config-return';
        panel.innerHTML = `
            <div class="rus-config-return__title">Стартовый конфигуратор RUS Config Donetsk</div>
            <button class="rus-config-return__button" type="button">Вернуться в стартовый конфигуратор</button>
            <div class="rus-config-return__slogan">Слава России!</div>
        `;

        panel.querySelector('button').addEventListener('click', returnToStarter);
        return panel;
    }

    function injectButton() {
        const landing = document.querySelector('.tab-landing .content_wrapper');

        if (!landing) {
            return;
        }

        injectStyles();

        const panels = Array.from(document.querySelectorAll('.rus-config-return'));
        const currentPanel = panels.find(function (panel) {
            return panel.parentElement === landing;
        }) || createPanel();

        panels.forEach(function (panel) {
            if (panel !== currentPanel) {
                panel.remove();
            }
        });

        if (currentPanel.parentElement !== landing || landing.firstElementChild !== currentPanel) {
            landing.insertBefore(currentPanel, landing.firstElementChild);
        }
    }

    function start() {
        injectButton();

        const observer = new MutationObserver(function () {
            injectButton();
        });

        observer.observe(document.body, { childList: true, subtree: true });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start);
    } else {
        start();
    }
}());
