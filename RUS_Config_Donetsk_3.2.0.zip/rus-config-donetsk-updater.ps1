param(
    [Parameter(Mandatory = $true)][string]$AppRoot,
    [string]$PackagePath,
    [string]$PackageUrl,
    [Parameter(Mandatory = $true)][string]$ExePath
)

$ErrorActionPreference = 'Stop'

function Write-UpdateLog {
    param([string]$Text)
    $logPath = Join-Path $AppRoot 'update.log'
    $line = ('{0} {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Text)
    Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
}

try {
    Write-UpdateLog "Update started. PackagePath: $PackagePath PackageUrl: $PackageUrl"

    if (-not (Test-Path -LiteralPath $AppRoot -PathType Container)) {
        throw "AppRoot not found: $AppRoot"
    }

    Start-Sleep -Seconds 2

    $processName = [System.IO.Path]::GetFileNameWithoutExtension($ExePath)
    $deadline = (Get-Date).AddSeconds(35)
    while ((Get-Date) -lt $deadline) {
        $running = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -eq $processName }
        if (-not $running) {
            break
        }
        Start-Sleep -Milliseconds 500
    }

    $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('rus-config-donetsk-update-' + [guid]::NewGuid().ToString('N'))
    $extractRoot = Join-Path $tempRoot 'package'
    New-Item -ItemType Directory -Force -Path $extractRoot | Out-Null

    if (-not [string]::IsNullOrWhiteSpace($PackageUrl)) {
        $downloadPath = Join-Path $tempRoot 'update-package.zip'
        Write-UpdateLog "Downloading package: $PackageUrl"
        $ProgressPreference = 'SilentlyContinue'
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $headers = @{}
        if (-not [string]::IsNullOrWhiteSpace($env:RCD_UPDATE_AUTH)) {
            $headers['Authorization'] = $env:RCD_UPDATE_AUTH
        }
        if ($PackageUrl -like 'https://api.github.com/repos/*/contents/*') {
            $headers['Accept'] = 'application/vnd.github.raw+json'
        }

        if ($headers.Count -gt 0) {
            Invoke-WebRequest -UseBasicParsing -Uri $PackageUrl -Headers $headers -OutFile $downloadPath
        } else {
            Invoke-WebRequest -UseBasicParsing -Uri $PackageUrl -OutFile $downloadPath
        }
        $PackagePath = $downloadPath
    }

    if ([string]::IsNullOrWhiteSpace($PackagePath) -or -not (Test-Path -LiteralPath $PackagePath -PathType Leaf)) {
        throw "Package not found: $PackagePath"
    }

    Add-Type -AssemblyName System.IO.Compression.FileSystem

    $zip = [System.IO.Compression.ZipFile]::OpenRead($PackagePath)
    try {
        $extractRootFull = [System.IO.Path]::GetFullPath($extractRoot)
        foreach ($entry in $zip.Entries) {
            if ([string]::IsNullOrWhiteSpace($entry.FullName)) {
                continue
            }

            $target = [System.IO.Path]::GetFullPath((Join-Path $extractRoot $entry.FullName))
            if (-not $target.StartsWith($extractRootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
                throw "Unsafe path in update package: $($entry.FullName)"
            }
        }
    } finally {
        $zip.Dispose()
    }

    [System.IO.Compression.ZipFile]::ExtractToDirectory($PackagePath, $extractRoot)

    $backupRoot = Join-Path $AppRoot ('backup\before-update-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
    New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null

    $files = Get-ChildItem -LiteralPath $extractRoot -Recurse -File
    foreach ($file in $files) {
        $relative = $file.FullName.Substring($extractRoot.Length).TrimStart('\', '/')
        $destination = Join-Path $AppRoot $relative
        if (Test-Path -LiteralPath $destination -PathType Leaf) {
            $backupDestination = Join-Path $backupRoot $relative
            $backupParent = Split-Path -Parent $backupDestination
            if ($backupParent) {
                New-Item -ItemType Directory -Force -Path $backupParent | Out-Null
            }
            Copy-Item -LiteralPath $destination -Destination $backupDestination -Force
        }
    }

    foreach ($file in $files) {
        $relative = $file.FullName.Substring($extractRoot.Length).TrimStart('\', '/')
        $destination = Join-Path $AppRoot $relative
        $destinationParent = Split-Path -Parent $destination
        if ($destinationParent) {
            New-Item -ItemType Directory -Force -Path $destinationParent | Out-Null
        }
        Copy-Item -LiteralPath $file.FullName -Destination $destination -Force
    }

    Remove-Item -LiteralPath $tempRoot -Recurse -Force
    Write-UpdateLog "Update finished. Backup: $backupRoot"

    if (Test-Path -LiteralPath $ExePath -PathType Leaf) {
        Start-Process -FilePath $ExePath -WorkingDirectory $AppRoot
    }
} catch {
    Write-UpdateLog ("Update failed: " + $_.Exception.Message)
    try {
        Start-Process -FilePath 'notepad.exe' -ArgumentList (Join-Path $AppRoot 'update.log')
    } catch {
    }
    throw
}
