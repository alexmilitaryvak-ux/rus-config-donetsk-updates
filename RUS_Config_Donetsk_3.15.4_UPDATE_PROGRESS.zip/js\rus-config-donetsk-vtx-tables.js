(function () {
    var tabText = "VTX \u0433\u043e\u0442\u043e\u0432\u044b\u0435 \u0442\u0430\u0431\u043b\u0438\u0446\u044b";
    var dumpTabText = "\u0413\u043e\u0442\u043e\u0432\u044b\u0435 DUMP";
    var offlineFirmwareTabText = "\u041f\u0440\u043e\u0448\u0438\u0432\u043a\u0438 Offline";
    var upravaTabText = "\u0423\u043f\u0440\u0430\u0432\u0430";
    var programUpdateTabText = "Обновление программы";
    var escConfiguratorTabText = "ESC Configurator";
    var elrsConfiguratorTabText = "ELRS Configurator";
    var elrsConfiguratorMainUrl = "https://elrsweb.ru/";
    var elrsConfiguratorWebFlasherUrl = "https://expresslrs.github.io/web-flasher/";
    var elrsConfiguratorCurrentUrl = elrsConfiguratorMainUrl;
    var guidesTabText = "Руководства";
    var guidesUrl = "https://technobee.ru/";
    var g13TabText = "G13";
    var g13Url = "https://g13.fvds.ru/landing";
    var g13RememberLoginStorageKey = "rus-config-donetsk-g13-remember-login";
    var programUpdateManifestPath = "https://raw.githubusercontent.com/alexmilitaryvak-ux/rus-config-donetsk-updates/main/version.json";
    var programUpdateSourceFileName = "update-source.json";
    var upravaReceiverPhotos = [
        { title: "433M_V1.0 (судоплатов)", photo: "./images/uprava-receivers/433M_V1.0 (судоплатов).jpg" },
        { title: "9624р -4ant", photo: "./images/uprava-receivers/9624р -4ant.jpg", thumbZoom: 2.25, thumbPosition: "50% 50%" },
        { title: "9624R (судоплатов)", photo: "./images/uprava-receivers/9624R (судоплатов).jpg" },
        { title: "9624R", photo: "./images/uprava-receivers/9624R.jpg" },
        { title: "Гермес", photo: "./images/uprava-receivers/Гермес.jpg" },
        { title: "Камчатка", photo: "./images/uprava-receivers/Камчатка.jpg" },
        { title: "Корал 15", photo: "./images/uprava-receivers/Корал 15.jpg" },
        { title: "Коралл 150", photo: "./images/uprava-receivers/Коралл 150.jpg" },
        { title: "Кузнечик G4", photo: "./images/uprava-receivers/Кузнечик G4.jpg" },
        { title: "Кузнечик", photo: "./images/uprava-receivers/Кузнечик.jpg" },
        { title: "ППРЧ КРЛ", photo: "./images/uprava-receivers/ППРЧ КРЛ.jpg" },
        { title: "Радуга", photo: "./images/uprava-receivers/Радуга.jpg" },
        { title: "Ariadna_R1A1_RX", photo: "./images/uprava-receivers/Ariadna_R1A1_RX.jpg" },
        { title: "B_SubGHz_RX", photo: "./images/uprava-receivers/B_SubGHz_RX.jpg" },
        { title: "BAYCKRC_900-2400_Dual_Band_Gemini_RX", photo: "./images/uprava-receivers/BAYCKRC_900-2400_Dual_Band_Gemini_RX.jpg" },
        { title: "BAYCKRC_900MHz_Dual_Core_RX", photo: "./images/uprava-receivers/BAYCKRC_900MHz_Dual_Core_RX.jpg" },
        { title: "belinRC = generic 900 = es900rx = betaFPV 900", photo: "./images/uprava-receivers/belinRC = generic 900 = es900rx = betaFPV 900.jpg" },
        { title: "BETAFPV 400MHz RX", photo: "./images/uprava-receivers/BETAFPV 400MHz RX.jpg" },
        { title: "Betafpv nano 2.4", photo: "./images/uprava-receivers/Betafpv nano 2.4 .jpg" },
        { title: "bswn 2.4", photo: "./images/uprava-receivers/bswn 2.4.jpg" },
        { title: "BSWN", photo: "./images/uprava-receivers/BSWN.jpg" },
        { title: "CYCLONE_C3_LR1121_400_RX", photo: "./images/uprava-receivers/CYCLONE_C3_LR1121_400_RX.jpg" },
        { title: "DAKEFPV 2.4 Nano", photo: "./images/uprava-receivers/DAKEFPV 2.4 Nano.jpg" },
        { title: "Edifier_1121R", photo: "./images/uprava-receivers/Edifier_1121R.jpg" },
        { title: "ff515rx", photo: "./images/uprava-receivers/ff515rx.jpg" },
        { title: "Flyfish 300rx", photo: "./images/uprava-receivers/Flyfish 300rx.jpg" },
        { title: "Flyfish 515rx", photo: "./images/uprava-receivers/Flyfish 515rx.jpg" },
        { title: "FLYFISH_2400_RX", photo: "./images/uprava-receivers/FLYFISH_2400_RX.jpg" },
        { title: "FlyFish_515_RX_", photo: "./images/uprava-receivers/FlyFish_515_RX_.jpg" },
        { title: "FlyFish_515_RX", photo: "./images/uprava-receivers/FlyFish_515_RX.jpg" },
        { title: "Foxeer 400 (500)", photo: "./images/uprava-receivers/Foxeer 400 (500).jpg" },
        { title: "Foxeer 900", photo: "./images/uprava-receivers/Foxeer 900.jpg" },
        { title: "generic 900 = es900rx = betafpv900rx", photo: "./images/uprava-receivers/generic 900 = es900rx = betafpv900rx.jpg" },
        { title: "Generic ESP8285 SX127x 900MHz RX Radiomaster BR1", photo: "./images/uprava-receivers/Generic ESP8285 SX127x 900MHz RX Radiomaster BR1.jpg" },
        { title: "GEPRC_900-2400_Single_Dual-Band_RX", photo: "./images/uprava-receivers/GEPRC_900-2400_Single_Dual-Band_RX.jpg" },
        { title: "HappyModel EP1 Dual", photo: "./images/uprava-receivers/HappyModel EP1 Dual.jpg" },
        { title: "HappyModel es900 dual rx", photo: "./images/uprava-receivers/HappyModel es900 dual rx.jpg" },
        { title: "HappyModelES900", photo: "./images/uprava-receivers/HappyModelES900.jpg" },
        { title: "Hobbyporter DBR1", photo: "./images/uprava-receivers/Hobbyporter DBR1.jpg" },
        { title: "Hobbyporter_DBR1_", photo: "./images/uprava-receivers/Hobbyporter_DBR1_.jpg" },
        { title: "Hobbyporter_DBR1", photo: "./images/uprava-receivers/Hobbyporter_DBR1.jpg" },
        { title: "mc2r4-1", photo: "./images/uprava-receivers/mc2r4-1.jpg" },
        { title: "mc2r4", photo: "./images/uprava-receivers/mc2r4.jpg" },
        { title: "radiomaster br3", photo: "./images/uprava-receivers/radiomaster br3.jpg" },
        { title: "Radiomaster RP3", photo: "./images/uprava-receivers/Radiomaster RP3.jpg" },
        { title: "Radiomaster xr3 dual diversity", photo: "./images/uprava-receivers/Radiomaster xr3 dual diversity.jpg" },
        { title: "SE4_900-2400_Dual_Band_Gemini", photo: "./images/uprava-receivers/SE4_900-2400_Dual_Band_Gemini.jpg" },
        { title: "TBS", photo: "./images/uprava-receivers/TBS.jpg" }
    ];
    var upravaTransmitterPhotos = [
        { title: "Квантв2", photo: "./images/uprava-transmitters/Квантв2.jpg" },
        { title: "b.sub", photo: "./images/uprava-transmitters/b.sub.jpg" },
        { title: "BAYCKRC_900-2400_Dual_Band_1W_Nano_TX", photo: "./images/uprava-transmitters/BAYCKRC_900-2400_Dual_Band_1W_Nano_TX.jpg" },
        { title: "beastfpv 2.1", photo: "./images/uprava-transmitters/beastfpv 2.1.jpg" },
        { title: "BEASTFPV_750MHZ_TX (хороший)", photo: "./images/uprava-transmitters/BEASTFPV_750MHZ_TX (хороший).jpg" },
        { title: "BEASTFPV_750MHZ_TX_V2 (плохой)", photo: "./images/uprava-transmitters/BEASTFPV_750MHZ_TX_V2 (плохой).jpg" },
        { title: "belinrc 433ТХ", photo: "./images/uprava-transmitters/belinrc 433ТХ.jpg" },
        { title: "BETAFPV 900 Micro V2", photo: "./images/uprava-transmitters/BETAFPV 900 Micro V2.jpg" },
        { title: "CYCLONE LR1211 TX 1W", photo: "./images/uprava-transmitters/CYCLONE LR1211 TX 1W.jpg" },
        { title: "CYCLONE_LR1121_TX_board_2.0", photo: "./images/uprava-transmitters/CYCLONE_LR1121_TX_board_2.0..jpg" },
        { title: "CYCLONE_LR1121_TX_board_2.0", photo: "./images/uprava-transmitters/CYCLONE_LR1121_TX_board_2.0.jpg" },
        { title: "DIY_ESP32_E19_900MHz_TX", photo: "./images/uprava-transmitters/DIY_ESP32_E19_900MHz_TX.jpg" },
        { title: "Edifier Oled 433", photo: "./images/uprava-transmitters/Edifier Oled 433..jpg" },
        { title: "Edifier Oled 433", photo: "./images/uprava-transmitters/Edifier Oled 433.jpg" },
        { title: "FF1027", photo: "./images/uprava-transmitters/FF1027.jpg" },
        { title: "FlyFish_500MHz_TX", photo: "./images/uprava-transmitters/FlyFish_500MHz_TX.jpg" },
        { title: "happymodel es900tx", photo: "./images/uprava-transmitters/happymodel es900tx.jpg" },
        { title: "HappyModel_ES900_Max_TX", photo: "./images/uprava-transmitters/HappyModel_ES900_Max_TX.jpg" },
        { title: "NamimnoRC_Flash_OLED_2.4GHz_TX", photo: "./images/uprava-transmitters/NamimnoRC_Flash_OLED_2.4GHz_TX.jpg" },
        { title: "NamimnoRC_N400T_1W_TX", photo: "./images/uprava-transmitters/NamimnoRC_N400T_1W_TX.jpg" },
        { title: "radiomaster ranger micro 2.4", photo: "./images/uprava-transmitters/radiomaster ranger micro 2.4.jpg" },
        { title: "Radiomaster T5", photo: "./images/uprava-transmitters/Radiomaster T5.jpg" },
        { title: "RadioMaster_500-TX", photo: "./images/uprava-transmitters/RadioMaster_500-TX.jpg" }
    ];
    var upravaFirmwareSections = [
        {
            id: "rx",
            title: "Приемник (RX)",
            groups: [
                {
                    id: "red-v4",
                    title: "Прошивка RED version 4",
                    folder: "./uprava-firmware/RX/RED-version-4",
                    items:                         [
                          {
                            "label": "LR1121 Ariadna R1A1 RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Ariadna_R1A1_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_Ariadna_R1A1_RX.bin"
                          },
                          {
                            "label": "LR1121 B SubGHz RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_B_SubGHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_B_SubGHz_RX.bin"
                          },
                          {
                            "label": "LR1121 BAYCKRC 900-2400 Dual Band Gemini RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BAYCKRC_900-2400_Dual_Band_Gemini_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_BAYCKRC_900-2400_Dual_Band_Gemini_RX.bin"
                          },
                          {
                            "label": "LR1121 BAYCKRC C3 900-2400 Dual Band 100mw 6PWM RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BAYCKRC_C3_900-2400_Dual_Band_100mw_6PWM_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_BAYCKRC_C3_900-2400_Dual_Band_100mw_6PWM_RX.bin"
                          },
                          {
                            "label": "LR1121 BAYCKRC C3 900-2400 Dual Band 100mW Gemini RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BAYCKRC_C3_900-2400_Dual_Band_100mW_Gemini_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_BAYCKRC_C3_900-2400_Dual_Band_100mW_Gemini_RX.bin"
                          },
                          {
                            "label": "LR1121 BAYCKRC C3 900-2400 Dual Band Nano RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BAYCKRC_C3_900-2400_Dual_Band_Nano_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_BAYCKRC_C3_900-2400_Dual_Band_Nano_RX.bin"
                          },
                          {
                            "label": "LR1121 BAYCKRC UR100 Dual Band RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BAYCKRC_UR100_Dual_Band_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_BAYCKRC_UR100_Dual_Band_RX.bin"
                          },
                          {
                            "label": "LR1121 BAYCKRC UR1000 Dual Band RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BAYCKRC_UR1000_Dual_Band_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_BAYCKRC_UR1000_Dual_Band_RX.bin"
                          },
                          {
                            "label": "LR1121 BAYCKRC UR500 Dual Band RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BAYCKRC_UR500_Dual_Band_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_BAYCKRC_UR500_Dual_Band_RX.bin"
                          },
                          {
                            "label": "LR1121 BETAFPV SuperX Mono RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BETAFPV_SuperX_Mono_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_BETAFPV_SuperX_Mono_RX.bin"
                          },
                          {
                            "label": "LR1121 BETAFPV SuperX Nano RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BETAFPV_SuperX_Nano_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_BETAFPV_SuperX_Nano_RX.bin"
                          },
                          {
                            "label": "LR1121 BrotherHobby C3 900-2400 Dual Band 100mW Gemini RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BrotherHobby_C3_900-2400_Dual_Band_100mW_Gemini_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_BrotherHobby_C3_900-2400_Dual_Band_100mW_Gemini_RX.bin"
                          },
                          {
                            "label": "LR1121 CYCLONE C3 LR1121 400 RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_CYCLONE_C3_LR1121_400_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_CYCLONE_C3_LR1121_400_RX.bin"
                          },
                          {
                            "label": "LR1121 CYCLONE XR3 Dual Band Gemini RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_CYCLONE_XR3_Dual_Band_Gemini_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_CYCLONE_XR3_Dual_Band_Gemini_RX.bin"
                          },
                          {
                            "label": "LR1121 DAKEFPV 1W 2.4GHz RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_DAKEFPV_1W_2.4GHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_DAKEFPV_1W_2.4GHz_RX.bin"
                          },
                          {
                            "label": "LR1121 DAKEFPV 400MHz RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_DAKEFPV_400MHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_DAKEFPV_400MHz_RX.bin"
                          },
                          {
                            "label": "LR1121 DAKEFPV 500mW 2.4GHz RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_DAKEFPV_500mW_2.4GHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_DAKEFPV_500mW_2.4GHz_RX.bin"
                          },
                          {
                            "label": "LR1121 DAKEFPV C3 900-2400 Dual Band 100mW Gemini RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_DAKEFPV_C3_900-2400_Dual_Band_100mW_Gemini_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_DAKEFPV_C3_900-2400_Dual_Band_100mW_Gemini_RX.bin"
                          },
                          {
                            "label": "LR1121 DAKEFPV Nano 2.4GHz RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_DAKEFPV_Nano_2.4GHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_DAKEFPV_Nano_2.4GHz_RX.bin"
                          },
                          {
                            "label": "LR1121 DAKEFPV Nano 900MHz RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_DAKEFPV_Nano_900MHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_DAKEFPV_Nano_900MHz_RX.bin"
                          },
                          {
                            "label": "LR1121 DAKEFPV SuperD 2.4GHz RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_DAKEFPV_SuperD_2.4GHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_DAKEFPV_SuperD_2.4GHz_RX.bin"
                          },
                          {
                            "label": "LR1121 Edifier 1121R",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Edifier_1121R.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_Edifier_1121R.bin"
                          },
                          {
                            "label": "LR1121 FlyFish 9624R 4ant",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_FlyFish_9624R_4ant.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_FlyFish_9624R_4ant.bin"
                          },
                          {
                            "label": "LR1121 FlyFish 9624R",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_FlyFish_9624R.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_FlyFish_9624R.bin"
                          },
                          {
                            "label": "LR1121 Gemini C3 XrossBand PA 2.4-900 RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Gemini_C3_XrossBand_PA_2.4-900_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_Gemini_C3_XrossBand_PA_2.4-900_RX.bin"
                          },
                          {
                            "label": "LR1121 Gemini XrossBand PA 2.4-900 RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Gemini_XrossBand_PA_2.4-900_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_Gemini_XrossBand_PA_2.4-900_RX.bin"
                          },
                          {
                            "label": "LR1121 Generic C3 LR1121 2.4-900 PWM RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_C3_LR1121_2.4-900_PWM_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_Generic_C3_LR1121_2.4-900_PWM_RX.bin"
                          },
                          {
                            "label": "LR1121 Generic C3 LR1121 2.4-900 RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_C3_LR1121_2.4-900_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_Generic_C3_LR1121_2.4-900_RX.bin"
                          },
                          {
                            "label": "LR1121 GEPRC 900-2400 Gemini Xrossband RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_GEPRC_900-2400_Gemini_Xrossband_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_GEPRC_900-2400_Gemini_Xrossband_RX.bin"
                          },
                          {
                            "label": "LR1121 GEPRC 900-2400 Single Dual-Band RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_GEPRC_900-2400_Single_Dual-Band_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_GEPRC_900-2400_Single_Dual-Band_RX.bin"
                          },
                          {
                            "label": "LR1121 GEPRC C3 900-2400 Gemini Xrossband RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_GEPRC_C3_900-2400_Gemini_Xrossband_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_GEPRC_C3_900-2400_Gemini_Xrossband_RX.bin"
                          },
                          {
                            "label": "LR1121 HGLRC C3 900-2400 Dual Band Nano RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HGLRC_C3_900-2400_Dual_Band_Nano_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_HGLRC_C3_900-2400_Dual_Band_Nano_RX.bin"
                          },
                          {
                            "label": "LR1121 HGLRC C3 900-2400 Dual Band PRO RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HGLRC_C3_900-2400_Dual_Band_PRO_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_HGLRC_C3_900-2400_Dual_Band_PRO_RX.bin"
                          },
                          {
                            "label": "LR1121 Hobbyporter DBR4",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Hobbyporter_DBR4.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_Hobbyporter_DBR4.bin"
                          },
                          {
                            "label": "LR1121 Holybro Zephyr Dual Band RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Holybro_Zephyr_Dual_Band_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_Holybro_Zephyr_Dual_Band_RX.bin"
                          },
                          {
                            "label": "LR1121 RadioMaster DBR4-TD True Diversity Dual Band RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_DBR4-TD_True_Diversity_Dual_Band_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_RadioMaster_DBR4-TD_True_Diversity_Dual_Band_RX.bin"
                          },
                          {
                            "label": "LR1121 RadioMaster XR1 Dual Band RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_XR1_Dual_Band_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_RadioMaster_XR1_Dual_Band_RX.bin"
                          },
                          {
                            "label": "LR1121 RadioMaster XR2 2.4GHz RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_XR2_2.4GHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_RadioMaster_XR2_2.4GHz_RX.bin"
                          },
                          {
                            "label": "LR1121 RadioMaster XR3 Dual Band Diversity RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_XR3_Dual_Band_Diversity_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_RadioMaster_XR3_Dual_Band_Diversity_RX.bin"
                          },
                          {
                            "label": "LR1121 RadioMaster XR4 Dual Band True Diversity RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_XR4_Dual_Band_True_Diversity_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_RadioMaster_XR4_Dual_Band_True_Diversity_RX.bin"
                          },
                          {
                            "label": "LR1121 SE4 900-2400 Dual Band Xross Gemini RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_SE4_900-2400_Dual_Band_Xross_Gemini_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_SE4_900-2400_Dual_Band_Xross_Gemini_RX.bin"
                          },
                          {
                            "label": "LR1121 Skopa RX V1.1",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Skopa_RX_V1.1.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_Skopa_RX_V1.1.bin"
                          },
                          {
                            "label": "LR1121 Spedix Dual Band RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Spedix_Dual_Band_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_Spedix_Dual_Band_RX.bin"
                          },
                          {
                            "label": "LR1121 Sub250 900-2400 Single Dual-Band RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Sub250_900-2400_Single_Dual-Band_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_Sub250_900-2400_Single_Dual-Band_RX.bin"
                          },
                          {
                            "label": "LR1121 THOBBY Dual Band RX",
                            "chip": "LR1121",
                            "version": "RED version 4",
                            "fileName": "R5RC6_THOBBY_Dual_Band_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/LR1121/R5RC6_THOBBY_Dual_Band_RX.bin"
                          },
                          {
                            "label": "SX1262 RMRLS RX",
                            "chip": "SX1262",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RMRLS_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1262/R5RC6_RMRLS_RX.bin"
                          },
                          {
                            "label": "SX1262 ZRX",
                            "chip": "SX1262",
                            "version": "RED version 4",
                            "fileName": "R5RC6_ZRX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1262/R5RC6_ZRX.bin"
                          },
                          {
                            "label": "SX1276 BAYCKRC 900MHz Dual Core RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BAYCKRC_900MHz_Dual_Core_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_BAYCKRC_900MHz_Dual_Core_RX.bin"
                          },
                          {
                            "label": "SX1276 BAYCKRC 900MHz Nano RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BAYCKRC_900MHz_Nano_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_BAYCKRC_900MHz_Nano_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 BeastFPV 750MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BeastFPV_750MHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_BeastFPV_750MHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 BelinRC 433MHZ RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BelinRC_433MHZ_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_BelinRC_433MHZ_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 BETAFPV 400MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BETAFPV_400MHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_BETAFPV_400MHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 BETAFPV 900MHz Nano RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BETAFPV_900MHz_Nano_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_BETAFPV_900MHz_Nano_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 BETAFPV SuperD 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BETAFPV_SuperD_900MHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_BETAFPV_SuperD_900MHz_RX.bin"
                          },
                          {
                            "label": "SX1276 BETAFPV SuperP 14Ch 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BETAFPV_SuperP_14Ch_900MHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_BETAFPV_SuperP_14Ch_900MHz_RX.bin"
                          },
                          {
                            "label": "SX1276 BETAFPV SuperP TX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BETAFPV_SuperP_TX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_BETAFPV_SuperP_TX.bin"
                          },
                          {
                            "label": "SX1276 BrotherHobby 900MHz Nano RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BrotherHobby_900MHz_Nano_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_BrotherHobby_900MHz_Nano_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 CYCLONE 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_CYCLONE_900MHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_CYCLONE_900MHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 DISRC 433MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_DISRC_433MHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_DISRC_433MHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 DIY Huzzah RFM95 900MHz TX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_DIY_Huzzah_RFM95_900MHz_TX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_DIY_Huzzah_RFM95_900MHz_TX.bin.gz"
                          },
                          {
                            "label": "SX1276 DIY TTGO V1 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_DIY_TTGO_V1_900MHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_DIY_TTGO_V1_900MHz_RX.bin"
                          },
                          {
                            "label": "SX1276 DIY TTGO V2 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_DIY_TTGO_V2_900MHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_DIY_TTGO_V2_900MHz_RX.bin"
                          },
                          {
                            "label": "SX1276 Edifier 433RX True Diversity",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Edifier_433RX_True_Diversity.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_Edifier_433RX_True_Diversity.bin"
                          },
                          {
                            "label": "SX1276 EMAX 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_EMAX_900MHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_EMAX_900MHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 FlyFish 433M RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_FlyFish_433M_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_FlyFish_433M_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 FlyFish 515MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_FlyFish_515MHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_FlyFish_515MHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 Foxeer 786MHz True Diversity RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Foxeer_786MHz_True_Diversity_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_Foxeer_786MHz_True_Diversity_RX.bin"
                          },
                          {
                            "label": "SX1276 Foxeer 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Foxeer_900MHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_Foxeer_900MHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 Foxeer 900MHz True Diversity RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Foxeer_900MHz_True_Diversity_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_Foxeer_900MHz_True_Diversity_RX.bin"
                          },
                          {
                            "label": "SX1276 Foxeer Diversity 400MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Foxeer_Diversity_400MHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_Foxeer_Diversity_400MHz_RX.bin"
                          },
                          {
                            "label": "SX1276 Generic ESP32 True Diversity 16xPWM 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP32_True_Diversity_16xPWM_900MHz_RX_.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_Generic_ESP32_True_Diversity_16xPWM_900MHz_RX_.bin"
                          },
                          {
                            "label": "SX1276 Generic ESP32 True Diversity 900MHz 500mW RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP32_True_Diversity_900MHz_500mW_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_Generic_ESP32_True_Diversity_900MHz_500mW_RX.bin"
                          },
                          {
                            "label": "SX1276 Generic ESP32 True Diversity 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP32_True_Diversity_900MHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_Generic_ESP32_True_Diversity_900MHz_RX.bin"
                          },
                          {
                            "label": "SX1276 Generic ESP8285 SX127x 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP8285_SX127x_900MHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_Generic_ESP8285_SX127x_900MHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 Generic ESP8285 SX127x with PWM 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP8285_SX127x_with_PWM_900MHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_Generic_ESP8285_SX127x_with_PWM_900MHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 GEPRC Nano 900MHz PA500 RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_GEPRC_Nano_900MHz_PA500_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_GEPRC_Nano_900MHz_PA500_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 GEPRC Nano 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_GEPRC_Nano_900MHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_GEPRC_Nano_900MHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 GEPRC True Diversity 900MHz PA500 RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_GEPRC_True_Diversity_900MHz_PA500_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_GEPRC_True_Diversity_900MHz_PA500_RX.bin"
                          },
                          {
                            "label": "SX1276 GEPRC True Diversity 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_GEPRC_True_Diversity_900MHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_GEPRC_True_Diversity_900MHz_RX.bin"
                          },
                          {
                            "label": "SX1276 HAOYERC 900MHz Nano RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HAOYERC_900MHz_Nano_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_HAOYERC_900MHz_Nano_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 HappyModel EPW6 PWM RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HappyModel_EPW6_PWM_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_HappyModel_EPW6_PWM_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 HappyModel ES900 Dual RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HappyModel_ES900_Dual_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_HappyModel_ES900_Dual_RX.bin"
                          },
                          {
                            "label": "SX1276 HappyModel ES900 RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HappyModel_ES900_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_HappyModel_ES900_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 HGLRC Gemini 900M RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HGLRC_Gemini_900M_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_HGLRC_Gemini_900M_RX.bin"
                          },
                          {
                            "label": "SX1276 HGLRC Hermes 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HGLRC_Hermes_900MHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_HGLRC_Hermes_900MHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 iFlight 900MHz 500mW Diversity RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_iFlight_900MHz_500mW_Diversity_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_iFlight_900MHz_500mW_Diversity_RX.bin"
                          },
                          {
                            "label": "SX1276 iFlight 900MHz 500mW RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_iFlight_900MHz_500mW_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_iFlight_900MHz_500mW_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 iFlight 900MHz Nano RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_iFlight_900MHz_Nano_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_iFlight_900MHz_Nano_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 iFlight 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_iFlight_900MHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_iFlight_900MHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 JHEMCU 900RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_JHEMCU_900RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_JHEMCU_900RX.bin.gz"
                          },
                          {
                            "label": "SX1276 Jumper AION Mini 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Jumper_AION_Mini_900MHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_Jumper_AION_Mini_900MHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 NamimnoRC Voyager ESP 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_NamimnoRC_Voyager_ESP_900MHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_NamimnoRC_Voyager_ESP_900MHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 NeutronRC 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_NeutronRC_900MHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_NeutronRC_900MHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 RadioMaster Bandit Nano-Micro 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_Bandit_Nano-Micro_900MHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_RadioMaster_Bandit_Nano-Micro_900MHz_RX.bin"
                          },
                          {
                            "label": "SX1276 RadioMaster BR1 900Mz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_BR1_900Mz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_RadioMaster_BR1_900Mz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 RadioMaster BR3 Diversity 900Mz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_BR3_Diversity_900Mz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_RadioMaster_BR3_Diversity_900Mz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 RadioMaster BR4TD 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_BR4TD_900MHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_RadioMaster_BR4TD_900MHz_RX.bin"
                          },
                          {
                            "label": "SX1276 Raduga RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Raduga_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_Raduga_RX.bin"
                          },
                          {
                            "label": "SX1276 SEQURE 900MHz Dual RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_SEQURE_900MHz_Dual_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_SEQURE_900MHz_Dual_RX.bin"
                          },
                          {
                            "label": "SX1276 Spedix 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Spedix_900MHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_Spedix_900MHz_RX.bin"
                          },
                          {
                            "label": "SX1276 SpeedyBee Nano 915MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_SpeedyBee_Nano_915MHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_SpeedyBee_Nano_915MHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 STELLAR 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_STELLAR_900MHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_STELLAR_900MHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 TBS Crossfire XF Nano 50 RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_TBS_Crossfire_XF_Nano_50_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_TBS_Crossfire_XF_Nano_50_RX.bin"
                          },
                          {
                            "label": "SX1276 THOBBY 900MHz RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_THOBBY_900MHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_THOBBY_900MHz_RX.bin"
                          },
                          {
                            "label": "SX1276 Zhmil 370M RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Zhmil_370M_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_Zhmil_370M_RX.bin.gz"
                          },
                          {
                            "label": "SX1276 Zhmil 700M TD RX",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Zhmil_700M_TD_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_Zhmil_700M_TD_RX.bin"
                          },
                          {
                            "label": "SX1276 ZOV RX 520MHz",
                            "chip": "SX1276",
                            "version": "RED version 4",
                            "fileName": "R5RC6_ZOV_RX_520MHz.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1276/R5RC6_ZOV_RX_520MHz.bin"
                          },
                          {
                            "label": "SX1280 Anyleaf 2.4GHz dual radio RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Anyleaf_2.4GHz_dual_radio_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Anyleaf_2.4GHz_dual_radio_RX.bin"
                          },
                          {
                            "label": "SX1280 Anyleaf 2.4GHz single radio RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Anyleaf_2.4GHz_single_radio_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Anyleaf_2.4GHz_single_radio_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 Anyleaf FC integrated RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Anyleaf_FC_integrated_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Anyleaf_FC_integrated_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 atomrc 2.4G RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_atomrc_2.4G_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_atomrc_2.4G_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 AXIS Thor 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_AXIS_Thor_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_AXIS_Thor_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 BAYCKRC 2.4GHz Dual Core RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BAYCKRC_2.4GHz_Dual_Core_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_BAYCKRC_2.4GHz_Dual_Core_RX.bin"
                          },
                          {
                            "label": "SX1280 BAYCKRC 2.4GHz Nano RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BAYCKRC_2.4GHz_Nano_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_BAYCKRC_2.4GHz_Nano_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 BeastFPV 2.1GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BeastFPV_2.1GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_BeastFPV_2.1GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 BETAFPV 2.4GHz AIO RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BETAFPV_2.4GHz_AIO_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_BETAFPV_2.4GHz_AIO_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 BETAFPV 2.4GHz Lite RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BETAFPV_2.4GHz_Lite_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_BETAFPV_2.4GHz_Lite_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 BETAFPV 2.4GHz Nano RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BETAFPV_2.4GHz_Nano_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_BETAFPV_2.4GHz_Nano_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 BETAFPV PWM 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BETAFPV_PWM_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_BETAFPV_PWM_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 BETAFPV SuperD 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BETAFPV_SuperD_2.4GHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_BETAFPV_SuperD_2.4GHz_RX.bin"
                          },
                          {
                            "label": "SX1280 BETAFPV SuperP 14Ch 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BETAFPV_SuperP_14Ch_2.4GHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_BETAFPV_SuperP_14Ch_2.4GHz_RX.bin"
                          },
                          {
                            "label": "SX1280 BrotherHobby 2.4GHz Nano RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_BrotherHobby_2.4GHz_Nano_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_BrotherHobby_2.4GHz_Nano_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 CYCLONE 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_CYCLONE_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_CYCLONE_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 EMAX 2.4GHz PA RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_EMAX_2.4GHz_PA_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_EMAX_2.4GHz_PA_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 EMAX 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_EMAX_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_EMAX_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 FD R24D 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_FD_R24D_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_FD_R24D_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 FlyFish MC2R4",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_FlyFish_MC2R4.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_FlyFish_MC2R4.bin.gz"
                          },
                          {
                            "label": "SX1280 FlyFish RD2R4",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_FlyFish_RD2R4.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_FlyFish_RD2R4.bin.gz"
                          },
                          {
                            "label": "SX1280 Flywoo EL24E TCXO 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Flywoo_EL24E_TCXO_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Flywoo_EL24E_TCXO_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 Flywoo EL24P TCXO 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Flywoo_EL24P_TCXO_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Flywoo_EL24P_TCXO_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 Foxeer 2.4Ghz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Foxeer_2.4Ghz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Foxeer_2.4Ghz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 Foxeer Lite 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Foxeer_Lite_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Foxeer_Lite_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 Generic ESP32 2.4Ghz Franken RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP32_2.4Ghz_Franken_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Generic_ESP32_2.4Ghz_Franken_RX.bin"
                          },
                          {
                            "label": "SX1280 Generic ESP32 2.4Ghz Rx and VTx",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP32_2.4Ghz_Rx_and_VTx.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Generic_ESP32_2.4Ghz_Rx_and_VTx.bin"
                          },
                          {
                            "label": "SX1280 Generic ESP32 PWM Vario 2.4Ghz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP32_PWM_Vario_2.4Ghz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Generic_ESP32_PWM_Vario_2.4Ghz_RX.bin"
                          },
                          {
                            "label": "SX1280 Generic ESP32 True Diversity 16xPWM 2.4Ghz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP32_True_Diversity_16xPWM_2.4Ghz_RX_.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Generic_ESP32_True_Diversity_16xPWM_2.4Ghz_RX_.bin"
                          },
                          {
                            "label": "SX1280 Generic ESP32 True Diversity 2.4Ghz RX and VTx",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP32_True_Diversity_2.4Ghz_RX_and_VTx.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Generic_ESP32_True_Diversity_2.4Ghz_RX_and_VTx.bin"
                          },
                          {
                            "label": "SX1280 Generic ESP32 True Diversity PA 14xPWM 2.4Ghz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP32_True_Diversity_PA_14xPWM_2.4Ghz_RX_.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Generic_ESP32_True_Diversity_PA_14xPWM_2.4Ghz_RX_.bin"
                          },
                          {
                            "label": "SX1280 Generic ESP32 True Diversity PA 2.4Ghz RX and VTx",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP32_True_Diversity_PA_2.4Ghz_RX_and_VTx.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Generic_ESP32_True_Diversity_PA_2.4Ghz_RX_and_VTx.bin"
                          },
                          {
                            "label": "SX1280 Generic ESP32 True Diversity PA 2.4Ghz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP32_True_Diversity_PA_2.4Ghz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Generic_ESP32_True_Diversity_PA_2.4Ghz_RX.bin"
                          },
                          {
                            "label": "SX1280 Generic ESP8285 2.4Ghz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP8285_2.4Ghz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Generic_ESP8285_2.4Ghz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 Generic ESP8285 5xPWM 2.4Ghz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP8285_5xPWM_2.4Ghz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Generic_ESP8285_5xPWM_2.4Ghz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 Generic ESP8285 6xPWM 2.4Ghz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP8285_6xPWM_2.4Ghz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Generic_ESP8285_6xPWM_2.4Ghz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 Generic ESP8285 7xPWM 2.4Ghz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP8285_7xPWM_2.4Ghz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Generic_ESP8285_7xPWM_2.4Ghz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 Generic ESP8285 Diversity PA 2.4Ghz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP8285_Diversity_PA_2.4Ghz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Generic_ESP8285_Diversity_PA_2.4Ghz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 Generic ESP8285 PA 2.4Ghz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP8285_PA_2.4Ghz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Generic_ESP8285_PA_2.4Ghz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 Generic ESP8285 RGB + PA 2.4Ghz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Generic_ESP8285_RGB_+_PA_2.4Ghz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Generic_ESP8285_RGB_+_PA_2.4Ghz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 GEPRC Nano 2.4GHz PA100 RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_GEPRC_Nano_2.4GHz_PA100_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_GEPRC_Nano_2.4GHz_PA100_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 GEPRC Nano(SE) 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_GEPRC_Nano(SE)_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_GEPRC_Nano(SE)_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 GEPRC True Diversity 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_GEPRC_True_Diversity_2.4GHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_GEPRC_True_Diversity_2.4GHz_RX.bin"
                          },
                          {
                            "label": "SX1280 HappyModel AIO 2.4GHz RX+VTX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HappyModel_AIO_2.4GHz_RX+VTX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_HappyModel_AIO_2.4GHz_RX+VTX.bin"
                          },
                          {
                            "label": "SX1280 HappyModel EP Dual 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HappyModel_EP_Dual_2.4GHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_HappyModel_EP_Dual_2.4GHz_RX.bin"
                          },
                          {
                            "label": "SX1280 HappyModel EP1-EP2 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HappyModel_EP1-EP2_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_HappyModel_EP1-EP2_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 HappyModel EPW5 2.4GHz PWM RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HappyModel_EPW5_2.4GHz_PWM_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_HappyModel_EPW5_2.4GHz_PWM_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 HappyModel EPW6 2.4GHz PWM RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HappyModel_EPW6_2.4GHz_PWM_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_HappyModel_EPW6_2.4GHz_PWM_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 HelloRadio HR7E 2.4GHz Diversity+7xPWM RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HelloRadio_HR7E_2.4GHz_Diversity+7xPWM_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_HelloRadio_HR7E_2.4GHz_Diversity+7xPWM_RX.bin"
                          },
                          {
                            "label": "SX1280 HelloRadio HR8E 2.4GHz Diversity+8xPWM RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HelloRadio_HR8E_2.4GHz_Diversity+8xPWM_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_HelloRadio_HR8E_2.4GHz_Diversity+8xPWM_RX.bin"
                          },
                          {
                            "label": "SX1280 HelloRadio HR8E TX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HelloRadio_HR8E_TX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_HelloRadio_HR8E_TX.bin"
                          },
                          {
                            "label": "SX1280 HGLRC Gemini 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HGLRC_Gemini_2.4GHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_HGLRC_Gemini_2.4GHz_RX.bin"
                          },
                          {
                            "label": "SX1280 HGLRC Hermes 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_HGLRC_Hermes_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_HGLRC_Hermes_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 iFlight 2.4GHz 250mW Diversity RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_iFlight_2.4GHz_250mW_Diversity_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_iFlight_2.4GHz_250mW_Diversity_RX.bin"
                          },
                          {
                            "label": "SX1280 iFlight 2.4GHz 500mW RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_iFlight_2.4GHz_500mW_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_iFlight_2.4GHz_500mW_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 iFlight 2.4GHz Nano RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_iFlight_2.4GHz_Nano_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_iFlight_2.4GHz_Nano_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 iFlight 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_iFlight_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_iFlight_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 JHEMCU 2.4GHz Dual RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_JHEMCU_2.4GHz_Dual_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_JHEMCU_2.4GHz_Dual_RX.bin"
                          },
                          {
                            "label": "SX1280 JHEMCU 2.4GHz Lite RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_JHEMCU_2.4GHz_Lite_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_JHEMCU_2.4GHz_Lite_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 Jumper AION Mini 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Jumper_AION_Mini_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Jumper_AION_Mini_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 Jumper AION Nano 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Jumper_AION_Nano_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Jumper_AION_Nano_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 MATEK R24-D 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_MATEK_R24-D_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_MATEK_R24-D_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 MATEK R24-P PWM 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_MATEK_R24-P_PWM_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_MATEK_R24-P_PWM_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 MATEK R24-S 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_MATEK_R24-S_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_MATEK_R24-S_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 NamimnoRC Flash 100mW Diversity 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_NamimnoRC_Flash_100mW_Diversity_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_NamimnoRC_Flash_100mW_Diversity_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 NamimnoRC Flash ESP 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_NamimnoRC_Flash_ESP_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_NamimnoRC_Flash_ESP_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 NewBeeDrone Diversity 2.4Ghz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_NewBeeDrone_Diversity_2.4Ghz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_NewBeeDrone_Diversity_2.4Ghz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 QuadKopters Nano 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_QuadKopters_Nano_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_QuadKopters_Nano_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 RadioMaster ER3C-i 2.4GHz PWM RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_ER3C-i_2.4GHz_PWM_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_RadioMaster_ER3C-i_2.4GHz_PWM_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 RadioMaster ER4 2.4GHz PWM RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_ER4_2.4GHz_PWM_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_RadioMaster_ER4_2.4GHz_PWM_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 RadioMaster ER5A-C 2.4GHz PWM RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_ER5A-C_2.4GHz_PWM_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_RadioMaster_ER5A-C_2.4GHz_PWM_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 RadioMaster ER5A-C V2 2.4GHz PWM RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_ER5A-C_V2_2.4GHz_PWM_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_RadioMaster_ER5A-C_V2_2.4GHz_PWM_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 RadioMaster ER5C-i 2.4GHz PWM RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_ER5C-i_2.4GHz_PWM_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_RadioMaster_ER5C-i_2.4GHz_PWM_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 RadioMaster ER6 2.4GHz Diversity+6xPWM RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_ER6_2.4GHz_Diversity+6xPWM_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_RadioMaster_ER6_2.4GHz_Diversity+6xPWM_RX.bin"
                          },
                          {
                            "label": "SX1280 RadioMaster ER6-G 2.4GHz Diversity+6xPWM RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_ER6-G_2.4GHz_Diversity+6xPWM_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_RadioMaster_ER6-G_2.4GHz_Diversity+6xPWM_RX.bin"
                          },
                          {
                            "label": "SX1280 RadioMaster ER6-GV 2.4GHz Diversity+6xPWM+Vario RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_ER6-GV_2.4GHz_Diversity+6xPWM+Vario_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_RadioMaster_ER6-GV_2.4GHz_Diversity+6xPWM+Vario_RX.bin"
                          },
                          {
                            "label": "SX1280 RadioMaster ER8 2.4GHz Diversity+8xPWM RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_ER8_2.4GHz_Diversity+8xPWM_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_RadioMaster_ER8_2.4GHz_Diversity+8xPWM_RX.bin"
                          },
                          {
                            "label": "SX1280 RadioMaster ER8-G 2.4GHz Diversity+8xPWM RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_ER8-G_2.4GHz_Diversity+8xPWM_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_RadioMaster_ER8-G_2.4GHz_Diversity+8xPWM_RX.bin"
                          },
                          {
                            "label": "SX1280 RadioMaster ER8-GV 2.4GHz Diversity+8xPWM+Vario RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_ER8-GV_2.4GHz_Diversity+8xPWM+Vario_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_RadioMaster_ER8-GV_2.4GHz_Diversity+8xPWM+Vario_RX.bin"
                          },
                          {
                            "label": "SX1280 Radiomaster Nexus-XR True Diversity 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Radiomaster_Nexus-XR_True_Diversity_2.4GHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Radiomaster_Nexus-XR_True_Diversity_2.4GHz_RX.bin"
                          },
                          {
                            "label": "SX1280 RadioMaster RP1 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_RP1_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_RadioMaster_RP1_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 RadioMaster RP2 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_RP2_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_RadioMaster_RP2_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 RadioMaster RP3 Diversity 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_RP3_Diversity_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_RadioMaster_RP3_Diversity_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 Radiomaster RP3-H Diversity 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Radiomaster_RP3-H_Diversity_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Radiomaster_RP3-H_Diversity_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 RadioMaster RP4TD True Diversity 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_RP4TD_True_Diversity_2.4GHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_RadioMaster_RP4TD_True_Diversity_2.4GHz_RX.bin"
                          },
                          {
                            "label": "SX1280 RadioMaster RP4TD-M True Diversity 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_RadioMaster_RP4TD-M_True_Diversity_2.4GHz_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_RadioMaster_RP4TD-M_True_Diversity_2.4GHz_RX.bin"
                          },
                          {
                            "label": "SX1280 SEQURE 2.4GHz Dual RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_SEQURE_2.4GHz_Dual_RX.bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_SEQURE_2.4GHz_Dual_RX.bin"
                          },
                          {
                            "label": "SX1280 SEQURE 2.4GHz Single RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_SEQURE_2.4GHz_Single_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_SEQURE_2.4GHz_Single_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 Skystars SS24D 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Skystars_SS24D_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Skystars_SS24D_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 SpeedyBee Nano 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_SpeedyBee_Nano_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_SpeedyBee_Nano_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 SPRacing RXN1 Gyro 2.4GHz RX-GYRO-IR (D4)",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_SPRacing_RXN1_Gyro_2.4GHz_RX-GYRO-IR_(D4).bin",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_SPRacing_RXN1_Gyro_2.4GHz_RX-GYRO-IR_(D4).bin"
                          },
                          {
                            "label": "SX1280 Squid Stick dongle V2",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Squid_Stick_dongle_V2.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Squid_Stick_dongle_V2.bin.gz"
                          },
                          {
                            "label": "SX1280 Sub250 2400 RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Sub250_2400_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Sub250_2400_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 Sub250 Nano PRO 2.4G RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Sub250_Nano_PRO_2.4G_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Sub250_Nano_PRO_2.4G_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 Vantac 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_Vantac_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_Vantac_2.4GHz_RX.bin.gz"
                          },
                          {
                            "label": "SX1280 ZeroDrag NexusONE 2.4GHz RX",
                            "chip": "SX1280",
                            "version": "RED version 4",
                            "fileName": "R5RC6_ZeroDrag_NexusONE_2.4GHz_RX.bin.gz",
                            "path": "./uprava-firmware/RX/RED-version-4/SX1280/R5RC6_ZeroDrag_NexusONE_2.4GHz_RX.bin.gz"
                          }
                        ]
                },
                {
                    id: "orange-v4",
                    title: "Прошивка Orange version 4",
                    folder: "./uprava-firmware/RX/Orange-version-4",
                    items:                     [
                      {
                        "label": "LR1121 Ariadna R1A1 RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Ariadna_R1A1_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_Ariadna_R1A1_RX.bin"
                      },
                      {
                        "label": "LR1121 B SubGHz RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_B_SubGHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_B_SubGHz_RX.bin"
                      },
                      {
                        "label": "LR1121 BAYCKRC 900-2400 Dual Band Gemini RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BAYCKRC_900-2400_Dual_Band_Gemini_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_BAYCKRC_900-2400_Dual_Band_Gemini_RX.bin"
                      },
                      {
                        "label": "LR1121 BAYCKRC C3 900-2400 Dual Band 100mw 6PWM RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BAYCKRC_C3_900-2400_Dual_Band_100mw_6PWM_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_BAYCKRC_C3_900-2400_Dual_Band_100mw_6PWM_RX.bin"
                      },
                      {
                        "label": "LR1121 BAYCKRC C3 900-2400 Dual Band 100mW Gemini RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BAYCKRC_C3_900-2400_Dual_Band_100mW_Gemini_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_BAYCKRC_C3_900-2400_Dual_Band_100mW_Gemini_RX.bin"
                      },
                      {
                        "label": "LR1121 BAYCKRC C3 900-2400 Dual Band Nano RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BAYCKRC_C3_900-2400_Dual_Band_Nano_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_BAYCKRC_C3_900-2400_Dual_Band_Nano_RX.bin"
                      },
                      {
                        "label": "LR1121 BAYCKRC UR100 Dual Band RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BAYCKRC_UR100_Dual_Band_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_BAYCKRC_UR100_Dual_Band_RX.bin"
                      },
                      {
                        "label": "LR1121 BAYCKRC UR1000 Dual Band RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BAYCKRC_UR1000_Dual_Band_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_BAYCKRC_UR1000_Dual_Band_RX.bin"
                      },
                      {
                        "label": "LR1121 BAYCKRC UR500 Dual Band RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BAYCKRC_UR500_Dual_Band_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_BAYCKRC_UR500_Dual_Band_RX.bin"
                      },
                      {
                        "label": "LR1121 BETAFPV SuperX Mono RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_SuperX_Mono_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_BETAFPV_SuperX_Mono_RX.bin"
                      },
                      {
                        "label": "LR1121 BETAFPV SuperX Nano RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_SuperX_Nano_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_BETAFPV_SuperX_Nano_RX.bin"
                      },
                      {
                        "label": "LR1121 BrotherHobby C3 900-2400 Dual Band 100mW Gemini RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BrotherHobby_C3_900-2400_Dual_Band_100mW_Gemini_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_BrotherHobby_C3_900-2400_Dual_Band_100mW_Gemini_RX.bin"
                      },
                      {
                        "label": "LR1121 CYCLONE C3 LR1121 400 RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_CYCLONE_C3_LR1121_400_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_CYCLONE_C3_LR1121_400_RX.bin"
                      },
                      {
                        "label": "LR1121 CYCLONE XR3 Dual Band Gemini RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_CYCLONE_XR3_Dual_Band_Gemini_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_CYCLONE_XR3_Dual_Band_Gemini_RX.bin"
                      },
                      {
                        "label": "LR1121 CYCLONE XR4 Dual Band Gemini RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_CYCLONE_XR4_Dual_Band_Gemini_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_CYCLONE_XR4_Dual_Band_Gemini_RX.bin"
                      },
                      {
                        "label": "LR1121 DAKEFPV 1W 2.4GHz RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DAKEFPV_1W_2.4GHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_DAKEFPV_1W_2.4GHz_RX.bin"
                      },
                      {
                        "label": "LR1121 DAKEFPV 400MHz RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DAKEFPV_400MHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_DAKEFPV_400MHz_RX.bin"
                      },
                      {
                        "label": "LR1121 DAKEFPV 500mW 2.4GHz RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DAKEFPV_500mW_2.4GHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_DAKEFPV_500mW_2.4GHz_RX.bin"
                      },
                      {
                        "label": "LR1121 DAKEFPV C3 900-2400 Dual Band 100mW Gemini RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DAKEFPV_C3_900-2400_Dual_Band_100mW_Gemini_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_DAKEFPV_C3_900-2400_Dual_Band_100mW_Gemini_RX.bin"
                      },
                      {
                        "label": "LR1121 DAKEFPV Nano 2.4GHz RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DAKEFPV_Nano_2.4GHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_DAKEFPV_Nano_2.4GHz_RX.bin"
                      },
                      {
                        "label": "LR1121 DAKEFPV Nano 900MHz RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DAKEFPV_Nano_900MHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_DAKEFPV_Nano_900MHz_RX.bin"
                      },
                      {
                        "label": "LR1121 DAKEFPV SuperD 2.4GHz RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DAKEFPV_SuperD_2.4GHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_DAKEFPV_SuperD_2.4GHz_RX.bin"
                      },
                      {
                        "label": "LR1121 Edifier 1121R",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Edifier_1121R.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_Edifier_1121R.bin"
                      },
                      {
                        "label": "LR1121 FlyFish 9624R 4ant",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_FlyFish_9624R_4ant.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_FlyFish_9624R_4ant.bin"
                      },
                      {
                        "label": "LR1121 FlyFish 9624R",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_FlyFish_9624R.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_FlyFish_9624R.bin"
                      },
                      {
                        "label": "LR1121 Flytex DB2 Dual Band True Diversity RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Flytex_DB2_Dual_Band_True_Diversity_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_Flytex_DB2_Dual_Band_True_Diversity_RX.bin"
                      },
                      {
                        "label": "LR1121 Gemini C3 XrossBand PA 2.4-900 RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Gemini_C3_XrossBand_PA_2.4-900_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_Gemini_C3_XrossBand_PA_2.4-900_RX.bin"
                      },
                      {
                        "label": "LR1121 Gemini XrossBand PA 2.4-900 RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Gemini_XrossBand_PA_2.4-900_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_Gemini_XrossBand_PA_2.4-900_RX.bin"
                      },
                      {
                        "label": "LR1121 Generic C3 LR1121 2.4-900 PWM RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_C3_LR1121_2.4-900_PWM_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_Generic_C3_LR1121_2.4-900_PWM_RX.bin"
                      },
                      {
                        "label": "LR1121 Generic C3 LR1121 2.4-900 RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_C3_LR1121_2.4-900_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_Generic_C3_LR1121_2.4-900_RX.bin"
                      },
                      {
                        "label": "LR1121 GEPRC 900-2400 Gemini Xrossband RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_GEPRC_900-2400_Gemini_Xrossband_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_GEPRC_900-2400_Gemini_Xrossband_RX.bin"
                      },
                      {
                        "label": "LR1121 GEPRC 900-2400 Single Dual-Band RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_GEPRC_900-2400_Single_Dual-Band_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_GEPRC_900-2400_Single_Dual-Band_RX.bin"
                      },
                      {
                        "label": "LR1121 GEPRC C3 900-2400 Gemini Xrossband RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_GEPRC_C3_900-2400_Gemini_Xrossband_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_GEPRC_C3_900-2400_Gemini_Xrossband_RX.bin"
                      },
                      {
                        "label": "LR1121 HGLRC C3 900-2400 Dual Band Nano RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HGLRC_C3_900-2400_Dual_Band_Nano_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_HGLRC_C3_900-2400_Dual_Band_Nano_RX.bin"
                      },
                      {
                        "label": "LR1121 HGLRC C3 900-2400 Dual Band PRO RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HGLRC_C3_900-2400_Dual_Band_PRO_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_HGLRC_C3_900-2400_Dual_Band_PRO_RX.bin"
                      },
                      {
                        "label": "LR1121 Hobbyporter DBR4",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Hobbyporter_DBR4.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_Hobbyporter_DBR4.bin"
                      },
                      {
                        "label": "LR1121 Holybro Zephyr Dual Band RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Holybro_Zephyr_Dual_Band_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_Holybro_Zephyr_Dual_Band_RX.bin"
                      },
                      {
                        "label": "LR1121 RadioMaster DBR4-TD True Diversity Dual Band RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_DBR4-TD_True_Diversity_Dual_Band_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_RadioMaster_DBR4-TD_True_Diversity_Dual_Band_RX.bin"
                      },
                      {
                        "label": "LR1121 RadioMaster XR1 Dual Band RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_XR1_Dual_Band_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_RadioMaster_XR1_Dual_Band_RX.bin"
                      },
                      {
                        "label": "LR1121 RadioMaster XR2 2.4GHz RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_XR2_2.4GHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_RadioMaster_XR2_2.4GHz_RX.bin"
                      },
                      {
                        "label": "LR1121 RadioMaster XR3 Dual Band Diversity RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_XR3_Dual_Band_Diversity_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_RadioMaster_XR3_Dual_Band_Diversity_RX.bin"
                      },
                      {
                        "label": "LR1121 RadioMaster XR4 Dual Band True Diversity RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_XR4_Dual_Band_True_Diversity_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_RadioMaster_XR4_Dual_Band_True_Diversity_RX.bin"
                      },
                      {
                        "label": "LR1121 SE4 900-2400 Dual Band Xross Gemini RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_SE4_900-2400_Dual_Band_Xross_Gemini_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_SE4_900-2400_Dual_Band_Xross_Gemini_RX.bin"
                      },
                      {
                        "label": "LR1121 Skopa RX V1.1",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Skopa_RX_V1.1.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_Skopa_RX_V1.1.bin"
                      },
                      {
                        "label": "LR1121 Spedix Dual Band RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Spedix_Dual_Band_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_Spedix_Dual_Band_RX.bin"
                      },
                      {
                        "label": "LR1121 Sub250 900-2400 Single Dual-Band RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Sub250_900-2400_Single_Dual-Band_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_Sub250_900-2400_Single_Dual-Band_RX.bin"
                      },
                      {
                        "label": "LR1121 THOBBY Dual Band RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_THOBBY_Dual_Band_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_THOBBY_Dual_Band_RX.bin"
                      },
                      {
                        "label": "LR1121 ZRX Dual RX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_ZRX_Dual_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/LR1121/OR5b4_ZRX_Dual_RX.bin"
                      },
                      {
                        "label": "SX1276 BAYCKRC 900MHz Dual Core RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BAYCKRC_900MHz_Dual_Core_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_BAYCKRC_900MHz_Dual_Core_RX.bin"
                      },
                      {
                        "label": "SX1276 BAYCKRC 900MHz Nano RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BAYCKRC_900MHz_Nano_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_BAYCKRC_900MHz_Nano_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 BeastFPV 750MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BeastFPV_750MHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_BeastFPV_750MHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 BelinRC 433MHZ RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BelinRC_433MHZ_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_BelinRC_433MHZ_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 BETAFPV 400MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_400MHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_BETAFPV_400MHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 BETAFPV 900MHz Nano RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_900MHz_Nano_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_BETAFPV_900MHz_Nano_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 BETAFPV SuperD 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_SuperD_900MHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_BETAFPV_SuperD_900MHz_RX.bin"
                      },
                      {
                        "label": "SX1276 BETAFPV SuperP 14Ch 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_SuperP_14Ch_900MHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_BETAFPV_SuperP_14Ch_900MHz_RX.bin"
                      },
                      {
                        "label": "SX1276 BETAFPV SuperP TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_SuperP_TX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_BETAFPV_SuperP_TX.bin"
                      },
                      {
                        "label": "SX1276 BrotherHobby 900MHz Nano RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BrotherHobby_900MHz_Nano_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_BrotherHobby_900MHz_Nano_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 CYCLONE 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_CYCLONE_900MHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_CYCLONE_900MHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 DISRC 433MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DISRC_433MHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_DISRC_433MHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 DIY Huzzah RFM95 900MHz TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DIY_Huzzah_RFM95_900MHz_TX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_DIY_Huzzah_RFM95_900MHz_TX.bin.gz"
                      },
                      {
                        "label": "SX1276 DIY TTGO V1 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DIY_TTGO_V1_900MHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_DIY_TTGO_V1_900MHz_RX.bin"
                      },
                      {
                        "label": "SX1276 DIY TTGO V2 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DIY_TTGO_V2_900MHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_DIY_TTGO_V2_900MHz_RX.bin"
                      },
                      {
                        "label": "SX1276 Edifier 433RX True Diversity",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Edifier_433RX_True_Diversity.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_Edifier_433RX_True_Diversity.bin"
                      },
                      {
                        "label": "SX1276 EMAX 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_EMAX_900MHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_EMAX_900MHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 FlyFish 433M RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_FlyFish_433M_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_FlyFish_433M_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 FlyFish 515MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_FlyFish_515MHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_FlyFish_515MHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 Foxeer 786MHz True Diversity RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Foxeer_786MHz_True_Diversity_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_Foxeer_786MHz_True_Diversity_RX.bin"
                      },
                      {
                        "label": "SX1276 Foxeer 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Foxeer_900MHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_Foxeer_900MHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 Foxeer 900MHz True Diversity RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Foxeer_900MHz_True_Diversity_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_Foxeer_900MHz_True_Diversity_RX.bin"
                      },
                      {
                        "label": "SX1276 Foxeer Diversity 400MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Foxeer_Diversity_400MHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_Foxeer_Diversity_400MHz_RX.bin"
                      },
                      {
                        "label": "SX1276 Generic ESP32 True Diversity 16xPWM 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP32_True_Diversity_16xPWM_900MHz_RX_.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_Generic_ESP32_True_Diversity_16xPWM_900MHz_RX_.bin"
                      },
                      {
                        "label": "SX1276 Generic ESP32 True Diversity 900MHz 500mW RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP32_True_Diversity_900MHz_500mW_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_Generic_ESP32_True_Diversity_900MHz_500mW_RX.bin"
                      },
                      {
                        "label": "SX1276 Generic ESP32 True Diversity 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP32_True_Diversity_900MHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_Generic_ESP32_True_Diversity_900MHz_RX.bin"
                      },
                      {
                        "label": "SX1276 Generic ESP8285 SX127x 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP8285_SX127x_900MHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_Generic_ESP8285_SX127x_900MHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 Generic ESP8285 SX127x with PWM 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP8285_SX127x_with_PWM_900MHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_Generic_ESP8285_SX127x_with_PWM_900MHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 GEPRC Nano 900MHz PA500 RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_GEPRC_Nano_900MHz_PA500_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_GEPRC_Nano_900MHz_PA500_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 GEPRC Nano 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_GEPRC_Nano_900MHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_GEPRC_Nano_900MHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 GEPRC True Diversity 900MHz PA500 RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_GEPRC_True_Diversity_900MHz_PA500_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_GEPRC_True_Diversity_900MHz_PA500_RX.bin"
                      },
                      {
                        "label": "SX1276 GEPRC True Diversity 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_GEPRC_True_Diversity_900MHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_GEPRC_True_Diversity_900MHz_RX.bin"
                      },
                      {
                        "label": "SX1276 HAOYERC 900MHz Nano RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HAOYERC_900MHz_Nano_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_HAOYERC_900MHz_Nano_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 HappyModel EPW6 PWM RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HappyModel_EPW6_PWM_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_HappyModel_EPW6_PWM_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 HappyModel ES900 Dual RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HappyModel_ES900_Dual_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_HappyModel_ES900_Dual_RX.bin"
                      },
                      {
                        "label": "SX1276 HappyModel ES900 RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HappyModel_ES900_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_HappyModel_ES900_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 HGLRC Gemini 900M RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HGLRC_Gemini_900M_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_HGLRC_Gemini_900M_RX.bin"
                      },
                      {
                        "label": "SX1276 HGLRC Hermes 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HGLRC_Hermes_900MHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_HGLRC_Hermes_900MHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 iFlight 900MHz 500mW Diversity RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_iFlight_900MHz_500mW_Diversity_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_iFlight_900MHz_500mW_Diversity_RX.bin"
                      },
                      {
                        "label": "SX1276 iFlight 900MHz 500mW RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_iFlight_900MHz_500mW_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_iFlight_900MHz_500mW_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 iFlight 900MHz Nano RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_iFlight_900MHz_Nano_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_iFlight_900MHz_Nano_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 iFlight 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_iFlight_900MHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_iFlight_900MHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 JHEMCU 900RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_JHEMCU_900RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_JHEMCU_900RX.bin.gz"
                      },
                      {
                        "label": "SX1276 Jumper AION Mini 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_AION_Mini_900MHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_Jumper_AION_Mini_900MHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 NamimnoRC Voyager ESP 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_NamimnoRC_Voyager_ESP_900MHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_NamimnoRC_Voyager_ESP_900MHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 NeutronRC 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_NeutronRC_900MHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_NeutronRC_900MHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 RadioMaster Bandit Nano-Micro 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_Bandit_Nano-Micro_900MHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_RadioMaster_Bandit_Nano-Micro_900MHz_RX.bin"
                      },
                      {
                        "label": "SX1276 RadioMaster BR1 900Mz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_BR1_900Mz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_RadioMaster_BR1_900Mz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 RadioMaster BR3 Diversity 900Mz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_BR3_Diversity_900Mz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_RadioMaster_BR3_Diversity_900Mz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 RadioMaster BR4TD 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_BR4TD_900MHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_RadioMaster_BR4TD_900MHz_RX.bin"
                      },
                      {
                        "label": "SX1276 Raduga RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Raduga_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_Raduga_RX.bin"
                      },
                      {
                        "label": "SX1276 SEQURE 900MHz Dual RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_SEQURE_900MHz_Dual_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_SEQURE_900MHz_Dual_RX.bin"
                      },
                      {
                        "label": "SX1276 Spedix 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Spedix_900MHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_Spedix_900MHz_RX.bin"
                      },
                      {
                        "label": "SX1276 SpeedyBee Nano 915MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_SpeedyBee_Nano_915MHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_SpeedyBee_Nano_915MHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 STELLAR 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_STELLAR_900MHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_STELLAR_900MHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 TBS Crossfire XF Nano 50 RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_TBS_Crossfire_XF_Nano_50_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_TBS_Crossfire_XF_Nano_50_RX.bin"
                      },
                      {
                        "label": "SX1276 THOBBY 900MHz RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_THOBBY_900MHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_THOBBY_900MHz_RX.bin"
                      },
                      {
                        "label": "SX1276 Upyr dual RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Upyr_dual_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_Upyr_dual_RX.bin"
                      },
                      {
                        "label": "SX1276 Zhmil 370M RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Zhmil_370M_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_Zhmil_370M_RX.bin.gz"
                      },
                      {
                        "label": "SX1276 Zhmil 700M TD RX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Zhmil_700M_TD_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_Zhmil_700M_TD_RX.bin"
                      },
                      {
                        "label": "SX1276 ZOV RX 520MHz",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_ZOV_RX_520MHz.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1276/OR5b4_ZOV_RX_520MHz.bin"
                      },
                      {
                        "label": "SX1280 Anyleaf 2.4GHz dual radio RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Anyleaf_2.4GHz_dual_radio_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Anyleaf_2.4GHz_dual_radio_RX.bin"
                      },
                      {
                        "label": "SX1280 Anyleaf 2.4GHz single radio RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Anyleaf_2.4GHz_single_radio_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Anyleaf_2.4GHz_single_radio_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 Anyleaf FC integrated RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Anyleaf_FC_integrated_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Anyleaf_FC_integrated_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 atomrc 2.4G RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_atomrc_2.4G_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_atomrc_2.4G_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 AXIS Thor 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_AXIS_Thor_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_AXIS_Thor_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 BAYCKRC 2.4GHz Dual Core RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BAYCKRC_2.4GHz_Dual_Core_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_BAYCKRC_2.4GHz_Dual_Core_RX.bin"
                      },
                      {
                        "label": "SX1280 BAYCKRC 2.4GHz Nano RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BAYCKRC_2.4GHz_Nano_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_BAYCKRC_2.4GHz_Nano_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 BeastFPV 2.1GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BeastFPV_2.1GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_BeastFPV_2.1GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 BETAFPV 2.4GHz AIO RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_2.4GHz_AIO_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_BETAFPV_2.4GHz_AIO_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 BETAFPV 2.4GHz Lite RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_2.4GHz_Lite_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_BETAFPV_2.4GHz_Lite_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 BETAFPV 2.4GHz Nano RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_2.4GHz_Nano_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_BETAFPV_2.4GHz_Nano_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 BETAFPV PWM 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_PWM_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_BETAFPV_PWM_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 BETAFPV SuperD 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_SuperD_2.4GHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_BETAFPV_SuperD_2.4GHz_RX.bin"
                      },
                      {
                        "label": "SX1280 BETAFPV SuperP 14Ch 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_SuperP_14Ch_2.4GHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_BETAFPV_SuperP_14Ch_2.4GHz_RX.bin"
                      },
                      {
                        "label": "SX1280 BrotherHobby 2.4GHz Nano RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BrotherHobby_2.4GHz_Nano_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_BrotherHobby_2.4GHz_Nano_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 CYCLONE 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_CYCLONE_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_CYCLONE_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 EMAX 2.4GHz PA RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_EMAX_2.4GHz_PA_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_EMAX_2.4GHz_PA_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 EMAX 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_EMAX_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_EMAX_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 FD R24D 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_FD_R24D_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_FD_R24D_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 FlyFish MC2R4",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_FlyFish_MC2R4.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_FlyFish_MC2R4.bin.gz"
                      },
                      {
                        "label": "SX1280 FlyFish RD2R4",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_FlyFish_RD2R4.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_FlyFish_RD2R4.bin.gz"
                      },
                      {
                        "label": "SX1280 Flywoo EL24E TCXO 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Flywoo_EL24E_TCXO_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Flywoo_EL24E_TCXO_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 Flywoo EL24P TCXO 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Flywoo_EL24P_TCXO_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Flywoo_EL24P_TCXO_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 Foxeer 2.4Ghz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Foxeer_2.4Ghz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Foxeer_2.4Ghz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 Foxeer Lite 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Foxeer_Lite_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Foxeer_Lite_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 Generic ESP32 2.4Ghz Franken RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP32_2.4Ghz_Franken_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Generic_ESP32_2.4Ghz_Franken_RX.bin"
                      },
                      {
                        "label": "SX1280 Generic ESP32 2.4Ghz Rx and VTx",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP32_2.4Ghz_Rx_and_VTx.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Generic_ESP32_2.4Ghz_Rx_and_VTx.bin"
                      },
                      {
                        "label": "SX1280 Generic ESP32 PWM Vario 2.4Ghz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP32_PWM_Vario_2.4Ghz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Generic_ESP32_PWM_Vario_2.4Ghz_RX.bin"
                      },
                      {
                        "label": "SX1280 Generic ESP32 True Diversity 16xPWM 2.4Ghz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP32_True_Diversity_16xPWM_2.4Ghz_RX_.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Generic_ESP32_True_Diversity_16xPWM_2.4Ghz_RX_.bin"
                      },
                      {
                        "label": "SX1280 Generic ESP32 True Diversity 2.4Ghz RX and VTx",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP32_True_Diversity_2.4Ghz_RX_and_VTx.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Generic_ESP32_True_Diversity_2.4Ghz_RX_and_VTx.bin"
                      },
                      {
                        "label": "SX1280 Generic ESP32 True Diversity PA 14xPWM 2.4Ghz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP32_True_Diversity_PA_14xPWM_2.4Ghz_RX_.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Generic_ESP32_True_Diversity_PA_14xPWM_2.4Ghz_RX_.bin"
                      },
                      {
                        "label": "SX1280 Generic ESP32 True Diversity PA 2.4Ghz RX and VTx",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP32_True_Diversity_PA_2.4Ghz_RX_and_VTx.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Generic_ESP32_True_Diversity_PA_2.4Ghz_RX_and_VTx.bin"
                      },
                      {
                        "label": "SX1280 Generic ESP32 True Diversity PA 2.4Ghz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP32_True_Diversity_PA_2.4Ghz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Generic_ESP32_True_Diversity_PA_2.4Ghz_RX.bin"
                      },
                      {
                        "label": "SX1280 Generic ESP8285 2.4Ghz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP8285_2.4Ghz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Generic_ESP8285_2.4Ghz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 Generic ESP8285 5xPWM 2.4Ghz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP8285_5xPWM_2.4Ghz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Generic_ESP8285_5xPWM_2.4Ghz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 Generic ESP8285 6xPWM 2.4Ghz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP8285_6xPWM_2.4Ghz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Generic_ESP8285_6xPWM_2.4Ghz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 Generic ESP8285 7xPWM 2.4Ghz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP8285_7xPWM_2.4Ghz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Generic_ESP8285_7xPWM_2.4Ghz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 Generic ESP8285 Diversity PA 2.4Ghz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP8285_Diversity_PA_2.4Ghz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Generic_ESP8285_Diversity_PA_2.4Ghz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 Generic ESP8285 PA 2.4Ghz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP8285_PA_2.4Ghz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Generic_ESP8285_PA_2.4Ghz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 Generic ESP8285 RGB + PA 2.4Ghz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP8285_RGB_+_PA_2.4Ghz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Generic_ESP8285_RGB_+_PA_2.4Ghz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 GEPRC Nano 2.4GHz PA100 RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_GEPRC_Nano_2.4GHz_PA100_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_GEPRC_Nano_2.4GHz_PA100_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 GEPRC Nano(SE) 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_GEPRC_Nano(SE)_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_GEPRC_Nano(SE)_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 GEPRC True Diversity 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_GEPRC_True_Diversity_2.4GHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_GEPRC_True_Diversity_2.4GHz_RX.bin"
                      },
                      {
                        "label": "SX1280 HappyModel AIO 2.4GHz RX+VTX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HappyModel_AIO_2.4GHz_RX+VTX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_HappyModel_AIO_2.4GHz_RX+VTX.bin"
                      },
                      {
                        "label": "SX1280 HappyModel EP Dual 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HappyModel_EP_Dual_2.4GHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_HappyModel_EP_Dual_2.4GHz_RX.bin"
                      },
                      {
                        "label": "SX1280 HappyModel EP1-EP2 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HappyModel_EP1-EP2_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_HappyModel_EP1-EP2_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 HappyModel EPW5 2.4GHz PWM RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HappyModel_EPW5_2.4GHz_PWM_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_HappyModel_EPW5_2.4GHz_PWM_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 HappyModel EPW6 2.4GHz PWM RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HappyModel_EPW6_2.4GHz_PWM_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_HappyModel_EPW6_2.4GHz_PWM_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 HelloRadio HR7E 2.4GHz Diversity+7xPWM RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HelloRadio_HR7E_2.4GHz_Diversity+7xPWM_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_HelloRadio_HR7E_2.4GHz_Diversity+7xPWM_RX.bin"
                      },
                      {
                        "label": "SX1280 HelloRadio HR8E 2.4GHz Diversity+8xPWM RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HelloRadio_HR8E_2.4GHz_Diversity+8xPWM_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_HelloRadio_HR8E_2.4GHz_Diversity+8xPWM_RX.bin"
                      },
                      {
                        "label": "SX1280 HelloRadio HR8E TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HelloRadio_HR8E_TX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_HelloRadio_HR8E_TX.bin"
                      },
                      {
                        "label": "SX1280 HGLRC Gemini 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HGLRC_Gemini_2.4GHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_HGLRC_Gemini_2.4GHz_RX.bin"
                      },
                      {
                        "label": "SX1280 HGLRC Hermes 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HGLRC_Hermes_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_HGLRC_Hermes_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 iFlight 2.4GHz 250mW Diversity RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_iFlight_2.4GHz_250mW_Diversity_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_iFlight_2.4GHz_250mW_Diversity_RX.bin"
                      },
                      {
                        "label": "SX1280 iFlight 2.4GHz 500mW RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_iFlight_2.4GHz_500mW_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_iFlight_2.4GHz_500mW_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 iFlight 2.4GHz Nano RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_iFlight_2.4GHz_Nano_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_iFlight_2.4GHz_Nano_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 iFlight 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_iFlight_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_iFlight_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 JHEMCU 2.4GHz Dual RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_JHEMCU_2.4GHz_Dual_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_JHEMCU_2.4GHz_Dual_RX.bin"
                      },
                      {
                        "label": "SX1280 JHEMCU 2.4GHz Lite RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_JHEMCU_2.4GHz_Lite_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_JHEMCU_2.4GHz_Lite_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 Jumper AION Mini 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_AION_Mini_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Jumper_AION_Mini_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 Jumper AION Nano 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_AION_Nano_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Jumper_AION_Nano_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 MATEK R24-D 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_MATEK_R24-D_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_MATEK_R24-D_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 MATEK R24-P PWM 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_MATEK_R24-P_PWM_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_MATEK_R24-P_PWM_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 MATEK R24-S 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_MATEK_R24-S_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_MATEK_R24-S_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 NamimnoRC Flash 100mW Diversity 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_NamimnoRC_Flash_100mW_Diversity_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_NamimnoRC_Flash_100mW_Diversity_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 NamimnoRC Flash ESP 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_NamimnoRC_Flash_ESP_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_NamimnoRC_Flash_ESP_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 NewBeeDrone Diversity 2.4Ghz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_NewBeeDrone_Diversity_2.4Ghz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_NewBeeDrone_Diversity_2.4Ghz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 QuadKopters Nano 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_QuadKopters_Nano_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_QuadKopters_Nano_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 RadioMaster ER3C-i 2.4GHz PWM RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_ER3C-i_2.4GHz_PWM_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_RadioMaster_ER3C-i_2.4GHz_PWM_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 RadioMaster ER4 2.4GHz PWM RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_ER4_2.4GHz_PWM_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_RadioMaster_ER4_2.4GHz_PWM_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 RadioMaster ER5A-C 2.4GHz PWM RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_ER5A-C_2.4GHz_PWM_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_RadioMaster_ER5A-C_2.4GHz_PWM_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 RadioMaster ER5A-C V2 2.4GHz PWM RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_ER5A-C_V2_2.4GHz_PWM_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_RadioMaster_ER5A-C_V2_2.4GHz_PWM_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 RadioMaster ER5C-i 2.4GHz PWM RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_ER5C-i_2.4GHz_PWM_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_RadioMaster_ER5C-i_2.4GHz_PWM_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 RadioMaster ER6 2.4GHz Diversity+6xPWM RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_ER6_2.4GHz_Diversity+6xPWM_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_RadioMaster_ER6_2.4GHz_Diversity+6xPWM_RX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster ER6-G 2.4GHz Diversity+6xPWM RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_ER6-G_2.4GHz_Diversity+6xPWM_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_RadioMaster_ER6-G_2.4GHz_Diversity+6xPWM_RX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster ER6-GV 2.4GHz Diversity+6xPWM+Vario RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_ER6-GV_2.4GHz_Diversity+6xPWM+Vario_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_RadioMaster_ER6-GV_2.4GHz_Diversity+6xPWM+Vario_RX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster ER8 2.4GHz Diversity+8xPWM RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_ER8_2.4GHz_Diversity+8xPWM_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_RadioMaster_ER8_2.4GHz_Diversity+8xPWM_RX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster ER8-G 2.4GHz Diversity+8xPWM RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_ER8-G_2.4GHz_Diversity+8xPWM_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_RadioMaster_ER8-G_2.4GHz_Diversity+8xPWM_RX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster ER8-GV 2.4GHz Diversity+8xPWM+Vario RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_ER8-GV_2.4GHz_Diversity+8xPWM+Vario_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_RadioMaster_ER8-GV_2.4GHz_Diversity+8xPWM+Vario_RX.bin"
                      },
                      {
                        "label": "SX1280 Radiomaster Nexus-XR True Diversity 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Radiomaster_Nexus-XR_True_Diversity_2.4GHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Radiomaster_Nexus-XR_True_Diversity_2.4GHz_RX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster RP1 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_RP1_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_RadioMaster_RP1_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 RadioMaster RP2 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_RP2_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_RadioMaster_RP2_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 RadioMaster RP3 Diversity 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_RP3_Diversity_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_RadioMaster_RP3_Diversity_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 Radiomaster RP3-H Diversity 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Radiomaster_RP3-H_Diversity_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Radiomaster_RP3-H_Diversity_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 RadioMaster RP4TD True Diversity 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_RP4TD_True_Diversity_2.4GHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_RadioMaster_RP4TD_True_Diversity_2.4GHz_RX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster RP4TD-M True Diversity 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_RP4TD-M_True_Diversity_2.4GHz_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_RadioMaster_RP4TD-M_True_Diversity_2.4GHz_RX.bin"
                      },
                      {
                        "label": "SX1280 SEQURE 2.4GHz Dual RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_SEQURE_2.4GHz_Dual_RX.bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_SEQURE_2.4GHz_Dual_RX.bin"
                      },
                      {
                        "label": "SX1280 SEQURE 2.4GHz Single RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_SEQURE_2.4GHz_Single_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_SEQURE_2.4GHz_Single_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 Skystars SS24D 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Skystars_SS24D_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Skystars_SS24D_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 SpeedyBee Nano 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_SpeedyBee_Nano_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_SpeedyBee_Nano_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 SPRacing RXN1 Gyro 2.4GHz RX-GYRO-IR (D4)",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_SPRacing_RXN1_Gyro_2.4GHz_RX-GYRO-IR_(D4).bin",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_SPRacing_RXN1_Gyro_2.4GHz_RX-GYRO-IR_(D4).bin"
                      },
                      {
                        "label": "SX1280 Squid Stick dongle V2",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Squid_Stick_dongle_V2.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Squid_Stick_dongle_V2.bin.gz"
                      },
                      {
                        "label": "SX1280 Sub250 2400 RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Sub250_2400_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Sub250_2400_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 Sub250 Nano PRO 2.4G RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Sub250_Nano_PRO_2.4G_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Sub250_Nano_PRO_2.4G_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 Vantac 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Vantac_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_Vantac_2.4GHz_RX.bin.gz"
                      },
                      {
                        "label": "SX1280 ZeroDrag NexusONE 2.4GHz RX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_ZeroDrag_NexusONE_2.4GHz_RX.bin.gz",
                        "path": "./uprava-firmware/RX/Orange-version-4/SX1280/OR5b4_ZeroDrag_NexusONE_2.4GHz_RX.bin.gz"
                      }
                    ]
                }
            ]
        },
        {
            id: "tx",
            title: "Передатчик (TX)",
            groups: [
                {
                    id: "tx-red-v4",
                    title: "Прошивка RED version 4",
                    folder: "./uprava-firmware/TX/RED-version-4",
                    items: [
                      {
                        "label": "LR1121 B SubGHz TX 2W board 1.1",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_B_SubGHz_TX_2W_board_1.1.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_B_SubGHz_TX_2W_board_1.1.bin"
                      },
                      {
                        "label": "LR1121 B SubGHz TX 2W",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_B_SubGHz_TX_2W.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_B_SubGHz_TX_2W.bin"
                      },
                      {
                        "label": "LR1121 BAYCKRC 900-2400 Dual Band 1W Micro Gemini TX",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BAYCKRC_900-2400_Dual_Band_1W_Micro_Gemini_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_BAYCKRC_900-2400_Dual_Band_1W_Micro_Gemini_TX.bin"
                      },
                      {
                        "label": "LR1121 BAYCKRC 900-2400 Dual Band 1W Nano Gemini TX",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BAYCKRC_900-2400_Dual_Band_1W_Nano_Gemini_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_BAYCKRC_900-2400_Dual_Band_1W_Nano_Gemini_TX.bin"
                      },
                      {
                        "label": "LR1121 BAYCKRC 900-2400 Dual Band 1W Nano TX",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BAYCKRC_900-2400_Dual_Band_1W_Nano_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_BAYCKRC_900-2400_Dual_Band_1W_Nano_TX.bin"
                      },
                      {
                        "label": "LR1121 CYCLONE LR1121 TX board 1.2",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_CYCLONE_LR1121_TX_board_1.2.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_CYCLONE_LR1121_TX_board_1.2.bin"
                      },
                      {
                        "label": "LR1121 CYCLONE LR1121 TX board 2.0",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_CYCLONE_LR1121_TX_board_2.0.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_CYCLONE_LR1121_TX_board_2.0.bin"
                      },
                      {
                        "label": "LR1121 DISRC 2.4GHz TX",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_DISRC_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_DISRC_2.4GHz_TX.bin"
                      },
                      {
                        "label": "LR1121 Edifier LR1121 TX",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Edifier_LR1121_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_Edifier_LR1121_TX.bin"
                      },
                      {
                        "label": "LR1121 Edifier LR1520 TX",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Edifier_LR1520_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_Edifier_LR1520_TX.bin"
                      },
                      {
                        "label": "LR1121 Gemini XrossBand 2.4-900 TX",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Gemini_XrossBand_2.4-900_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_Gemini_XrossBand_2.4-900_TX.bin"
                      },
                      {
                        "label": "LR1121 GEPRC LINKFLOW 900-2400 Dual-Band TX",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_GEPRC_LINKFLOW_900-2400_Dual-Band_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_GEPRC_LINKFLOW_900-2400_Dual-Band_TX.bin"
                      },
                      {
                        "label": "LR1121 RadioMaster 300-TX",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RadioMaster_300-TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_RadioMaster_300-TX.bin"
                      },
                      {
                        "label": "LR1121 RadioMaster GX12 2.4-900 TX",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RadioMaster_GX12_2.4-900_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_RadioMaster_GX12_2.4-900_TX.bin"
                      },
                      {
                        "label": "LR1121 RadioMaster Nomad 2.4-900 TX",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RadioMaster_Nomad_2.4-900_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_RadioMaster_Nomad_2.4-900_TX.bin"
                      },
                      {
                        "label": "LR1121 RadioMaster TX15 2.4-900 TX",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RadioMaster_TX15_2.4-900_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_RadioMaster_TX15_2.4-900_TX.bin"
                      },
                      {
                        "label": "LR1121 XFly FF1027",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_XFly_FF1027.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_XFly_FF1027.bin"
                      },
                      {
                        "label": "LR1121 XFly FF36-FF610",
                        "chip": "LR1121",
                        "version": "RED version 4",
                        "fileName": "R5RC6_XFly_FF36-FF610.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/LR1121/R5RC6_XFly_FF36-FF610.bin"
                      },
                      {
                        "label": "SX1262 ASN 220MHz Micro TX",
                        "chip": "SX1262",
                        "version": "RED version 4",
                        "fileName": "R5RC6_ASN_220MHz_Micro_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1262/R5RC6_ASN_220MHz_Micro_TX.bin"
                      },
                      {
                        "label": "SX1262 ASN 280MHz Micro TX",
                        "chip": "SX1262",
                        "version": "RED version 4",
                        "fileName": "R5RC6_ASN_280MHz_Micro_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1262/R5RC6_ASN_280MHz_Micro_TX.bin"
                      },
                      {
                        "label": "SX1262 Kvant SubGHz",
                        "chip": "SX1262",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Kvant_SubGHz.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1262/R5RC6_Kvant_SubGHz.bin"
                      },
                      {
                        "label": "SX1262 RMRLS TX",
                        "chip": "SX1262",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RMRLS_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1262/R5RC6_RMRLS_TX.bin"
                      },
                      {
                        "label": "SX1262 ZTX",
                        "chip": "SX1262",
                        "version": "RED version 4",
                        "fileName": "R5RC6_ZTX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1262/R5RC6_ZTX.bin"
                      },
                      {
                        "label": "SX1276 BeastFPV 750MHz TX V1",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BeastFPV_750MHz_TX_V1.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_BeastFPV_750MHz_TX_V1.bin"
                      },
                      {
                        "label": "SX1276 BeastFPV 750MHz TX V2",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BeastFPV_750MHz_TX_V2.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_BeastFPV_750MHz_TX_V2.bin"
                      },
                      {
                        "label": "SX1276 BelinRC 433MHZ TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BelinRC_433MHZ_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_BelinRC_433MHZ_TX.bin"
                      },
                      {
                        "label": "SX1276 BelinRC 750MHZ TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BelinRC_750MHZ_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_BelinRC_750MHZ_TX.bin"
                      },
                      {
                        "label": "SX1276 BETAFPV 370-420MHz Micro TX board 1.1",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BETAFPV_370-420MHz_Micro_TX_board_1.1.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_BETAFPV_370-420MHz_Micro_TX_board_1.1.bin"
                      },
                      {
                        "label": "SX1276 BETAFPV 400MHz Micro TX board 1.0",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BETAFPV_400MHz_Micro_TX_board_1.0.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_BETAFPV_400MHz_Micro_TX_board_1.0.bin"
                      },
                      {
                        "label": "SX1276 BETAFPV 500-560MHz Micro TX board 1.1",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BETAFPV_500-560MHz_Micro_TX_board_1.1.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_BETAFPV_500-560MHz_Micro_TX_board_1.1.bin"
                      },
                      {
                        "label": "SX1276 BETAFPV 900MHz Micro TX V2",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BETAFPV_900MHz_Micro_TX_V2.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_BETAFPV_900MHz_Micro_TX_V2.bin"
                      },
                      {
                        "label": "SX1276 BETAFPV 900MHz Micro TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BETAFPV_900MHz_Micro_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_BETAFPV_900MHz_Micro_TX.bin"
                      },
                      {
                        "label": "SX1276 BETAFPV 900MHz Nano TX V2",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BETAFPV_900MHz_Nano_TX_V2.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_BETAFPV_900MHz_Nano_TX_V2.bin"
                      },
                      {
                        "label": "SX1276 BETAFPV 900MHz Nano TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BETAFPV_900MHz_Nano_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_BETAFPV_900MHz_Nano_TX.bin"
                      },
                      {
                        "label": "SX1276 CEKTOP TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_CEKTOP_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_CEKTOP_TX.bin"
                      },
                      {
                        "label": "SX1276 CYCLONE 900MHz Micro TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_CYCLONE_900MHz_Micro_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_CYCLONE_900MHz_Micro_TX.bin"
                      },
                      {
                        "label": "SX1276 CYCLONE SX1276 TX400 board 1.0",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_CYCLONE_SX1276_TX400_board_1.0.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_CYCLONE_SX1276_TX400_board_1.0.bin"
                      },
                      {
                        "label": "SX1276 CYCLONE SX1276 TX400 board 2.0",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_CYCLONE_SX1276_TX400_board_2.0.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_CYCLONE_SX1276_TX400_board_2.0.bin"
                      },
                      {
                        "label": "SX1276 DAKEFPV 433MHz Micro MAX 2W TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_DAKEFPV_433MHz_Micro_MAX_2W_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_DAKEFPV_433MHz_Micro_MAX_2W_TX.bin"
                      },
                      {
                        "label": "SX1276 DISRC TX 433 v2",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_DISRC_TX_433_v2.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_DISRC_TX_433_v2.bin"
                      },
                      {
                        "label": "SX1276 DIY ESP32 E19 900MHz TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_DIY_ESP32_E19_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_DIY_ESP32_E19_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 DIY ESP32 RFM95 900MHz TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_DIY_ESP32_RFM95_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_DIY_ESP32_RFM95_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 DIY TTGO V1 900MHz TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_DIY_TTGO_V1_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_DIY_TTGO_V1_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 DIY TTGO V2 900MHz TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_DIY_TTGO_V2_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_DIY_TTGO_V2_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 Edifier OLED 433MHz TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Edifier_OLED_433MHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_Edifier_OLED_433MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 EMAX Nano 900MHz TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_EMAX_Nano_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_EMAX_Nano_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 EMAX OLED 900MHz TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_EMAX_OLED_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_EMAX_OLED_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 FlyFish 150MHz TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_FlyFish_150MHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_FlyFish_150MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 FlyFish 500MHz TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_FlyFish_500MHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_FlyFish_500MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 FOXEER OLED 790MHz TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_FOXEER_OLED_790MHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_FOXEER_OLED_790MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 Generic ESP32 900MHz Gemini TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Generic_ESP32_900MHz_Gemini_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_Generic_ESP32_900MHz_Gemini_TX.bin"
                      },
                      {
                        "label": "SX1276 GEPRC LINKFLOW 900M TX V2",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_GEPRC_LINKFLOW_900M_TX_V2.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_GEPRC_LINKFLOW_900M_TX_V2.bin"
                      },
                      {
                        "label": "SX1276 GEPRC LINKFLOW 900M TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_GEPRC_LINKFLOW_900M_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_GEPRC_LINKFLOW_900M_TX.bin"
                      },
                      {
                        "label": "SX1276 HappyModel ES900 Max TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_HappyModel_ES900_Max_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_HappyModel_ES900_Max_TX.bin"
                      },
                      {
                        "label": "SX1276 HappyModel ES900 TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_HappyModel_ES900_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_HappyModel_ES900_TX.bin"
                      },
                      {
                        "label": "SX1276 HGLRC OLED 900MHz TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_HGLRC_OLED_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_HGLRC_OLED_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 iFlight 900MHz TX V2",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_iFlight_900MHz_TX_V2.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_iFlight_900MHz_TX_V2.bin"
                      },
                      {
                        "label": "SX1276 iFlight 900MHz TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_iFlight_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_iFlight_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 Jumper AION T-14 900M TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Jumper_AION_T-14_900M_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_Jumper_AION_T-14_900M_TX.bin"
                      },
                      {
                        "label": "SX1276 Jumper AION T-15 900M TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Jumper_AION_T-15_900M_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_Jumper_AION_T-15_900M_TX.bin"
                      },
                      {
                        "label": "SX1276 Jumper AION T-20 900M TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Jumper_AION_T-20_900M_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_Jumper_AION_T-20_900M_TX.bin"
                      },
                      {
                        "label": "SX1276 Jumper AION T-20 900M V2 TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Jumper_AION_T-20_900M_V2_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_Jumper_AION_T-20_900M_V2_TX.bin"
                      },
                      {
                        "label": "SX1276 Jumper T-Pro 900M TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Jumper_T-Pro_900M_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_Jumper_T-Pro_900M_TX.bin"
                      },
                      {
                        "label": "SX1276 Jumper T-ProS 900M TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Jumper_T-ProS_900M_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_Jumper_T-ProS_900M_TX.bin"
                      },
                      {
                        "label": "SX1276 NamimnoRC Voyager OLED 900MHz TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_NamimnoRC_Voyager_OLED_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_NamimnoRC_Voyager_OLED_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 RadioMaster 500-TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RadioMaster_500-TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_RadioMaster_500-TX.bin"
                      },
                      {
                        "label": "SX1276 RadioMaster Bandit 900MHz TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RadioMaster_Bandit_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_RadioMaster_Bandit_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 RadioMaster Bandit Micro 900MHz TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RadioMaster_Bandit_Micro_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_RadioMaster_Bandit_Micro_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 RadioMaster Bandit Nano 900MHz TX",
                        "chip": "SX1276",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RadioMaster_Bandit_Nano_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1276/R5RC6_RadioMaster_Bandit_Nano_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1280 AXIS Thor 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_AXIS_Thor_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_AXIS_Thor_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 BeastFPV 2.1GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BeastFPV_2.1GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_BeastFPV_2.1GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 BETAFPV 2.4GHz 1W Micro TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BETAFPV_2.4GHz_1W_Micro_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_BETAFPV_2.4GHz_1W_Micro_TX.bin"
                      },
                      {
                        "label": "SX1280 BETAFPV 2.4GHz LiteRadio 3 Pro",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BETAFPV_2.4GHz_LiteRadio_3_Pro.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_BETAFPV_2.4GHz_LiteRadio_3_Pro.bin"
                      },
                      {
                        "label": "SX1280 BETAFPV 2.4GHz Micro TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BETAFPV_2.4GHz_Micro_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_BETAFPV_2.4GHz_Micro_TX.bin"
                      },
                      {
                        "label": "SX1280 BETAFPV 2.4GHz Nano TX V2",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BETAFPV_2.4GHz_Nano_TX_V2.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_BETAFPV_2.4GHz_Nano_TX_V2.bin"
                      },
                      {
                        "label": "SX1280 BETAFPV 2.4GHz Nano TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BETAFPV_2.4GHz_Nano_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_BETAFPV_2.4GHz_Nano_TX.bin"
                      },
                      {
                        "label": "SX1280 BETAFPV SuperG 2.4GHz Gemini TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_BETAFPV_SuperG_2.4GHz_Gemini_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_BETAFPV_SuperG_2.4GHz_Gemini_TX.bin"
                      },
                      {
                        "label": "SX1280 CYCLONE 2.4GHz Micro TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_CYCLONE_2.4GHz_Micro_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_CYCLONE_2.4GHz_Micro_TX.bin"
                      },
                      {
                        "label": "SX1280 DIY ESP32 BLE Joystick TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_DIY_ESP32_BLE_Joystick_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_DIY_ESP32_BLE_Joystick_TX.bin"
                      },
                      {
                        "label": "SX1280 DIY ESP32 E28 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_DIY_ESP32_E28_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_DIY_ESP32_E28_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 DIY ESP32 F27 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_DIY_ESP32_F27_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_DIY_ESP32_F27_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 DIY Mini ESP32 SX1280 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_DIY_Mini_ESP32_SX1280_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_DIY_Mini_ESP32_SX1280_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 EMAX Nano 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_EMAX_Nano_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_EMAX_Nano_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 EMAX OLED 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_EMAX_OLED_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_EMAX_OLED_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Generic ESP32 2.4Ghz Gemini TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Generic_ESP32_2.4Ghz_Gemini_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_Generic_ESP32_2.4Ghz_Gemini_TX.bin"
                      },
                      {
                        "label": "SX1280 Generic Full-duplex 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Generic_Full-duplex_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_Generic_Full-duplex_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 HappyModel ES24 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_HappyModel_ES24_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_HappyModel_ES24_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 HappyModel ES24 Pro 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_HappyModel_ES24_Pro_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_HappyModel_ES24_Pro_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 HappyModel ES24 Slim Pro 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_HappyModel_ES24_Slim_Pro_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_HappyModel_ES24_Slim_Pro_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 HDZero Radio 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_HDZero_Radio_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_HDZero_Radio_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 HELLORADIO V14 Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_HELLORADIO_V14_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_HELLORADIO_V14_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 HELLORADIO V16 Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_HELLORADIO_V16_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_HELLORADIO_V16_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 HELLORADIO V16R Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_HELLORADIO_V16R_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_HELLORADIO_V16R_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 HGLRC Hermes 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_HGLRC_Hermes_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_HGLRC_Hermes_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 iFlight 2.4GHz TX V2",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_iFlight_2.4GHz_TX_V2.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_iFlight_2.4GHz_TX_V2.bin"
                      },
                      {
                        "label": "SX1280 iFlight 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_iFlight_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_iFlight_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION Nano 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Jumper_AION_Nano_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_Jumper_AION_Nano_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION T-14 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Jumper_AION_T-14_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_Jumper_AION_T-14_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION T-15 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Jumper_AION_T-15_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_Jumper_AION_T-15_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION T-20 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Jumper_AION_T-20_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_Jumper_AION_T-20_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION T-20 2.4GHz V2 TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Jumper_AION_T-20_2.4GHz_V2_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_Jumper_AION_T-20_2.4GHz_V2_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION T-Lite 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Jumper_AION_T-Lite_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_Jumper_AION_T-Lite_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION T-Pro 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Jumper_AION_T-Pro_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_Jumper_AION_T-Pro_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION T-ProS 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Jumper_AION_T-ProS_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_Jumper_AION_T-ProS_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper Gemini T-20 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Jumper_Gemini_T-20_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_Jumper_Gemini_T-20_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 NamimnoRC Flash OLED 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_NamimnoRC_Flash_OLED_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_NamimnoRC_Flash_OLED_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 QuadKopters JR 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_QuadKopters_JR_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_QuadKopters_JR_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 QuadKopters Slim 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_QuadKopters_Slim_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_QuadKopters_Slim_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster Boxer Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RadioMaster_Boxer_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_RadioMaster_Boxer_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster MT12 Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RadioMaster_MT12_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_RadioMaster_MT12_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster Pocket Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RadioMaster_Pocket_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_RadioMaster_Pocket_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster Ranger 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RadioMaster_Ranger_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_RadioMaster_Ranger_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster Ranger Micro 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RadioMaster_Ranger_Micro_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_RadioMaster_Ranger_Micro_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster Ranger Nano 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RadioMaster_Ranger_Nano_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_RadioMaster_Ranger_Nano_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster TX12 Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RadioMaster_TX12_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_RadioMaster_TX12_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster TX16S Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RadioMaster_TX16S_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_RadioMaster_TX16S_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster Zorro Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_RadioMaster_Zorro_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_RadioMaster_Zorro_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Vantac Lite 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "RED version 4",
                        "fileName": "R5RC6_Vantac_Lite_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/RED-version-4/SX1280/R5RC6_Vantac_Lite_2.4GHz_TX.bin"
                      }
                    ]
                },
                {
                    id: "tx-orange-v4",
                    title: "Прошивка Orange version 4",
                    folder: "./uprava-firmware/TX/Orange-version-4",
                    items: [
                      {
                        "label": "LR1121 B SubGHz TX 2W board 1.1",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_B_SubGHz_TX_2W_board_1.1.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_B_SubGHz_TX_2W_board_1.1.bin"
                      },
                      {
                        "label": "LR1121 B SubGHz TX 2W",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_B_SubGHz_TX_2W.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_B_SubGHz_TX_2W.bin"
                      },
                      {
                        "label": "LR1121 BAYCKRC 900-2400 Dual Band 1W Micro Gemini TX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BAYCKRC_900-2400_Dual_Band_1W_Micro_Gemini_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_BAYCKRC_900-2400_Dual_Band_1W_Micro_Gemini_TX.bin"
                      },
                      {
                        "label": "LR1121 BAYCKRC 900-2400 Dual Band 1W Nano Gemini TX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BAYCKRC_900-2400_Dual_Band_1W_Nano_Gemini_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_BAYCKRC_900-2400_Dual_Band_1W_Nano_Gemini_TX.bin"
                      },
                      {
                        "label": "LR1121 BAYCKRC 900-2400 Dual Band 1W Nano TX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BAYCKRC_900-2400_Dual_Band_1W_Nano_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_BAYCKRC_900-2400_Dual_Band_1W_Nano_TX.bin"
                      },
                      {
                        "label": "LR1121 CYCLONE LR1121 TX board 1.2",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_CYCLONE_LR1121_TX_board_1.2.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_CYCLONE_LR1121_TX_board_1.2.bin"
                      },
                      {
                        "label": "LR1121 CYCLONE LR1121 TX board 2.0",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_CYCLONE_LR1121_TX_board_2.0.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_CYCLONE_LR1121_TX_board_2.0.bin"
                      },
                      {
                        "label": "LR1121 DISRC 2.4GHz TX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DISRC_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_DISRC_2.4GHz_TX.bin"
                      },
                      {
                        "label": "LR1121 Edifier LR1121 TX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Edifier_LR1121_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_Edifier_LR1121_TX.bin"
                      },
                      {
                        "label": "LR1121 Edifier LR1520 TX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Edifier_LR1520_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_Edifier_LR1520_TX.bin"
                      },
                      {
                        "label": "LR1121 Flyfish H300 TX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Flyfish_H300_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_Flyfish_H300_TX.bin"
                      },
                      {
                        "label": "LR1121 Gemini XrossBand 2.4-900 TX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Gemini_XrossBand_2.4-900_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_Gemini_XrossBand_2.4-900_TX.bin"
                      },
                      {
                        "label": "LR1121 GEPRC LINKFLOW 900-2400 Dual-Band TX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_GEPRC_LINKFLOW_900-2400_Dual-Band_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_GEPRC_LINKFLOW_900-2400_Dual-Band_TX.bin"
                      },
                      {
                        "label": "LR1121 RadioMaster 300-TX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_300-TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_RadioMaster_300-TX.bin"
                      },
                      {
                        "label": "LR1121 RadioMaster GX12 2.4-900 TX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_GX12_2.4-900_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_RadioMaster_GX12_2.4-900_TX.bin"
                      },
                      {
                        "label": "LR1121 RadioMaster Nomad 2.4-900 TX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_Nomad_2.4-900_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_RadioMaster_Nomad_2.4-900_TX.bin"
                      },
                      {
                        "label": "LR1121 RadioMaster TX15 2.4-900 TX",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_TX15_2.4-900_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_RadioMaster_TX15_2.4-900_TX.bin"
                      },
                      {
                        "label": "LR1121 XFly FF1027",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_XFly_FF1027.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_XFly_FF1027.bin"
                      },
                      {
                        "label": "LR1121 XFly FF36-FF610",
                        "chip": "LR1121",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_XFly_FF36-FF610.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/LR1121/OR5b4_XFly_FF36-FF610.bin"
                      },
                      {
                        "label": "SX1276 BeastFPV 750MHz TX V1",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BeastFPV_750MHz_TX_V1.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_BeastFPV_750MHz_TX_V1.bin"
                      },
                      {
                        "label": "SX1276 BeastFPV 750MHz TX V2",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BeastFPV_750MHz_TX_V2.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_BeastFPV_750MHz_TX_V2.bin"
                      },
                      {
                        "label": "SX1276 BelinRC 433MHZ TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BelinRC_433MHZ_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_BelinRC_433MHZ_TX.bin"
                      },
                      {
                        "label": "SX1276 BelinRC 750MHZ TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BelinRC_750MHZ_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_BelinRC_750MHZ_TX.bin"
                      },
                      {
                        "label": "SX1276 BETAFPV 370-420MHz Micro TX board 1.1",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_370-420MHz_Micro_TX_board_1.1.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_BETAFPV_370-420MHz_Micro_TX_board_1.1.bin"
                      },
                      {
                        "label": "SX1276 BETAFPV 400MHz Micro TX board 1.0",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_400MHz_Micro_TX_board_1.0.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_BETAFPV_400MHz_Micro_TX_board_1.0.bin"
                      },
                      {
                        "label": "SX1276 BETAFPV 500-560MHz Micro TX board 1.1",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_500-560MHz_Micro_TX_board_1.1.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_BETAFPV_500-560MHz_Micro_TX_board_1.1.bin"
                      },
                      {
                        "label": "SX1276 BETAFPV 900MHz Micro TX V2",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_900MHz_Micro_TX_V2.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_BETAFPV_900MHz_Micro_TX_V2.bin"
                      },
                      {
                        "label": "SX1276 BETAFPV 900MHz Micro TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_900MHz_Micro_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_BETAFPV_900MHz_Micro_TX.bin"
                      },
                      {
                        "label": "SX1276 BETAFPV 900MHz Nano TX V2",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_900MHz_Nano_TX_V2.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_BETAFPV_900MHz_Nano_TX_V2.bin"
                      },
                      {
                        "label": "SX1276 BETAFPV 900MHz Nano TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_900MHz_Nano_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_BETAFPV_900MHz_Nano_TX.bin"
                      },
                      {
                        "label": "SX1276 CEKTOP TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_CEKTOP_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_CEKTOP_TX.bin"
                      },
                      {
                        "label": "SX1276 CYCLONE 900MHz Micro TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_CYCLONE_900MHz_Micro_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_CYCLONE_900MHz_Micro_TX.bin"
                      },
                      {
                        "label": "SX1276 CYCLONE SX1276 TX400 board 1.0",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_CYCLONE_SX1276_TX400_board_1.0.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_CYCLONE_SX1276_TX400_board_1.0.bin"
                      },
                      {
                        "label": "SX1276 CYCLONE SX1276 TX400 board 2.0",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_CYCLONE_SX1276_TX400_board_2.0.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_CYCLONE_SX1276_TX400_board_2.0.bin"
                      },
                      {
                        "label": "SX1276 DAKEFPV 433MHz Micro MAX 2W TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DAKEFPV_433MHz_Micro_MAX_2W_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_DAKEFPV_433MHz_Micro_MAX_2W_TX.bin"
                      },
                      {
                        "label": "SX1276 DISRC TX 433 v2",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DISRC_TX_433_v2.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_DISRC_TX_433_v2.bin"
                      },
                      {
                        "label": "SX1276 DIY ESP32 E19 900MHz TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DIY_ESP32_E19_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_DIY_ESP32_E19_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 DIY ESP32 RFM95 900MHz TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DIY_ESP32_RFM95_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_DIY_ESP32_RFM95_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 DIY TTGO V1 900MHz TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DIY_TTGO_V1_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_DIY_TTGO_V1_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 DIY TTGO V2 900MHz TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DIY_TTGO_V2_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_DIY_TTGO_V2_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 Edifier OLED 433MHz TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Edifier_OLED_433MHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_Edifier_OLED_433MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 EMAX Nano 900MHz TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_EMAX_Nano_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_EMAX_Nano_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 EMAX OLED 900MHz TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_EMAX_OLED_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_EMAX_OLED_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 FlyFish 150MHz TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_FlyFish_150MHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_FlyFish_150MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 FlyFish 500MHz TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_FlyFish_500MHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_FlyFish_500MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 FOXEER OLED 790MHz TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_FOXEER_OLED_790MHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_FOXEER_OLED_790MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 Generic ESP32 900MHz Gemini TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP32_900MHz_Gemini_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_Generic_ESP32_900MHz_Gemini_TX.bin"
                      },
                      {
                        "label": "SX1276 GEPRC LINKFLOW 900M TX V2",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_GEPRC_LINKFLOW_900M_TX_V2.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_GEPRC_LINKFLOW_900M_TX_V2.bin"
                      },
                      {
                        "label": "SX1276 GEPRC LINKFLOW 900M TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_GEPRC_LINKFLOW_900M_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_GEPRC_LINKFLOW_900M_TX.bin"
                      },
                      {
                        "label": "SX1276 HappyModel ES900 Max TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HappyModel_ES900_Max_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_HappyModel_ES900_Max_TX.bin"
                      },
                      {
                        "label": "SX1276 HappyModel ES900 TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HappyModel_ES900_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_HappyModel_ES900_TX.bin"
                      },
                      {
                        "label": "SX1276 HGLRC OLED 900MHz TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HGLRC_OLED_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_HGLRC_OLED_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 iFlight 900MHz TX V2",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_iFlight_900MHz_TX_V2.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_iFlight_900MHz_TX_V2.bin"
                      },
                      {
                        "label": "SX1276 iFlight 900MHz TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_iFlight_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_iFlight_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 Jumper AION T-14 900M TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_AION_T-14_900M_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_Jumper_AION_T-14_900M_TX.bin"
                      },
                      {
                        "label": "SX1276 Jumper AION T-15 900M TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_AION_T-15_900M_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_Jumper_AION_T-15_900M_TX.bin"
                      },
                      {
                        "label": "SX1276 Jumper AION T-20 900M TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_AION_T-20_900M_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_Jumper_AION_T-20_900M_TX.bin"
                      },
                      {
                        "label": "SX1276 Jumper AION T-20 900M V2 TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_AION_T-20_900M_V2_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_Jumper_AION_T-20_900M_V2_TX.bin"
                      },
                      {
                        "label": "SX1276 Jumper T-Pro 900M TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_T-Pro_900M_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_Jumper_T-Pro_900M_TX.bin"
                      },
                      {
                        "label": "SX1276 Jumper T-ProS 900M TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_T-ProS_900M_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_Jumper_T-ProS_900M_TX.bin"
                      },
                      {
                        "label": "SX1276 NamimnoRC N400T 1W TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_NamimnoRC_N400T_1W_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_NamimnoRC_N400T_1W_TX.bin"
                      },
                      {
                        "label": "SX1276 NamimnoRC Voyager OLED 900MHz TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_NamimnoRC_Voyager_OLED_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_NamimnoRC_Voyager_OLED_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 RadioMaster 500-TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_500-TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_RadioMaster_500-TX.bin"
                      },
                      {
                        "label": "SX1276 RadioMaster Bandit 900MHz TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_Bandit_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_RadioMaster_Bandit_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 RadioMaster Bandit Micro 900MHz TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_Bandit_Micro_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_RadioMaster_Bandit_Micro_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1276 RadioMaster Bandit Nano 900MHz TX",
                        "chip": "SX1276",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_Bandit_Nano_900MHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1276/OR5b4_RadioMaster_Bandit_Nano_900MHz_TX.bin"
                      },
                      {
                        "label": "SX1280 AXIS Thor 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_AXIS_Thor_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_AXIS_Thor_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 BeastFPV 2.1GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BeastFPV_2.1GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_BeastFPV_2.1GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 BETAFPV 2.4GHz 1W Micro TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_2.4GHz_1W_Micro_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_BETAFPV_2.4GHz_1W_Micro_TX.bin"
                      },
                      {
                        "label": "SX1280 BETAFPV 2.4GHz LiteRadio 3 Pro",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_2.4GHz_LiteRadio_3_Pro.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_BETAFPV_2.4GHz_LiteRadio_3_Pro.bin"
                      },
                      {
                        "label": "SX1280 BETAFPV 2.4GHz Micro TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_2.4GHz_Micro_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_BETAFPV_2.4GHz_Micro_TX.bin"
                      },
                      {
                        "label": "SX1280 BETAFPV 2.4GHz Nano TX V2",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_2.4GHz_Nano_TX_V2.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_BETAFPV_2.4GHz_Nano_TX_V2.bin"
                      },
                      {
                        "label": "SX1280 BETAFPV 2.4GHz Nano TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_2.4GHz_Nano_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_BETAFPV_2.4GHz_Nano_TX.bin"
                      },
                      {
                        "label": "SX1280 BETAFPV SuperG 2.4GHz Gemini TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_BETAFPV_SuperG_2.4GHz_Gemini_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_BETAFPV_SuperG_2.4GHz_Gemini_TX.bin"
                      },
                      {
                        "label": "SX1280 CoreWing Sirius 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_CoreWing_Sirius_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_CoreWing_Sirius_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 CYCLONE 2.4GHz Micro TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_CYCLONE_2.4GHz_Micro_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_CYCLONE_2.4GHz_Micro_TX.bin"
                      },
                      {
                        "label": "SX1280 DIY ESP32 BLE Joystick TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DIY_ESP32_BLE_Joystick_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_DIY_ESP32_BLE_Joystick_TX.bin"
                      },
                      {
                        "label": "SX1280 DIY ESP32 E28 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DIY_ESP32_E28_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_DIY_ESP32_E28_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 DIY ESP32 F27 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DIY_ESP32_F27_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_DIY_ESP32_F27_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 DIY ESP32-S3 DevKit Gemini 2.4Ghz TX ",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DIY_ESP32-S3_DevKit_Gemini_2.4Ghz_TX_.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_DIY_ESP32-S3_DevKit_Gemini_2.4Ghz_TX_.bin"
                      },
                      {
                        "label": "SX1280 DIY Mini ESP32 SX1280 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_DIY_Mini_ESP32_SX1280_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_DIY_Mini_ESP32_SX1280_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 EMAX Nano 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_EMAX_Nano_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_EMAX_Nano_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 EMAX OLED 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_EMAX_OLED_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_EMAX_OLED_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Flysky PA01 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Flysky_PA01_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_Flysky_PA01_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Generic ESP32 2.4Ghz Gemini TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_ESP32_2.4Ghz_Gemini_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_Generic_ESP32_2.4Ghz_Gemini_TX.bin"
                      },
                      {
                        "label": "SX1280 Generic Full-duplex 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Generic_Full-duplex_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_Generic_Full-duplex_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 HappyModel ES24 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HappyModel_ES24_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_HappyModel_ES24_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 HappyModel ES24 Pro 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HappyModel_ES24_Pro_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_HappyModel_ES24_Pro_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 HappyModel ES24 Slim Pro 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HappyModel_ES24_Slim_Pro_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_HappyModel_ES24_Slim_Pro_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 HDZero Radio 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HDZero_Radio_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_HDZero_Radio_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 HELLORADIO V14 Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HELLORADIO_V14_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_HELLORADIO_V14_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 HELLORADIO V16 Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HELLORADIO_V16_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_HELLORADIO_V16_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 HELLORADIO V16R Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HELLORADIO_V16R_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_HELLORADIO_V16R_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 HGLRC Hermes 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_HGLRC_Hermes_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_HGLRC_Hermes_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 iFlight 2.4GHz TX V2",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_iFlight_2.4GHz_TX_V2.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_iFlight_2.4GHz_TX_V2.bin"
                      },
                      {
                        "label": "SX1280 iFlight 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_iFlight_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_iFlight_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION Bumblebee 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_AION_Bumblebee_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_Jumper_AION_Bumblebee_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION Nano 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_AION_Nano_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_Jumper_AION_Nano_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION T-12 MAX 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_AION_T-12_MAX_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_Jumper_AION_T-12_MAX_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION T-14 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_AION_T-14_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_Jumper_AION_T-14_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION T-15 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_AION_T-15_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_Jumper_AION_T-15_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION T-20 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_AION_T-20_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_Jumper_AION_T-20_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION T-20 2.4GHz V2 TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_AION_T-20_2.4GHz_V2_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_Jumper_AION_T-20_2.4GHz_V2_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION T-Lite 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_AION_T-Lite_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_Jumper_AION_T-Lite_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION T-Pro 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_AION_T-Pro_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_Jumper_AION_T-Pro_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper AION T-ProS 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_AION_T-ProS_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_Jumper_AION_T-ProS_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Jumper Gemini T-20 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Jumper_Gemini_T-20_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_Jumper_Gemini_T-20_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 NamimnoRC Flash OLED 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_NamimnoRC_Flash_OLED_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_NamimnoRC_Flash_OLED_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 QuadKopters JR 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_QuadKopters_JR_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_QuadKopters_JR_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 QuadKopters Slim 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_QuadKopters_Slim_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_QuadKopters_Slim_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster Boxer Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_Boxer_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_RadioMaster_Boxer_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster MT12 Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_MT12_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_RadioMaster_MT12_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster Pocket Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_Pocket_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_RadioMaster_Pocket_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster Ranger 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_Ranger_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_RadioMaster_Ranger_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster Ranger Micro 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_Ranger_Micro_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_RadioMaster_Ranger_Micro_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster Ranger Nano 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_Ranger_Nano_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_RadioMaster_Ranger_Nano_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster TX12 Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_TX12_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_RadioMaster_TX12_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster TX16S Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_TX16S_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_RadioMaster_TX16S_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 RadioMaster Zorro Internal 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_RadioMaster_Zorro_Internal_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_RadioMaster_Zorro_Internal_2.4GHz_TX.bin"
                      },
                      {
                        "label": "SX1280 Vantac Lite 2.4GHz TX",
                        "chip": "SX1280",
                        "version": "Orange version 4",
                        "fileName": "OR5b4_Vantac_Lite_2.4GHz_TX.bin",
                        "path": "./uprava-firmware/TX/Orange-version-4/SX1280/OR5b4_Vantac_Lite_2.4GHz_TX.bin"
                      }
                    ]
                }
            ]
        }
    ];
    var selectedUpravaFirmware = {};
    var emptyTableText = "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0432\u0438\u0434\u0435\u043e\u043f\u0435\u0440\u0435\u0434\u0430\u0442\u0447\u0438\u043a, \u0438 \u0437\u0434\u0435\u0441\u044c \u043f\u043e\u044f\u0432\u0438\u0442\u0441\u044f CLI VTX Table.";
    var emptyPhotoText = "\u0424\u043e\u0442\u043e \u0432\u0438\u0434\u0435\u043e\u043f\u0435\u0440\u0435\u0434\u0430\u0442\u0447\u0438\u043a\u0430";
    var readyDumps = [
        {
            name: "Боец (Fighter)",
            multiDump: true,
            photo: "./images/ready-dumps/fighter-boec.jpg",
            note: "FC                        : SKYSTARSF405V2\n" +
                "Прошивка          : 4.5.2\n" +
                "VTX                      : AKK 96ch (SmartAudio)",
            controllers: [
                {
                    name: "SKYSTARSF405V2 (Черный) EOX",
                    flightController: "SKYSTARSF405V2",
                    firmware: "4.5.2",
                    vtx: "AKK 96ch (SmartAudio)",
                    dumpPath: "./ready-dumps/fighter/black.txt",
                    photo: "./images/ready-dumps/fighter-boec.jpg",
                    note: "FC                        : SKYSTARSF405V2\n" +
                        "Прошивка          : 4.5.2\n" +
                        "VTX                      : AKK 96ch (SmartAudio)\n" +
                        "VTX правила      : EOX (Bands)"
                },
                {
                    name: "AOCODARCF405V3 (Зеленый) EOX",
                    flightController: "AOCODARCF405V3",
                    firmware: "4.5.2",
                    vtx: "AKK 96ch (SmartAudio)",
                    dumpPath: "./ready-dumps/fighter/green.txt",
                    photo: "./images/ready-dumps/fighter-boec.jpg",
                    note: "FC                        : AOCODARCF405V3\n" +
                        "Прошивка          : 4.5.2\n" +
                        "VTX                      : AKK 96ch (SmartAudio)\n" +
                        "VTX правила      : EOX (Bands)"
                },
                {
                    name: "HAKRCF405V2 (Оранжевый) EOX",
                    flightController: "HAKRCF405V2",
                    firmware: "4.5.2",
                    vtx: "AKK 96ch (SmartAudio)",
                    dumpPath: "./ready-dumps/fighter/orange.txt",
                    photo: "./images/ready-dumps/fighter-boec.jpg",
                    note: "FC                        : HAKRCF405V2\n" +
                        "Прошивка          : 4.5.2\n" +
                        "VTX                      : AKK 96ch (SmartAudio)\n" +
                        "VTX правила      : EOX (Bands)"
                },
                {
                    name: "SKYSTARSF405V2 (Черный) EOU",
                    flightController: "SKYSTARSF405V2",
                    firmware: "4.5.2",
                    vtx: "AKK 96ch (SmartAudio)",
                    dumpPath: "./ready-dumps/fighter/black-eou.txt",
                    photo: "./images/ready-dumps/fighter-boec.jpg",
                    note: "FC                        : SKYSTARSF405V2\n" +
                        "Прошивка          : 4.5.2\n" +
                        "VTX                      : AKK 96ch (SmartAudio)\n" +
                        "VTX правила      : EOU (Bands)"
                },
                {
                    name: "AOCODARCF405V3 (Зеленый) EOU",
                    flightController: "AOCODARCF405V3",
                    firmware: "4.5.2",
                    vtx: "AKK 96ch (SmartAudio)",
                    dumpPath: "./ready-dumps/fighter/green-eou.txt",
                    photo: "./images/ready-dumps/fighter-boec.jpg",
                    note: "FC                        : AOCODARCF405V3\n" +
                        "Прошивка          : 4.5.2\n" +
                        "VTX                      : AKK 96ch (SmartAudio)\n" +
                        "VTX правила      : EOU (Bands)"
                },
                {
                    name: "HAKRCF405V2 (Оранжевый) EOU",
                    flightController: "HAKRCF405V2",
                    firmware: "4.5.2",
                    vtx: "AKK 96ch (SmartAudio)",
                    dumpPath: "./ready-dumps/fighter/orange-eou.txt",
                    photo: "./images/ready-dumps/fighter-boec.jpg",
                    note: "FC                        : HAKRCF405V2\n" +
                        "Прошивка          : 4.5.2\n" +
                        "VTX                      : AKK 96ch (SmartAudio)\n" +
                        "VTX правила      : EOU (Bands)"
                }
            ]
        },
        {
            name: "РТД-15",
            photo: "./images/ready-dumps/rtd-15.jpg",
            note: "FC                        : AOCODARCF405V3\n" +
                "Прошивка          : 4.5.1 G13\n" +
                "VTX                     : Холодильник (SmartAudio)\n" +
                "VTX правила      : EOX (Bands)",
            controllers: [
                {
                    name: "AOCODARCF405V3",
                    flightController: "AOCODARCF405V3",
                    firmware: "4.5.1 G13",
                    vtx: "Холодильник (SmartAudio)",
                    dumpPath: "./ready-dumps/rtd-15/g13-rtd-15.txt",
                    photo: "./images/ready-dumps/rtd-15.jpg",
                    note: "FC                        : AOCODARCF405V3\n" +
                        "Прошивка          : 4.5.1 G13\n" +
                        "VTX                     : Холодильник (SmartAudio)\n" +
                        "VTX правила      : EOX (Bands)"
                }
            ]
        },
        {
            name: "Бумеранг",
            photo: "./images/ready-dumps/boomerang.jpg",
            note: "FC                        : FOXEERF405V2\n" +
                "Прошивка          : 4.5.1 G13\n" +
                "VTX:Foxeer infinity 5W Custom Freg (TRAMP)\n" +
                "VTX правила      : EOU (Bands)",
            controllers: [
                {
                    name: "FOXEERF405V2",
                    flightController: "FOXEERF405V2",
                    firmware: "4.5.1 G13",
                    vtx: "Foxeer infinity 5W Custom Freg (TRAMP)",
                    dumpPath: "./ready-dumps/boomerang/g13-eou.txt",
                    photo: "./images/ready-dumps/boomerang.jpg",
                    note: "FC                        : FOXEERF405V2\n" +
                        "Прошивка          : 4.5.1 G13\n" +
                        "VTX:Foxeer infinity 5W Custom Freg (TRAMP)\n" +
                        "VTX правила      : EOU (Bands)"
                }
            ]
        },
        {
            name: "ПВХ-1",
            multiDump: true,
            photo: "./images/ready-dumps/pvh-1.jpg",
            note: "FC                        : HAKRCF405V2\n" +
                "Прошивка          : 4.5.1\n" +
                "VTX                     : Холодильник(SmartAudio)\n" +
                "VTX правила      : EOX (Bands)\n" +
                "В OSD установлен номер пилота : 610002",
            controllers: [
                {
                    name: "HAKRCF405V2 (оранжевый)",
                    flightController: "HAKRCF405V2",
                    firmware: "4.5.1",
                    vtx: "Холодильник(SmartAudio)",
                    dumpPath: "./ready-dumps/pvh-1/610002-or-komik-smart-holod.txt",
                    photo: "./images/ready-dumps/pvh-1.jpg",
                    note: "FC                        : HAKRCF405V2\n" +
                        "Прошивка          : 4.5.1\n" +
                        "VTX                     : Холодильник(SmartAudio)\n" +
                        "VTX правила      : EOX (Bands)\n" +
                        "В OSD установлен номер пилота : 610002"
                },
                {
                    name: "HAKRCF405V2 (серый) EOX",
                    flightController: "HAKRCF405V2",
                    firmware: "4.5.1",
                    vtx: "SmartAudio",
                    dumpPath: "./ready-dumps/pvh-1/610002-gray-smart-eox.txt",
                    photo: "./images/ready-dumps/pvh-1.jpg",
                    note: "FC                        : HAKRCF405V2\n" +
                        "Прошивка          : 4.5.1\n" +
                        "VTX                     : SmartAudio\n" +
                        "VTX правила      : EOX (Bands)\n" +
                        "В OSD установлен номер пилота : 610002"
                }
            ]
        }    ];
    var selectedDumpIndex = 0;
    var selectedDumpControllerIndex = 0;
    var offlineFirmwareTargets = [
        {
            name: "SKYSTARSF405V2",
            target: "SKYSTARSF405V2",
            fileName: "SKYSTARF405V2/fw.bin",
            firmwarePath: "./offline-firmware/SKYSTARF405V2/fw.bin",
            aliases: ["SKYSTARF405V2"],
            hasFirmware: true,
            firmwareVersion: "4.5.2",
            baseAddress: 0x08000000
        },
        {
            name: "SPEDIXF405",
            target: "SPEDIXF405",
            fileName: "SPEDIXF405_4.4.2/hobbyporthex.hex",
            firmwarePath: "./offline-firmware/SPEDIXF405_4.4.2/hobbyporthex.hex",
            aliases: ["HOBBYPORT", "HOBBY PORT", "HOBBYPORTF405", "SPEDIXF405"],
            hasFirmware: true,
            firmwareVersion: "4.4.2",
            offlineNote: "Дрон ПВХ приходит в подразделения с черным цветом",
            baseAddress: 0x08000000
        },
        {
            name: "GENERICF4V2 G13 (зеленый)",
            target: "GENERICF4V2",
            fileName: "GENERICF4V2_4.5.1_G13_green/Green G13 GenericF4V2.hex",
            firmwarePath: "./offline-firmware/GENERICF4V2_4.5.1_G13_green/Green G13 GenericF4V2.hex",
            aliases: ["GENERIC_F4", "GENERICF4", "STM32F405", "STM32F405 G13+61"],
            hasFirmware: true,
            firmwareVersion: "4.5.1 G13",
            offlineNote: "Дрон ПВХ приходит в подразделения с зеленым цветом",
            baseAddress: 0x08000000
        },
        {
            name: "HAKRCF405V2 (оранжевый)",
            target: "HAKRCF405V2",
            fileName: "HAKRCF405V2_4.5.1_orange/Orange_4.5.1_STM32F405_HAKRCF405V2.hex",
            firmwarePath: "./offline-firmware/HAKRCF405V2_4.5.1_orange/Orange_4.5.1_STM32F405_HAKRCF405V2.hex",
            aliases: ["HKRCF405V2", "HKRC", "HAKRC"],
            hasFirmware: true,
            firmwareVersion: "4.5.1",
            offlineNote: "Дрон ПВХ приходит в подразделения с оранжевым цветом",
            baseAddress: 0x08000000
        },
        {
            name: "SPEEDYBEEF405V3",
            target: "SPEEDYBEEF405V3",
            fileName: "SPEEDYBEEF405V3_4.3.2_yellow/betaflight_4.3.2_SPEEDYBEEF405V3.hex",
            firmwarePath: "./offline-firmware/SPEEDYBEEF405V3_4.3.2_yellow/betaflight_4.3.2_SPEEDYBEEF405V3.hex",
            aliases: ["SPEEDYBEE", "SPEEDYBEEF405", "STM32F405"],
            hasFirmware: true,
            firmwareVersion: "4.3.2",
            offlineNote: "Дрон ПВХ приходит в подразделения с желтым цветом",
            baseAddress: 0x08000000
        },
        {
            name: "FURYF4OSD (Mamba)",
            target: "FURYF4OSD",
            fileName: "FURYF4OSD_4.4.3_blue/Mamba_4.4.3.hex",
            firmwarePath: "./offline-firmware/FURYF4OSD_4.4.3_blue/Mamba_4.4.3.hex",
            aliases: ["MAMBA", "DIAT", "DIATONE", "STM32F405"],
            hasFirmware: true,
            firmwareVersion: "4.4.3",
            offlineNote: "Дрон ПВХ приходит в подразделения с голубым цветом",
            baseAddress: 0x08000000
        },
        {
            name: "FOXEERF405V2 (Бумеранг)",
            target: "FOXEERF405V2",
            fileName: "FOXEERF405V2_2025.12.2_alpha_boomerang/fw.bin",
            firmwarePath: "./offline-firmware/FOXEERF405V2_2025.12.2_alpha_boomerang/fw.bin",
            aliases: ["FOXEERF405V2", "FOXE", "FOXEER", "STM32F405"],
            hasFirmware: true,
            firmwareVersion: "2025.12.2-alpha",
            baseAddress: 0x08000000
        },
        {
            name: "FOXEERF405V2 (Бумеранг G13)",
            target: "FOXEERF405V2",
            fileName: "FOXEERF405V2_G13_boomerang/fw.bin",
            firmwarePath: "./offline-firmware/FOXEERF405V2_G13_boomerang/fw.bin",
            aliases: ["FOXEERF405V2", "FOXE", "FOXEER", "STM32F405", "G13", "BOOMERANG"],
            hasFirmware: true,
            firmwareVersion: "G13",
            baseAddress: 0x08000000
        }
    ];
    var selectedOfflineFirmwareIndex = 0;
    var offlineFirmwareDfuTimer = null;

    var transmitters = [
        {
            name: "AKK Alpha5 G13 80ch",
            photo: "./images/vtx/akk-alpha5-g13-80ch.png",
            table: "# vtxtable (AKK_Alpha 5 80CH_inav.json)\n" +
                "vtxtable bands 10\n" +
                "vtxtable channels 8\n" +
                "vtxtable band 1 BOSCAM_A A FACTORY 5865 5845 5825 5805 5785 5765 5745 5725\n" +
                "vtxtable band 2 BOSCAM_B B FACTORY 5733 5752 5771 5790 5809 5828 5847 5866\n" +
                "vtxtable band 3 BOSCAM_E E FACTORY 5705 5685 5665 5645 5885 5905 5925 5945\n" +
                "vtxtable band 4 FATSHARK F FACTORY 5740 5760 5780 5800 5820 5840 5860 5880\n" +
                "vtxtable band 5 RACEBAND R FACTORY 5658 5695 5732 5769 5806 5843 5880 5917\n" +
                "vtxtable band 6 LOWRACEP P FACTORY 5653 5693 5733 5773 5813 5853 5893 5933\n" +
                "vtxtable band 7 BAND_L L FACTORY 5333 5373 5413 5453 5493 5533 5573 5613\n" +
                "vtxtable band 8 BAND_U U FACTORY 5325 5348 5366 5384 5402 5420 5438 5456\n" +
                "vtxtable band 9 BAND_O O FACTORY 5474 5492 5510 5528 5546 5564 5582 5600\n" +
                "vtxtable band 10 BAND_X X FACTORY 4990 5020 5050 5080 5110 5140 5170 5200\n" +
                "vtxtable powerlevels 5\n" +
                "vtxtable powervalues 0 1 2 3 4\n" +
                "vtxtable powerlabels 25 1W 2W 3W 5W\n\n" +
                "save"
        },
        {
            name: "AKK A100 G13 64ch",
            photo: "./images/vtx/akk-a100-g13-64ch-v2.png",
            table: "# vtxtable (AKK_A100 64CH.json)\n" +
                "vtxtable bands 8\n" +
                "vtxtable channels 8\n" +
                "vtxtable band 1 BOSCAM_A A FACTORY 5865 5845 5825 5805 5785 5765 5745 5725\n" +
                "vtxtable band 2 BOSCAM_B B FACTORY 5733 5752 5771 5790 5809 5828 5847 5866\n" +
                "vtxtable band 3 BOSCAM_E E FACTORY 5705 5685 5665 5645 5885 5905 5925 5945\n" +
                "vtxtable band 4 FATSHARK F FACTORY 5740 5760 5780 5800 5820 5840 5860 5880\n" +
                "vtxtable band 5 RACEBAND R FACTORY 5658 5695 5732 5769 5806 5843 5880 5917\n" +
                "vtxtable band 6 LOWRACEP P FACTORY 5653 5693 5733 5773 5813 5853 5893 5933\n" +
                "vtxtable band 7 BAND_L L FACTORY 5333 5373 5413 5453 5493 5533 5573 5613\n" +
                "vtxtable band 8 BAND_U U FACTORY 5325 5348 5366 5384 5402 5420 5438 5456\n" +
                "vtxtable powerlevels 5\n" +
                "vtxtable powervalues 0 1 2 3 4\n" +
                "vtxtable powerlabels 25 1W 2W 3W 5W\n\n" +
                "save"
        },
        {
            name: "CTR33 3.3 40ch",
            photo: "./images/vtx/ctr33-3-3-40ch.png",
            table: "# vtxtable (CTR33_g13_40CH.json)\n" +
                "vtxtable bands 5\n" +
                "vtxtable channels 8\n" +
                "vtxtable band 1 A A FACTORY 3200 3220 3240 3260 3280 3300 3320 3340\n" +
                "vtxtable band 2 B B FACTORY 3360 3380 3400 3420 3440 3460 3480 3500\n" +
                "vtxtable band 3 C C FACTORY 3520 3540 3560 3580 3600 3620 3640 3680\n" +
                "vtxtable band 4 D D FACTORY 3210 3250 3290 3330 3370 3410 3450 3490\n" +
                "vtxtable band 5 E E FACTORY 3230 3290 3350 3410 3470 3530 3590 3700\n" +
                "vtxtable powerlevels 5\n" +
                "vtxtable powervalues 0 1 2 3 4\n" +
                "vtxtable powerlabels 25 100 200 1W 5W\n\n" +
                "save"
        },
        {
            name: "Foxeer 4.9G-6G Reaper Infinity 10W 5.8",
            photo: "./images/vtx/foxeer-reaper-infinity-10w-5-8.png",
            table: "# vtxtable (Foxeer_VTx_table_10W_A_B_E_F_R_H_U_O.json)\n" +
                "vtxtable bands 8\n" +
                "vtxtable channels 8\n" +
                "vtxtable band 1 BAND_A   A CUSTOM 5865 5845 5825 5805 5785 5765 5745 5725\n" +
                "vtxtable band 2 BAND_B   B CUSTOM 5733 5752 5771 5790 5809 5828 5847 5866\n" +
                "vtxtable band 3 BAND_E   E CUSTOM 5705 5685 5665 5645 5885 5905 5925 5945\n" +
                "vtxtable band 4 BAND_F   F CUSTOM 5740 5760 5780 5800 5820 5840 5860 5880\n" +
                "vtxtable band 5 BAND_R   R CUSTOM 5658 5695 5732 5769 5806 5843 5880 5917\n" +
                "vtxtable band 6 BAND_H   H CUSTOM 5653 5693 5733 5773 5813 5853 5893 5933\n" +
                "vtxtable band 7 BAND_U U CUSTOM 5325 5348 5366 5384 5402 5420 5438 5456\n" +
                "vtxtable band 8 BAND_O O CUSTOM 5474 5492 5510 5528 5546 5564 5582 5600\n" +
                "vtxtable powerlevels 5\n" +
                "vtxtable powervalues 25 100 200 400 600\n" +
                "vtxtable powerlabels 500 2.5 5 7.5 10\n\n" +
                "save"
        },
        {
            name: "Foxeer 4.9G-6G Reaper Infinity 10W 4.9",
            photo: "./images/vtx/foxeer-reaper-infinity-10w-5-8.png",
            table: "# vtxtable (Foxeer_vtx_table_10W_A_B_E_F_R_H_L_X (3).json)\n" +
                "vtxtable bands 8\n" +
                "vtxtable channels 8\n" +
                "vtxtable band 1 BAND_A   A CUSTOM 5865 5845 5825 5805 5785 5765 5745 5725\n" +
                "vtxtable band 2 BAND_B   B CUSTOM 5733 5752 5771 5790 5809 5828 5847 5866\n" +
                "vtxtable band 3 BAND_E   E CUSTOM 5705 5685 5665 5645 5885 5905 5925 5945\n" +
                "vtxtable band 4 BAND_F   F CUSTOM 5740 5760 5780 5800 5820 5840 5860 5880\n" +
                "vtxtable band 5 BAND_R   R CUSTOM 5658 5695 5732 5769 5806 5843 5880 5917\n" +
                "vtxtable band 6 BAND_H   H CUSTOM 5653 5693 5733 5773 5813 5853 5893 5933\n" +
                "vtxtable band 7 BAND_L L CUSTOM 5333 5373 5413 5453 5493 5533 5573 5613\n" +
                "vtxtable band 8 BAND_X X CUSTOM 4990 5020 5050 5080 5110 5140 5170 5200\n" +
                "vtxtable powerlevels 5\n" +
                "vtxtable powervalues 25 100 200 400 600\n" +
                "vtxtable powerlabels 500 2.5 5 7.5 10\n\n" +
                "save"
        },
        {
            name: "Solo Max Full",
            photo: "./images/vtx/solo-max-full.png",
            table: "# vtxtable (VTX G13_MAx_Solo_full.json)\n" +
                "vtxtable bands 7\n" +
                "vtxtable channels 8\n" +
                "vtxtable band 1 BAND_A A CUSTOM 5865 5845 5825 5805 5785 5765 5745 5725\n" +
                "vtxtable band 2 BAND_B B CUSTOM 5733 5752 5771 5790 5999 5828 5847 5866\n" +
                "vtxtable band 3 BAND_E E CUSTOM 5705 5685 5665 5645 5885 5905 5925 5945\n" +
                "vtxtable band 4 AIRWAVE F CUSTOM 5740 5760 5780 5800 5820 5840 5860 5880\n" +
                "vtxtable band 5 RACEBAND R CUSTOM 5658 5695 5732 5769 5806 5843 5880 5917\n" +
                "vtxtable band 6 LOWRACE L CUSTOM 5362 5399 5436 5473 5510 5547 5584 5621\n" +
                "vtxtable band 7 BAND_X X CUSTOM 4990 5020 5050 5080 5110 5140 5170 5200\n" +
                "vtxtable powerlevels 4\n" +
                "vtxtable powervalues 14 27 30 34\n" +
                "vtxtable powerlabels 25 500 1 2.5\n\n" +
                "save"
        },
        {
            name: 'FF4960 "Холодильник" 5.8G',
            photo: "./images/vtx/ff4960-holodilnik.png",
            table: "# vtxtable (FF4960.json)\n" +
                "vtxtable bands 12\n" +
                "vtxtable channels 8\n" +
                "vtxtable band 1 BAND_A   A FACTORY 5474 5492 5510 5528 5546 5564 5582 5600\n" +
                "vtxtable band 2 BAND_B   B FACTORY 5362 5399 5436 5473 5500 5547 5584 5621\n" +
                "vtxtable band 3 BAND_E   E FACTORY 5300 5348 5366 5384 5400 5420 5438 5456\n" +
                "vtxtable band 4 BAND_F   F FACTORY 5129 5159 5189 5219 5249 5279 5309 5339\n" +
                "vtxtable band 5 BAND_R   R FACTORY 4990 5020 5050 5080 5110 5150 5170 5200\n" +
                "vtxtable band 6 BAND_P   P FACTORY 5333 5373 5413 5453 5493 5533 5373 5613\n" +
                "vtxtable band 7 BAND_L   L FACTORY 4875 4884 4900 4958 4995 5032 5069 5099\n" +
                "vtxtable band 8 BAND_U   U FACTORY 5960 5980 6000 6020 6030 6040 6050 6060\n" +
                "vtxtable band 9 BAND_O   O FACTORY 5865 5845 5825 5805 5785 5765 5745 5725\n" +
                "vtxtable band 10 BAND_H   H FACTORY 5733 5752 5771 5790 5809 5828 5847 5866\n" +
                "vtxtable band 11 BAND_T   T FACTORY 5705 5685 5665 5645 5885 5905 5925 5945\n" +
                "vtxtable band 12 BAND_N   N FACTORY 5740 5760 5780 5800 5820 5840 5860 5880\n" +
                "vtxtable powerlevels 0\n" +
                "vtxtable powervalues \n" +
                "vtxtable powerlabels \n\n" +
                "save"
        },
        {
            name: "Sudoplatov 4.8-6.1G",
            photo: "./images/vtx/sudoplatov-4-8-6-1g.png",
            table: "# vtxtable (vtx_band_full_fixed.json)\n" +
                "vtxtable bands 12\n" +
                "vtxtable channels 8\n" +
                "vtxtable band 1 VTX_A    A CUSTOM 5474 5492 5510 5528 5546 5564 5582 5600\n" +
                "vtxtable band 2 VTX_B    B CUSTOM 5362 5399 5436 5473 5500 5547 5584 5621\n" +
                "vtxtable band 3 VTX_E    E CUSTOM 5300 5348 5366 5384 5400 5420 5438 5456\n" +
                "vtxtable band 4 VTX_F    F CUSTOM 5129 5159 5189 5219 5249 5279 5309 5339\n" +
                "vtxtable band 5 VTX_R    R CUSTOM 4990 5020 5050 5080 5110 5150 5170 5200\n" +
                "vtxtable band 6 VTX_P    P CUSTOM 5333 5373 5413 5453 5493 5533 5573 5613\n" +
                "vtxtable band 7 VTX_L    L CUSTOM 4875 4884 4900 4958 4995 5032 5069 5099\n" +
                "vtxtable band 8 VTX_U    U CUSTOM 5960 5980 6000 6020 6030 6040 6050 6060\n" +
                "vtxtable band 9 VTX_O    O CUSTOM 5865 5845 5825 5805 5785 5765 5745 5725\n" +
                "vtxtable band 10 VTX_H    H CUSTOM 5733 5752 5771 5790 5809 5828 5847 5866\n" +
                "vtxtable band 11 VTX_T    T CUSTOM 5705 5685 5665 5645 5885 5905 5925 5945\n" +
                "vtxtable band 12 VTX_N    N CUSTOM 5740 5760 5780 5800 5820 5840 5860 5880\n" +
                "vtxtable powerlevels 4\n" +
                "vtxtable powervalues 25 200 2000 4000\n" +
                "vtxtable powerlabels 25  200 2K  4K \n\n" +
                "save"
        },
        {
            name: 'Foxeer infinity 5W Custom Freg "БУМЕРАНГ 5.8"',
            photo: "./images/vtx/foxeer-infinity-5w-boomerang-5-8.png",
            table: "# vtxtable (BTFL_vtxtable_VT.40_20260131_175637_TBF78_FOXEERF405V2.json)\n" +
                "vtxtable bands 8\n" +
                "vtxtable channels 8\n" +
                "vtxtable band 1 BAND_A   A CUSTOM 5865 5845 5825 5805 5785 5765 5745 5725\n" +
                "vtxtable band 2 BAND_B   B CUSTOM 5733 5752 5771 5790 5809 5828 5847 5866\n" +
                "vtxtable band 3 BAND_E   E CUSTOM 5705 5685 5665 5645 5885 5905 5925 5945\n" +
                "vtxtable band 4 BAND_F   F CUSTOM 5740 5760 5780 5800 5820 5840 5860 5880\n" +
                "vtxtable band 5 BAND_X   X CUSTOM 5658 5695 5732 5769 5806 5843 5880 5917\n" +
                "vtxtable band 6 BAND_H   H CUSTOM 5653 5693 5733 5773 5813 5853 5893 5933\n" +
                "vtxtable band 7 BAND_O   O CUSTOM 5474 5492 5510 5528 5546 5564 5582 5600\n" +
                "vtxtable band 8 BAND_U   U CUSTOM 5325 5348 5336 5384 5402 5420 5438 5456\n" +
                "vtxtable powerlevels 5\n" +
                "vtxtable powervalues 25 100 200 400 600\n" +
                "vtxtable powerlabels 1   2   3   4   5  \n\n" +
                "save"
        },
        {
            name: "БУМЕРАНГ 3.3",
            photo: "./images/vtx/boomerang-3-3.png",
            table: "# vtxtable (Bumer 3.3.json)\n" +
                "vtxtable bands 5\n" +
                "vtxtable channels 8\n" +
                "vtxtable band 1 BAND_A   A CUSTOM 3320 3345 3370 3395 3420 3445 3470 3495\n" +
                "vtxtable band 2 BAND_B   B CUSTOM 3310 3330 3355 3380 3405 3430 3455 3480\n" +
                "vtxtable band 3 BAND_C   C CUSTOM 3490 3510 3530 3550 3570 3590 3610 3630\n" +
                "vtxtable band 4 BAND_D   D CUSTOM 3330 3350 3370 3390 3410 3430 3450 3470\n" +
                "vtxtable band 5 BAND_E   E CUSTOM 3170 3190 3210 3230 3250 3270 3290 3310\n" +
                "vtxtable powerlevels 5\n" +
                "vtxtable powervalues 25 100 200 400 600\n" +
                "vtxtable powerlabels 250 500 1   2   4  \n\n" +
                "save"
        },
        {
            name: 'BeastFPV "Горыныч" 5.8',
            photo: "./images/vtx/beastfpv-gorynych-5-8.png",
            table: "# vtxtable (BeastFPV_Горыныч_5.8.json)\n" +
                "vtxtable bands 8\n" +
                "vtxtable channels 8\n" +
                "vtxtable band 1 BOSCAM_A A CUSTOM 5865 5845 5825 5805 5785 5765 5745 5725\n" +
                "vtxtable band 2 BOSCAM_B B CUSTOM 5733 5752 5771 5790 5809 5828 5847 5866\n" +
                "vtxtable band 3 BOSCAM_E E CUSTOM 5705 5685 5665 5645 5885 5905 5925 5945\n" +
                "vtxtable band 4 BOSCAM_F F CUSTOM 5740 5760 5780 5800 5820 5840 5860 5880\n" +
                "vtxtable band 5 BOSCAM_R R CUSTOM 5658 5695 5732 5769 5806 5843 5880 5917\n" +
                "vtxtable band 6 BOSCAM_L L CUSTOM 5333 5373 5436 5453 5493 5533 5573 5613\n" +
                "vtxtable band 7 BOSCAM_U U CUSTOM 5325 5348 5366 5384 5402 5420 5438 5456\n" +
                "vtxtable band 8 BOSCAM_X X CUSTOM 4990 5020 5050 5080 5110 5140 5170 5200\n" +
                "vtxtable powerlevels 4\n" +
                "vtxtable powervalues 25 100 200 600\n" +
                "vtxtable powerlabels  50 1.0 2.5 5.0\n\n" +
                "save"
        },
        {
            name: "FF3237 3.3G",
            photo: "./images/vtx/ff3237.png",
            table: "# vtxtable (FF3237.json)\n" +
                "vtxtable bands 5\n" +
                "vtxtable channels 8\n" +
                "vtxtable band 1 VTX_A    A CUSTOM 3200 3220 3240 3260 3280 3300 3320 3340\n" +
                "vtxtable band 2 VTX_B    B CUSTOM 3360 3380 3400 3420 3440 3460 3480 3500\n" +
                "vtxtable band 3 VTX_C    C CUSTOM 3520 3540 3560 3580 3600 3620 3640 3680\n" +
                "vtxtable band 4 VTX_D    D CUSTOM 3210 3250 3290 3330 3370 3410 3450 3490\n" +
                "vtxtable band 5 VTX_E    E CUSTOM 3230 3290 3350 3410 3470 3530 3590 3700\n" +
                "vtxtable powerlevels 0\n" +
                "vtxtable powervalues \n" +
                "vtxtable powerlabels \n\n" +
                "save"
        },
        {
            name: "Peak Thor T78",
            photo: "./images/vtx/peak-thor-t78.png",
            table: "# vtxtable (BTFL_vtxtable_20260420_165804_TANTOF405.json)\n" +
                "vtxtable bands 5\n" +
                "vtxtable channels 8\n" +
                "vtxtable band 1 BOSCAM_A A FACTORY 7200 7220 7240 7260 7280 7300 7320 7340\n" +
                "vtxtable band 2 BOSCAM_B B FACTORY 7360 7380 7400 7420 7440 7460 7480 7500\n" +
                "vtxtable band 3 BOSCAM_E E FACTORY 7520 7540 7560 7580 7600 7620 7640 7680\n" +
                "vtxtable band 4 FATSHARK F FACTORY 7700 7720 7740 7760 7780 7800 7820 7840\n" +
                "vtxtable band 5 RACEBAND R FACTORY 7860 7880 7900 7920 7940 7960 7980 8000\n" +
                "vtxtable powerlevels 5\n" +
                "vtxtable powervalues 0 1 2 3 4\n" +
                "vtxtable powerlabels 25  200 500 1W  3W \n\n" +
                "save"
        }
    ];
    var selectedIndex = 0;
    var vtxRules = [];
    var defaultRanges = [
        [900, 1200],
        [1300, 1700],
        [1800, 2100]
    ];

    function setupSidebarTab(tab, linkClassName, iconClassName, labelClassName, text) {
        var link = tab.querySelector("a");
        link.className = linkClassName;
        link.title = text;
        link.setAttribute("aria-label", text);
        link.innerHTML = '<span class="' + iconClassName + '" title="' + text + '" aria-hidden="true"></span><span class="' + labelClassName + '">' + text + '</span>';
        tab.style.display = "block";
        tab.style.visibility = "visible";
    }

    function ensureTab() {
        var tabs = document.querySelector("#tabs ul.mode-connected-cli");
        if (tabs) {
            var tab = tabs.querySelector(".rus-config-donetsk-vtx-tables");
            if (!tab) {
                tab = document.createElement("li");
                tab.className = "tab_vtx_tables_rcd rus-config-donetsk-vtx-tables";
                tab.innerHTML = '<a href="#" class="vtx-ready-tab-link" title="' + tabText + '"></a>';
                tabs.appendChild(tab);
            }

            var dumpTab = tabs.querySelector(".rus-config-donetsk-ready-dumps");
            if (!dumpTab) {
                dumpTab = document.createElement("li");
                dumpTab.className = "tab_ready_dumps_rcd rus-config-donetsk-ready-dumps";
                dumpTab.innerHTML = '<a href="#" class="ready-dump-tab-link" title="' + dumpTabText + '"></a>';
            }

            if (tab.nextElementSibling !== dumpTab) {
                tabs.insertBefore(dumpTab, tab.nextElementSibling);
            }

            setupSidebarTab(tab, "vtx-ready-tab-link", "vtx-ready-tab-icon", "vtx-ready-tab-label", tabText);
            setupSidebarTab(dumpTab, "ready-dump-tab-link", "ready-dump-tab-icon", "ready-dump-tab-label", dumpTabText);
        }

        var disconnectedTabs = document.querySelector("#tabs ul.mode-disconnected");
        if (!disconnectedTabs) {
            return;
        }

        var escConfiguratorTab = disconnectedTabs.querySelector(".rus-config-donetsk-esc-configurator");
        if (!escConfiguratorTab) {
            escConfiguratorTab = document.createElement("li");
            escConfiguratorTab.className = "tab_esc_configurator_rcd rus-config-donetsk-esc-configurator";
            escConfiguratorTab.innerHTML = '<a href="#" class="esc-configurator-tab-link" title="' + escConfiguratorTabText + '"></a>';
        }

        var landingTab = disconnectedTabs.querySelector(".tab_landing") || disconnectedTabs.firstElementChild;
        if (landingTab && landingTab.nextElementSibling !== escConfiguratorTab) {
            disconnectedTabs.insertBefore(escConfiguratorTab, landingTab.nextElementSibling);
        } else if (!escConfiguratorTab.parentNode) {
            disconnectedTabs.insertBefore(escConfiguratorTab, disconnectedTabs.firstElementChild);
        }

        setupSidebarTab(escConfiguratorTab, "esc-configurator-tab-link", "esc-configurator-tab-icon", "esc-configurator-tab-label", escConfiguratorTabText);

        var elrsConfiguratorTab = disconnectedTabs.querySelector(".rus-config-donetsk-elrs-configurator");
        if (!elrsConfiguratorTab) {
            elrsConfiguratorTab = document.createElement("li");
            elrsConfiguratorTab.className = "tab_elrs_configurator_rcd rus-config-donetsk-elrs-configurator";
            elrsConfiguratorTab.innerHTML = '<a href="#" class="elrs-configurator-tab-link" title="' + elrsConfiguratorTabText + '"></a>';
        }

        if (escConfiguratorTab.parentNode && escConfiguratorTab.nextElementSibling !== elrsConfiguratorTab) {
            disconnectedTabs.insertBefore(elrsConfiguratorTab, escConfiguratorTab.nextElementSibling);
        } else if (!elrsConfiguratorTab.parentNode) {
            disconnectedTabs.appendChild(elrsConfiguratorTab);
        }

        setupSidebarTab(elrsConfiguratorTab, "elrs-configurator-tab-link", "elrs-configurator-tab-icon", "elrs-configurator-tab-label", elrsConfiguratorTabText);

        var guidesTab = disconnectedTabs.querySelector(".rus-config-donetsk-guides");
        if (!guidesTab) {
            guidesTab = document.createElement("li");
            guidesTab.className = "tab_guides_rcd rus-config-donetsk-guides";
            guidesTab.innerHTML = '<a href="#" class="guides-tab-link" title="' + guidesTabText + '"></a>';
        }

        if (elrsConfiguratorTab.parentNode && elrsConfiguratorTab.nextElementSibling !== guidesTab) {
            disconnectedTabs.insertBefore(guidesTab, elrsConfiguratorTab.nextElementSibling);
        } else if (!guidesTab.parentNode) {
            disconnectedTabs.appendChild(guidesTab);
        }

        setupSidebarTab(guidesTab, "guides-tab-link", "guides-tab-icon", "guides-tab-label", guidesTabText);

        var g13Tab = disconnectedTabs.querySelector(".rus-config-donetsk-g13");
        if (!g13Tab) {
            g13Tab = document.createElement("li");
            g13Tab.className = "tab_g13_rcd rus-config-donetsk-g13";
            g13Tab.innerHTML = '<a href="#" class="g13-tab-link" title="' + g13TabText + '"></a>';
        }

        if (guidesTab.parentNode && guidesTab.nextElementSibling !== g13Tab) {
            disconnectedTabs.insertBefore(g13Tab, guidesTab.nextElementSibling);
        } else if (!g13Tab.parentNode) {
            disconnectedTabs.appendChild(g13Tab);
        }

        setupSidebarTab(g13Tab, "g13-tab-link", "g13-tab-icon", "g13-tab-label", g13TabText);

        var offlineFirmwareTab = disconnectedTabs.querySelector(".rus-config-donetsk-offline-firmware");
        if (!offlineFirmwareTab) {
            offlineFirmwareTab = document.createElement("li");
            offlineFirmwareTab.className = "tab_offline_firmware_rcd rus-config-donetsk-offline-firmware";
            offlineFirmwareTab.innerHTML = '<a href="#" class="offline-firmware-tab-link" title="' + offlineFirmwareTabText + '"></a>';
        }

        var firmwareTab = disconnectedTabs.querySelector(".tab_firmware_flasher");
        if (firmwareTab && firmwareTab.nextElementSibling !== offlineFirmwareTab) {
            disconnectedTabs.insertBefore(offlineFirmwareTab, firmwareTab.nextElementSibling);
        } else if (!offlineFirmwareTab.parentNode) {
            disconnectedTabs.appendChild(offlineFirmwareTab);
        }

        setupSidebarTab(offlineFirmwareTab, "offline-firmware-tab-link", "offline-firmware-tab-icon", "offline-firmware-tab-label", offlineFirmwareTabText);

        var upravaTab = disconnectedTabs.querySelector(".rus-config-donetsk-uprava");
        if (!upravaTab) {
            upravaTab = document.createElement("li");
            upravaTab.className = "tab_uprava_rcd rus-config-donetsk-uprava";
            upravaTab.innerHTML = '<a href="#" class="uprava-tab-link" title="' + upravaTabText + '"></a>';
        }

        if (offlineFirmwareTab.parentNode && offlineFirmwareTab.nextElementSibling !== upravaTab) {
            disconnectedTabs.insertBefore(upravaTab, offlineFirmwareTab.nextElementSibling);
        } else if (!upravaTab.parentNode) {
            disconnectedTabs.appendChild(upravaTab);
        }

        setupSidebarTab(upravaTab, "uprava-tab-link", "uprava-tab-icon", "uprava-tab-label", upravaTabText);

        var programUpdateTab = disconnectedTabs.querySelector(".rus-config-donetsk-program-update");
        if (!programUpdateTab) {
            programUpdateTab = document.createElement("li");
            programUpdateTab.className = "tab_program_update_rcd rus-config-donetsk-program-update";
            programUpdateTab.innerHTML = '<a href="#" class="program-update-tab-link" title="' + programUpdateTabText + '"></a>';
        }

        if (upravaTab.parentNode && upravaTab.nextElementSibling !== programUpdateTab) {
            disconnectedTabs.insertBefore(programUpdateTab, upravaTab.nextElementSibling);
        } else if (!programUpdateTab.parentNode) {
            disconnectedTabs.appendChild(programUpdateTab);
        }

        setupSidebarTab(programUpdateTab, "program-update-tab-link", "program-update-tab-icon", "program-update-tab-label", programUpdateTabText);
    }
    function escapeHtml(value) {
        return String(value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");
    }

    function getSelectedTransmitter() {
        return transmitters[selectedIndex] || null;
    }

    function renderTransmitterOptions() {
        if (!transmitters.length) {
            return '<option value="">\u041f\u043e\u043a\u0430 \u043d\u0435\u0442 \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d\u043d\u044b\u0445 VTX</option>';
        }

        return transmitters.map(function (item, index) {
            return '<option value="' + index + '"' + (index === selectedIndex ? " selected" : "") + ">" + escapeHtml(item.name) + "</option>";
        }).join("");
    }

    function renderPhoto(item) {
        if (item && item.photo) {
            return '<img src="' + escapeHtml(item.photo) + '" alt="' + escapeHtml(item.name) + '">';
        }

        return '<div class="vtx-photo-placeholder">' + emptyPhotoText + '</div>';
    }

    function stripFinalSave(table) {
        return String(table || "").replace(/\s*save\s*$/i, "").replace(/\s+$/g, "");
    }

    function readVtxTableInfo(item) {
        var info = {
            bands: [],
            channels: 8,
            powerLevels: []
        };
        var powerValues = [];
        var powerLabels = [];
        var bandCount = 0;

        String(item && item.table ? item.table : "").split(/\r?\n/).forEach(function (line) {
            var parts = line.trim().split(/\s+/);
            if (parts[0] !== "vtxtable") {
                return;
            }

            if (parts[1] === "bands") {
                bandCount = parseInt(parts[2], 10) || 0;
            }

            if (parts[1] === "channels") {
                info.channels = parseInt(parts[2], 10) || info.channels;
            }

            if (parts[1] === "band") {
                info.bands.push({
                    number: parseInt(parts[2], 10) || 0,
                    name: parts[3] || ("BAND_" + parts[2]),
                    letter: parts[4] || "",
                    frequencies: parts.slice(6).map(function (value) {
                        return parseInt(value, 10) || 0;
                    })
                });
            }

            if (parts[1] === "powervalues") {
                powerValues = parts.slice(2);
            }

            if (parts[1] === "powerlabels") {
                powerLabels = parts.slice(2);
            }
        });

        if (!info.bands.length && bandCount > 0) {
            for (var band = 1; band <= bandCount; band += 1) {
                info.bands.push({
                    number: band,
                    name: "BAND_" + band,
                    letter: String(band),
                    frequencies: []
                });
            }
        }

        var powerCount = Math.max(powerValues.length, powerLabels.length);
        for (var power = 0; power < powerCount; power += 1) {
            info.powerLevels.push({
                number: power + 1,
                value: powerValues[power] || "",
                label: powerLabels[power] || powerValues[power] || ("Level " + (power + 1))
            });
        }

        return info;
    }

    function renderOption(value, label, selected) {
        return '<option value="' + escapeHtml(value) + '"' + (Number(value) === Number(selected) ? " selected" : "") + ">" + escapeHtml(label) + "</option>";
    }

    function renderAuxOptions(rule) {
        var options = [];
        for (var aux = 0; aux < 12; aux += 1) {
            options.push(renderOption(aux, "AUX" + (aux + 1) + " CH" + (aux + 5) + " (CLI" + aux + ")", rule.aux));
        }
        return options.join("");
    }

    function renderBandOptions(rule, info) {
        return [renderOption(0, "\u041d\u0435 \u043c\u0435\u043d\u044f\u0442\u044c", rule.band)].concat(info.bands.map(function (band) {
            var label = band.number + ": " + band.name + (band.letter ? " (" + band.letter + ")" : "");
            return renderOption(band.number, label, rule.band);
        })).join("");
    }

    function renderChannelOptions(rule, info) {
        var selectedBand = info.bands.find(function (band) {
            return Number(band.number) === Number(rule.band);
        });
        var channelCount = selectedBand && selectedBand.frequencies.length ? selectedBand.frequencies.length : info.channels;
        var options = [renderOption(0, "\u041d\u0435 \u043c\u0435\u043d\u044f\u0442\u044c", rule.channel)];

        for (var channel = 1; channel <= channelCount; channel += 1) {
            var frequency = selectedBand && selectedBand.frequencies[channel - 1];
            var label = "CH " + channel;
            if (frequency) {
                label += " - " + frequency + " MHz";
            } else if (selectedBand) {
                label += " - \u0437\u0430\u0431\u043b.";
            }
            options.push(renderOption(channel, label, rule.channel));
        }

        return options.join("");
    }

    function renderPowerOptions(rule, info) {
        return [renderOption(0, "\u041d\u0435 \u043c\u0435\u043d\u044f\u0442\u044c", rule.power)].concat(info.powerLevels.map(function (power) {
            var suffix = power.value ? " / value " + power.value : "";
            return renderOption(power.number, power.number + ": " + power.label + suffix, rule.power);
        })).join("");
    }

    function createDefaultRule(index) {
        var range = defaultRanges[index % defaultRanges.length];
        return {
            aux: 7,
            band: 0,
            channel: 0,
            power: 0,
            rangeStart: range[0],
            rangeEnd: range[1]
        };
    }

    function clampRangeValue(value, fallback) {
        var parsed = parseInt(value, 10);
        if (Number.isNaN(parsed)) {
            return fallback;
        }
        return Math.max(900, Math.min(2100, parsed));
    }

    function buildVtxCommand(rule, index) {
        return [
            "vtx",
            index,
            parseInt(rule.aux, 10) || 0,
            parseInt(rule.band, 10) || 0,
            parseInt(rule.channel, 10) || 0,
            parseInt(rule.power, 10) || 0,
            clampRangeValue(rule.rangeStart, 900),
            clampRangeValue(rule.rangeEnd, 2100)
        ].join(" ");
    }

    function buildCombinedTable(item) {
        if (!item || !item.table) {
            return emptyTableText;
        }

        var baseTable = stripFinalSave(item.table);
        if (!vtxRules.length) {
            return baseTable + "\n\nsave";
        }

        return baseTable + "\n\n# VTX\n" + vtxRules.map(buildVtxCommand).join("\n") + "\n\nsave";
    }

    function renderTable(item) {
        return escapeHtml(buildCombinedTable(item));
    }

    function renderVtxRule(rule, index, info) {
        var addButton = index === vtxRules.length - 1
            ? '<button type="button" class="vtx-add-rule" id="vtx-add-rule"><span aria-hidden="true">+</span><span>\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u043a\u043e\u043c\u0430\u043d\u0434\u0443 VTX</span></button>'
            : "";

        return [
            '<div class="vtx-rule-card" data-rule-index="' + index + '">',
            '  <div class="vtx-rule-head">',
            '    <h3>VTX \u043f\u0440\u0430\u0432\u0438\u043b\u043e ' + index + '</h3>',
            '    <div class="vtx-rule-actions">',
            addButton,
            '      <button type="button" class="vtx-remove-rule" data-remove-rule="' + index + '" title="\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u043f\u0440\u0430\u0432\u0438\u043b\u043e" aria-label="\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u043f\u0440\u0430\u0432\u0438\u043b\u043e"><span aria-hidden="true">&times;</span></button>',
            '    </div>',
            '  </div>',
            '  <div class="vtx-rule-grid">',
            '    <label class="vtx-rule-field"><span>AUX</span><select class="vtx-rule-control" data-field="aux">' + renderAuxOptions(rule) + '</select></label>',
            '    <label class="vtx-rule-field"><span>Band</span><select class="vtx-rule-control" data-field="band">' + renderBandOptions(rule, info) + '</select></label>',
            '    <label class="vtx-rule-field"><span>Channel</span><select class="vtx-rule-control" data-field="channel">' + renderChannelOptions(rule, info) + '</select></label>',
            '    <label class="vtx-rule-field"><span>Power Level</span><select class="vtx-rule-control" data-field="power">' + renderPowerOptions(rule, info) + '</select></label>',
            '    <label class="vtx-rule-field vtx-rule-range"><span>Range</span><span class="vtx-range-inputs"><input type="number" min="900" max="2100" step="1" class="vtx-rule-control" data-field="rangeStart" value="' + escapeHtml(rule.rangeStart) + '"><b>-</b><input type="number" min="900" max="2100" step="1" class="vtx-rule-control" data-field="rangeEnd" value="' + escapeHtml(rule.rangeEnd) + '"></span></label>',
            '  </div>',
            '</div>'
        ].join("");
    }

    function renderVtxSwitching(item) {
        var info = readVtxTableInfo(item);
        var emptyState = !vtxRules.length
            ? '<div class="vtx-empty-rules"><button type="button" class="vtx-add-rule" id="vtx-add-rule"><span aria-hidden="true">+</span><span>\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u043a\u043e\u043c\u0430\u043d\u0434\u0443 VTX</span></button></div>'
            : "";

        return [
            '<section class="vtx-switch-card">',
            '  <div class="vtx-switch-title">',
            '    <h2>\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u043f\u0435\u0440\u0435\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f VTX</h2>',
            vtxRules.length ? "" : '    <span class="vtx-no-rules">\u043d\u0438 \u043e\u0434\u043d\u043e \u0437\u043d\u0430\u0447\u0435\u043d\u0438\u0435 \u043d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u043e</span>',
            '  </div>',
            emptyState,
            '  <div class="vtx-rule-list">',
            vtxRules.map(function (rule, index) {
                return renderVtxRule(rule, index, info);
            }).join(""),
            '  </div>',
            '</section>'
        ].join("");
    }

    function refreshCliPreview() {
        var cli = document.getElementById("vtx-ready-cli");
        if (cli) {
            cli.textContent = buildCombinedTable(getSelectedTransmitter());
        }
    }

    function renderVtxTablesTab() {
        var content = document.getElementById("content");
        if (!content) {
            return;
        }

        var item = getSelectedTransmitter();

        content.innerHTML = [
            '<div class="tab-vtx-ready-tables">',
            '  <div class="content_wrapper">',
            '    <div class="vtx-ready-header">',
            '      <h1>VTX \u0433\u043e\u0442\u043e\u0432\u044b\u0435 \u0442\u0430\u0431\u043b\u0438\u0446\u044b</h1>',
            '      <button class="vtx-ready-help">\u0411\u0410\u0417\u0410 \u0417\u041d\u0410\u041d\u0418\u0419</button>',
            '    </div>',
            '    <div class="vtx-ready-layout">',
            '      <section class="vtx-picker-card">',
            '        <h2>\u0412\u044b\u0431\u043e\u0440 \u0432\u0438\u0434\u0435\u043e\u043f\u0435\u0440\u0435\u0434\u0430\u0442\u0447\u0438\u043a\u0430</h2>',
            '        <select id="vtx-ready-select">' + renderTransmitterOptions() + '</select>',
            '      </section>',
            renderVtxSwitching(item),
            '      <section class="vtx-photo-card">',
            '        <h2>\u0424\u043e\u0442\u043e</h2>',
            '        <div class="vtx-photo-frame">' + renderPhoto(item) + '</div>',
            '      </section>',
            '      <section class="vtx-cli-card">',
            '        <div class="vtx-cli-title">',
            '          <h2>CLI VTX Table</h2>',
            '          <button class="vtx-copy-button" id="vtx-copy-table">\u0421\u043a\u043e\u043f\u0438\u0440\u043e\u0432\u0430\u0442\u044c</button>',
            '        </div>',
            '        <pre id="vtx-ready-cli">' + renderTable(item) + '</pre>',
            '      </section>',
            '      <section class="vtx-warning-card">',
            '        <h2>\u0418\u043d\u0441\u0442\u0440\u0443\u043a\u0446\u0438\u044f</h2>',
            '        <p>\u0412\u043d\u0438\u043c\u0430\u043d\u0438\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u044b\u0435 \u0437\u043d\u0430\u0447\u0435\u043d\u0438\u044f \u0441\u043a\u043e\u043f\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0438 \u0432\u0441\u0442\u0430\u0432\u0438\u0442\u044c \u0432 \u043a\u043e\u043c\u0430\u043d\u0434\u043d\u0443\u044e \u0441\u0442\u0440\u043e\u043a\u0443 , \u043f\u043e\u0441\u043b\u0435 \u0447\u0435\u0433\u043e \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u044b\u0435 \u0437\u043d\u0430\u0447\u0435\u043d\u0438\u044f \u0431\u0443\u0434\u0443\u0442 \u043d\u0430\u0437\u043d\u0430\u0447\u0435\u043d\u044b \u0432 \u043f\u043e\u043b\u0435\u0442\u043d\u043e\u043c \u043a\u043e\u043d\u0442\u0440\u043e\u043b\u043b\u0435\u0440\u0435</p>',
            '      </section>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join("");
    }


    function getSelectedDumpDrone() {
        return readyDumps[selectedDumpIndex] || null;
    }

    function getDumpControllers(item) {
        if (!item) {
            return [];
        }

        if (Array.isArray(item.controllers)) {
            return item.controllers;
        }

        if (Array.isArray(item.dumps)) {
            return item.dumps;
        }

        if (item.dumpPath || item.controller || item.flightController) {
            return [item];
        }

        return [];
    }

    function getDumpControllerName(item) {
        return item && (item.name || item.controller || item.flightController || item.fc || item.board) || "";
    }

    function getSelectedDump() {
        var drone = getSelectedDumpDrone();
        var controllers = getDumpControllers(drone);
        var controller = controllers[selectedDumpControllerIndex] || controllers[0] || {};

        if (!drone) {
            return null;
        }

        return {
            name: drone.name,
            photo: controller.photo || drone.photo,
            note: controller.note || drone.note,
            dumpPath: controller.dumpPath || drone.dumpPath,
            controllerName: getDumpControllerName(controller)
        };
    }

    function renderDumpOptions() {
        if (!readyDumps.length) {
            return '<option value="">\u041f\u043e\u043a\u0430 \u043d\u0435\u0442 \u0433\u043e\u0442\u043e\u0432\u044b\u0445 DUMP</option>';
        }

        return readyDumps.map(function (item, index) {
            return '<option value="' + index + '"' + (index === selectedDumpIndex ? " selected" : "") + '>' + escapeHtml(item.name) + '</option>';
        }).join("");
    }

    function renderDumpControllerSelect(item) {
        var controllers = getDumpControllers(item);

        if (controllers.length <= 1 && !(item && item.multiDump)) {
            return "";
        }

        return [
            '<div class="dump-controller-select-block">',
            '  <h2>\u041f\u043e\u043b\u0435\u0442\u043d\u044b\u0439 \u043a\u043e\u043d\u0442\u0440\u043e\u043b\u043b\u0435\u0440</h2>',
            '  <select id="dump-controller-select">',
            controllers.map(function (controller, index) {
                return '<option value="' + index + '"' + (index === selectedDumpControllerIndex ? " selected" : "") + '>' + escapeHtml(getDumpControllerName(controller) || ("\u0412\u0430\u0440\u0438\u0430\u043d\u0442 DUMP " + (index + 1))) + '</option>';
            }).join(""),
            '  </select>',
            '</div>'
        ].join("");
    }

    function renderDumpPhoto(item) {
        if (item && item.photo) {
            return '<img src="' + escapeHtml(item.photo) + '" alt="' + escapeHtml(item.name) + '">';
        }

        return '<div class="dump-drone-photo-placeholder">\u0424\u043e\u0442\u043e \u0434\u0440\u043e\u043d\u0430 \u0431\u0443\u0434\u0435\u0442 \u0437\u0434\u0435\u0441\u044c</div>';
    }

    function renderDumpNote(item) {
        if (item && item.note) {
            return escapeHtml(item.note).replace(/\n/g, "<br>");
        }

        return '\u0412\u044b\u0431\u0435\u0440\u0438 \u0434\u0440\u043e\u043d, \u0438 \u0437\u0434\u0435\u0441\u044c \u043f\u043e\u044f\u0432\u0438\u0442\u0441\u044f \u043e\u043f\u0438\u0441\u0430\u043d\u0438\u0435: \u043f\u043e\u043b\u0435\u0442\u043d\u044b\u0439 \u043a\u043e\u043d\u0442\u0440\u043e\u043b\u043b\u0435\u0440, \u043f\u0440\u043e\u0448\u0438\u0432\u043a\u0430, VTX, RX UART \u0438 VTX UART.';
    }

    function setDumpLoadProgress(value, text) {
        var progress = document.getElementById("dump-load-progress");
        var status = document.getElementById("dump-load-status");

        if (progress) {
            progress.value = Math.max(0, Math.min(100, value));
        }

        if (status && text) {
            status.textContent = text;
        }
    }

    function showDumpLoadDialog(item) {
        var dialog = document.getElementById("dump-load-dialog");
        var title = document.getElementById("dump-load-title");

        if (title) {
            title.textContent = item && item.name ? "\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 DUMP: " + item.name : "\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 DUMP";
        }

        setDumpLoadProgress(0, "\u041f\u043e\u0434\u0433\u043e\u0442\u043e\u0432\u043a\u0430 \u0434\u0430\u043c\u043f\u0430...");

        if (dialog && typeof dialog.showModal === "function" && !dialog.open) {
            dialog.showModal();
        } else if (dialog) {
            dialog.setAttribute("open", "open");
        }
    }

    function closeDumpLoadDialog() {
        var dialog = document.getElementById("dump-load-dialog");

        if (dialog && typeof dialog.close === "function" && dialog.open) {
            dialog.close();
        } else if (dialog) {
            dialog.removeAttribute("open");
        }
    }

    function waitDump(ms) {
        return new Promise(function (resolve) {
            window.setTimeout(resolve, ms);
        });
    }

    function getReadyDumpText(item) {
        return fetch(item.dumpPath, { cache: "no-store" }).then(function (response) {
            if (!response.ok) {
                throw new Error("\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u0440\u043e\u0447\u0438\u0442\u0430\u0442\u044c DUMP: " + response.status);
            }

            return response.text();
        });
    }

    function getSpecialForceScriptUrl() {
        var script = document.querySelector('script[src$="rus-config-donetsk-vtx-tables.js"]');

        return script && script.src ? script.src : window.location.href;
    }

    function importModuleNearScript(path) {
        return import(new URL(path, getSpecialForceScriptUrl()).href);
    }

    function normalizeDumpCommands(dumpText) {
        var lines = dumpText.split(/\r?\n/)
            .map(function (line) {
                return line.trim();
            })
            .filter(function (line) {
                return line !== "";
            });

        while (lines.length && lines[lines.length - 1].toLowerCase() === "save") {
            lines.pop();
        }

        return lines;
    }

    function waitForDumpCliReady(engine, CONFIGURATOR) {
        var startedAt = Date.now();
        var repeatedEnterSent = false;

        return new Promise(function (resolve, reject) {
            function checkReady() {
                if (CONFIGURATOR.cliEngineValid) {
                    resolve();
                    return;
                }

                if (!repeatedEnterSent && Date.now() - startedAt > 900) {
                    repeatedEnterSent = true;
                    engine.enterCliMode();
                }

                if (Date.now() - startedAt > 4500) {
                    reject(new Error("Не удалось войти в CLI. Проверь, что дрон подключен и не занят другой вкладкой."));
                    return;
                }

                window.setTimeout(checkReady, 100);
            }

            checkReady();
        });
    }

    function sendDumpLinesSlowly(engine, lines) {
        var total = lines.length;

        return lines.reduce(function (promise, line, index) {
            return promise.then(function () {
                var command = String(line || "").trim();

                if (!command) {
                    return Promise.resolve();
                }

                return new Promise(function (resolve) {
                    var delay = command.toLowerCase().startsWith("profile") ? 160 : 45;
                    var progress = 12 + Math.round(((index + 1) / Math.max(1, total)) * 76);

                    setDumpLoadProgress(progress, "Загрузка DUMP... " + (index + 1) + " / " + total);
                    engine.sendLine(command, function () {
                        window.setTimeout(resolve, delay);
                    });
                });
            });
        }, Promise.resolve());
    }

    function waitForReconnectOrTimeout(reinitializeConnection, GUI) {
        if (typeof reinitializeConnection !== "function") {
            return waitDump(1200);
        }

        return new Promise(function (resolve) {
            var resolved = false;

            function finish() {
                if (!resolved) {
                    resolved = true;
                    resolve();
                }
            }

            try {
                if (!GUI || GUI.connected_to || GUI.connecting_to) {
                    reinitializeConnection(finish);
                } else {
                    finish();
                }
            } catch (error) {
                finish();
            }

            waitDump(12000).then(finish);
        });
    }

    function sendDumpTextToFlightController(dumpText) {
        var lines = normalizeDumpCommands(dumpText);

        if (!lines.length) {
            throw new Error("DUMP пустой.");
        }

        return Promise.all([
            importModuleNearScript("../presets.js"),
            importModuleNearScript("../common.js"),
            importModuleNearScript("../jquery.js"),
            importModuleNearScript("main.js")
        ]).then(function (modules) {
            var presetsModule = modules[0];
            var commonModule = modules[1];
            var jqueryModule = modules[2];
            var mainModule = modules[3];
            var CliEngine = presetsModule && presetsModule.CliEngine;
            var CONFIGURATOR = commonModule && commonModule.C;
            var $ = (jqueryModule && jqueryModule.$) || window.$;
            var TABS = mainModule && mainModule.T;
            var GUI = mainModule && mainModule.G;
            var reinitializeConnection = mainModule && mainModule.l;

            if (!CliEngine || !CONFIGURATOR || !$ || !TABS) {
                throw new Error("Не удалось запустить CLI-загрузчик.");
            }

            if (GUI && !GUI.connected_to && !GUI.connecting_to) {
                throw new Error("Сначала подключи дрон, потом загружай DUMP.");
            }

            var engine = new CliEngine(null);
            var previousPresetsRead = TABS.presets && TABS.presets.read;

            if (!TABS.presets) {
                TABS.presets = {};
            }

            TABS.presets.read = function (readInfo) {
                engine.readSerial(readInfo);
            };

            engine.setUi($("#dump-cli-window"), $("#dump-cli-window-wrapper"), $("#dump-cli-command"));
            CONFIGURATOR.cliActive = false;
            CONFIGURATOR.cliEngineActive = true;
            CONFIGURATOR.cliEngineValid = false;

            function restoreReadHandler() {
                if (TABS.presets) {
                    TABS.presets.read = previousPresetsRead;
                }

                CONFIGURATOR.cliEngineActive = false;
                CONFIGURATOR.cliEngineValid = false;
            }

            setDumpLoadProgress(10, "Переход в CLI...");
            engine.enterCliMode();

            return waitForDumpCliReady(engine, CONFIGURATOR)
                .then(function () {
                    return sendDumpLinesSlowly(engine, lines);
                })
                .then(function () {
                    setDumpLoadProgress(92, "Сохранение в FC...");
                    engine.sendLine("save");
                    return waitDump(1400);
                })
                .then(function () {
                    restoreReadHandler();
                    setDumpLoadProgress(96, "Перезапуск подключения...");
                    return waitForReconnectOrTimeout(reinitializeConnection, GUI);
                })
                .catch(function (error) {
                    restoreReadHandler();
                    throw error;
                });
        });
    }
    function loadSelectedDump() {
        var item = getSelectedDump();
        if (!item || !item.dumpPath) {
            window.alert("DUMP для выбранного дрона пока не добавлен.");
            return;
        }

        showDumpLoadDialog(item);
        getReadyDumpText(item)
            .then(function (dumpText) {
                setDumpLoadProgress(8, "\u0424\u0430\u0439\u043b DUMP \u043f\u0440\u043e\u0447\u0438\u0442\u0430\u043d...");
                return sendDumpTextToFlightController(dumpText);
            })
            .then(function () {
                setDumpLoadProgress(100, "\u0413\u043e\u0442\u043e\u0432\u043e.");
                return waitDump(450);
            })
            .then(closeDumpLoadDialog)
            .catch(function (error) {
                closeDumpLoadDialog();
                window.alert((error && error.message) || "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044c DUMP.");
            });
    }
    function renderReadyDumpsTab() {
        var content = document.getElementById("content");
        if (!content) {
            return;
        }

        var dumpDrone = getSelectedDumpDrone();
        var dumpItem = getSelectedDump();

        content.innerHTML = [
            '<div class="tab-ready-dumps">',
            '  <div class="content_wrapper">',
            '    <div class="vtx-ready-header dump-ready-header">',
            '      <h1>' + dumpTabText + '</h1>',
            '      <button class="vtx-ready-help">\u0411\u0410\u0417\u0410 \u0417\u041d\u0410\u041d\u0418\u0419</button>',
            '    </div>',
            '    <section class="dump-ready-layout">',
            '      <div class="dump-drone-select-card">',
            '        <h2>\u0412\u044b\u0431\u043e\u0440 \u043d\u0430\u0438\u043c\u0435\u043d\u043e\u0432\u0430\u043d\u0438\u044f \u0434\u0440\u043e\u043d\u0430</h2>',
            '        <div class="dump-drone-select-row">',
            '          <select id="dump-drone-select">' + renderDumpOptions() + '</select>',
            '        </div>',
            renderDumpControllerSelect(dumpDrone),
            '      </div>',
            '      <div class="dump-drone-photo-card">',
            '        <h2>\u0424\u043e\u0442\u043e \u0434\u0440\u043e\u043d\u0430</h2>',
            '        <div class="dump-drone-photo-frame">' + renderDumpPhoto(dumpItem) + '</div>',
            '      </div>',
            '      <div class="dump-drone-note-card">',
            '        <h2>\u041f\u0440\u0438\u043c\u0435\u0447\u0430\u043d\u0438\u0435</h2>',
            '        <div class="dump-drone-note-text">' + renderDumpNote(dumpItem) + '</div>',
            '      </div>',
            '      <div class="dump-drone-actions-card">',
            '        <button type="button" id="dump-load-button" class="dump-load-button"' + (dumpItem && dumpItem.dumpPath ? '' : ' disabled') + '>\u0417\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044c DUMP</button>',
            '      </div>',
            '    </section>',
            '    <dialog id="dump-load-dialog" class="dump-load-dialog">',
            '      <h2 id="dump-load-title">\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 DUMP</h2>',
            '      <p id="dump-load-status">\u041f\u043e\u0434\u0433\u043e\u0442\u043e\u0432\u043a\u0430 \u0434\u0430\u043c\u043f\u0430...</p>',
            '      <progress id="dump-load-progress" max="100" value="0"></progress>',
            '      <div class="dump-cli-hidden" aria-hidden="true">',
            '        <div id="dump-cli-window"><div id="dump-cli-window-wrapper"></div></div>',
            '        <textarea id="dump-cli-command"></textarea>',
            '      </div>',
            '    </dialog>',
            '  </div>',
            '</div>'
        ].join("");
    }


    function getSelectedOfflineFirmwareTarget() {
        return offlineFirmwareTargets[selectedOfflineFirmwareIndex] || null;
    }

    function renderOfflineFirmwareOptions() {
        if (!offlineFirmwareTargets.length) {
            return '<option value="">Пока нет добавленных прошивок</option>';
        }

        return offlineFirmwareTargets.map(function (item, index) {
            return '<option value="' + index + '"' + (index === selectedOfflineFirmwareIndex ? ' selected' : '') + '>' + escapeHtml(item.name) + '</option>';
        }).join('');
    }

    function renderOfflineFirmwareSelectedDetails() {
        var item = getSelectedOfflineFirmwareTarget();

        if (!item) {
            return '<div class="offline-firmware-empty">Список прошивок пока не добавлен.</div>';
        }
        var firmwareStatus = item.hasFirmware ? (item.firmwareVersion || 'версия не указана') : 'прошивка не добавлена';
        var offlineNote = item.offlineNote ? '<div class="offline-firmware-selected-note">' + escapeHtml(item.offlineNote) + '</div>' : '';

        return [
            '<div class="offline-firmware-selected-title">' + escapeHtml(item.name) + '</div>',
            '<div class="offline-firmware-selected-path">Прошивка: <code>' + escapeHtml(firmwareStatus) + '</code></div>',
            '<div class="offline-firmware-selected-path">Наименование полетного контроллера: <code>' + escapeHtml(item.target || item.name || '') + '</code></div>',
            offlineNote,
            '<div class="offline-firmware-selected-hint">Прошивка без DUMP</div>'
        ].join('');
    }

    function normalizeOfflineFirmwareTarget(value) {
        return String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    }

    function findOfflineFirmwareTargetByBoard(boardName) {
        var detected = normalizeOfflineFirmwareTarget(boardName);

        if (!detected) {
            return -1;
        }

        for (var index = 0; index < offlineFirmwareTargets.length; index += 1) {
            var item = offlineFirmwareTargets[index];
            var candidates = [item.target, item.name].concat(item.aliases || []);

            for (var candidateIndex = 0; candidateIndex < candidates.length; candidateIndex += 1) {
                var target = normalizeOfflineFirmwareTarget(candidates[candidateIndex]);

                if (target && (target === detected || detected.indexOf(target) !== -1 || target.indexOf(detected) !== -1)) {
                    return index;
                }
            }
        }

        return -1;
    }

    function getFirmwareFlasherModule() {
        return importModuleNearScript('../firmware_flasher.js').then(function (module) {
            if (!module || !module.firmware_flasher) {
                throw new Error('Не удалось открыть модуль прошивальщика.');
            }

            return module.firmware_flasher;
        });
    }

    function getOfflineFirmwareFileType(item) {
        var fileName = String((item && item.fileName) || '').toLowerCase();
        var match = fileName.match(/\.([a-z0-9]+)$/);

        return match ? match[1] : 'hex';
    }

    function getOfflineFirmwareData(item) {
        if (!item || !item.firmwarePath) {
            return Promise.reject(new Error('Файл прошивки для выбранного полетного контроллера пока не добавлен.'));
        }

        var fileType = getOfflineFirmwareFileType(item);

        return fetch(item.firmwarePath, { cache: 'no-store' }).then(function (response) {
            if (!response.ok) {
                throw new Error('Файл прошивки не найден: offline-firmware/' + (item.fileName || ''));
            }

            if (fileType === 'bin') {
                return response.arrayBuffer().then(function (buffer) {
                    return {
                        type: 'bin',
                        buffer: buffer,
                    };
                });
            }

            if (fileType === 'hex') {
                return response.text().then(function (text) {
                    return {
                        type: 'hex',
                        text: text,
                    };
                });
            }

            throw new Error('Поддерживаются только файлы прошивки HEX или BIN.');
        });
    }

    function setOfflineFirmwareMessage(message, type) {
        var box = document.getElementById('offline-firmware-message');

        if (!box) {
            return;
        }

        box.textContent = message || '';
        box.className = 'offline-firmware-message' + (type ? ' is-' + type : '');
    }

    function setOfflineFirmwareBusy(isBusy) {
        document.querySelectorAll('.offline-firmware-button').forEach(function (button) {
            var requiresTarget = button.dataset.requiresTarget === 'true';
            button.disabled = Boolean(isBusy) || (requiresTarget && !offlineFirmwareTargets.length);
        });
    }

    function updateOfflineFirmwareTargetInfo() {
        var details = document.getElementById('offline-firmware-selected-info');
        var select = document.getElementById('offline-firmware-target-select');

        if (select) {
            select.value = String(selectedOfflineFirmwareIndex);
        }

        if (details) {
            details.innerHTML = renderOfflineFirmwareSelectedDetails();
        }
    }

    function refreshOfflineFirmwareDfuIndicator() {
        var light = document.getElementById('offline-firmware-dfu-light');
        var text = document.getElementById('offline-firmware-dfu-text');

        if (!light || !text) {
            return Promise.resolve(false);
        }

        return getFirmwareFlasherModule()
            .then(function (flasher) {
                return flasher.isDfuMode();
            })
            .then(function (isDfu) {
                light.classList.toggle('is-dfu', Boolean(isDfu));
                light.classList.toggle('not-dfu', !isDfu);
                text.textContent = isDfu ? 'Полетный контроллер в DFU' : 'Полетный контроллер не в DFU';
                return isDfu;
            })
            .catch(function () {
                light.classList.remove('is-dfu');
                light.classList.add('not-dfu');
                text.textContent = 'Полетный контроллер не в DFU';
                return false;
            });
    }

    function stopOfflineFirmwareDfuPolling() {
        if (offlineFirmwareDfuTimer) {
            window.clearInterval(offlineFirmwareDfuTimer);
            offlineFirmwareDfuTimer = null;
        }
    }

    function startOfflineFirmwareDfuPolling() {
        stopOfflineFirmwareDfuPolling();
        refreshOfflineFirmwareDfuIndicator();
        offlineFirmwareDfuTimer = window.setInterval(function () {
            if (!document.getElementById('offline-firmware-dfu-light')) {
                stopOfflineFirmwareDfuPolling();
                return;
            }

            refreshOfflineFirmwareDfuIndicator();
        }, 2000);
    }

    function detectOfflineFirmwareTarget() {
        setOfflineFirmwareBusy(true);
        setOfflineFirmwareMessage('Автоопределение полетного контроллера...', 'neutral');

        getFirmwareFlasherModule()
            .then(function (flasher) {
                return flasher.detectConnectedBoardName();
            })
            .then(function (boardName) {
                var index = findOfflineFirmwareTargetByBoard(boardName);

                if (index < 0) {
                    setOfflineFirmwareMessage('Вашего полетного контроллера нет в списке', 'error');
                    return;
                }

                selectedOfflineFirmwareIndex = index;
                updateOfflineFirmwareTargetInfo();
                setOfflineFirmwareMessage('Найдено: ' + offlineFirmwareTargets[index].name, 'ok');
            })
            .catch(function (error) {
                var message = (error && error.message) || 'Вашего полетного контроллера нет в списке';
                setOfflineFirmwareMessage(message, 'error');
            })
            .then(function () {
                setOfflineFirmwareBusy(false);
                refreshOfflineFirmwareDfuIndicator();
            });
    }

    function enterOfflineFirmwareDfu() {
        setOfflineFirmwareBusy(true);
        setOfflineFirmwareMessage('Перевод полетного контроллера в DFU...', 'neutral');

        getFirmwareFlasherModule()
            .then(function (flasher) {
                return flasher.enterDfuMode();
            })
            .then(function () {
                setOfflineFirmwareMessage('Полетный контроллер в DFU.', 'ok');
            })
            .catch(function (error) {
                setOfflineFirmwareMessage((error && error.message) || 'Не удалось перейти в DFU.', 'error');
            })
            .then(function () {
                setOfflineFirmwareBusy(false);
                refreshOfflineFirmwareDfuIndicator();
            });
    }

    function installOfflineFirmware() {
        var item = getSelectedOfflineFirmwareTarget();

        if (!item) {
            setOfflineFirmwareMessage('Выбери полетный контроллер.', 'error');
            return;
        }

        setOfflineFirmwareBusy(true);
        setOfflineFirmwareMessage('Проверка DFU...', 'neutral');

        getFirmwareFlasherModule()
            .then(function (flasher) {
                return flasher.isDfuMode().then(function (isDfu) {
                    if (!isDfu) {
                        throw new Error('Введите полетный контроллер в режим DFU');
                    }

                    setOfflineFirmwareMessage('Чтение файла прошивки...', 'neutral');
                    return getOfflineFirmwareData(item)
                        .then(function (firmwareData) {
                            return flasher.loadOfflineFirmwareData({
                                target: item.target || item.name,
                                filename: item.fileName || item.name + '.hex',
                                text: firmwareData.text,
                                buffer: firmwareData.buffer,
                                baseAddress: item.baseAddress || 0x08000000,
                            });
                        })
                        .then(function () {
                            return flasher.flashOfflineFirmwareInDfu();
                        });
                });
            })
            .then(function () {
                setOfflineFirmwareMessage('Прошивка запущена. Не отключай полетный контроллер.', 'ok');
            })
            .catch(function (error) {
                var message = (error && error.message) || 'Не удалось установить прошивку.';
                setOfflineFirmwareMessage(message, 'error');
                if (message === 'Введите полетный контроллер в режим DFU') {
                    window.alert(message);
                }
            })
            .then(function () {
                setOfflineFirmwareBusy(false);
                refreshOfflineFirmwareDfuIndicator();
            });
    }

    function renderOfflineFirmwareTab() {
        var content = document.getElementById("content");
        if (!content) {
            return;
        }

        var hasTargets = offlineFirmwareTargets.length > 0;

        content.innerHTML = [
            '<div class="tab-offline-firmware">',
            '  <div class="content_wrapper">',
            '    <div class="vtx-ready-header offline-firmware-header">',
            '      <h1>' + offlineFirmwareTabText + '</h1>',
            '      <button class="vtx-ready-help">БАЗА ЗНАНИЙ</button>',
            '    </div>',
            '    <section class="offline-firmware-card">',
            '      <h2>Прошивки Offline</h2>',
            '      <div class="offline-firmware-controls">',
            '        <label class="offline-firmware-field">',
            '          <span>Выбор полетного контроллера</span>',
            '          <select id="offline-firmware-target-select"' + (hasTargets ? '' : ' disabled') + '>' + renderOfflineFirmwareOptions() + '</select>',
            '        </label>',
            '        <button type="button" id="offline-firmware-detect-button" class="offline-firmware-button">Автоопределение</button>',
            '      </div>',
            '      <div id="offline-firmware-message" class="offline-firmware-message"></div>',
            '      <div id="offline-firmware-selected-info" class="offline-firmware-selected-info">' + renderOfflineFirmwareSelectedDetails() + '</div>',
            '      <div class="offline-firmware-dfu-row">',
            '        <span id="offline-firmware-dfu-light" class="offline-firmware-dfu-light not-dfu" aria-hidden="true"></span>',
            '        <span id="offline-firmware-dfu-text">Проверка DFU...</span>',
            '      </div>',
            '      <div class="offline-firmware-actions">',
            '        <button type="button" id="offline-firmware-enter-dfu-button" class="offline-firmware-button">Перевести полетный контроллер в режим DFU</button>',
            '        <button type="button" id="offline-firmware-install-button" class="offline-firmware-button primary" data-requires-target="true"' + (hasTargets ? '' : ' disabled') + '>Установить прошивку</button>',
            '      </div>',
            '      <div class="offline-firmware-progress-wrap">',
            '        <progress class="progress offline-firmware-progress" max="100" value="0"></progress>',
            '        <span class="progressLabel offline-firmware-progress-label">Готово к работе с offline прошивкой.</span>',
            '      </div>',
            '    </section>',
            '  </div>',
            '</div>'
        ].join("");

        startOfflineFirmwareDfuPolling();
    }
    function getUpravaGroup(sectionId, groupId) {
        for (var sectionIndex = 0; sectionIndex < upravaFirmwareSections.length; sectionIndex += 1) {
            var section = upravaFirmwareSections[sectionIndex];
            if (section.id !== sectionId) {
                continue;
            }

            for (var groupIndex = 0; groupIndex < section.groups.length; groupIndex += 1) {
                if (section.groups[groupIndex].id === groupId) {
                    return section.groups[groupIndex];
                }
            }
        }

        return null;
    }

    function getUpravaGroupKey(sectionId, groupId) {
        return sectionId + ':' + groupId;
    }

    function getSelectedUpravaFirmware(sectionId, groupId) {
        var group = getUpravaGroup(sectionId, groupId);
        if (!group || !group.items || !group.items.length) {
            return null;
        }

        var key = getUpravaGroupKey(sectionId, groupId);
        var selected = Number(selectedUpravaFirmware[key] || 0);
        if (selected < 0 || selected >= group.items.length) {
            selected = 0;
            selectedUpravaFirmware[key] = 0;
        }

        return group.items[selected];
    }

    function renderUpravaFirmwareOptions(section, group) {
        if (!group.items || !group.items.length) {
            return '<option value="">Прошивки пока не добавлены</option>';
        }

        var key = getUpravaGroupKey(section.id, group.id);
        var selected = Number(selectedUpravaFirmware[key] || 0);
        return group.items.map(function (item, index) {
            var label = item.label || item.name || item.fileName || 'Прошивка ' + (index + 1);
            return '<option value="' + index + '"' + (index === selected ? ' selected' : '') + '>' + escapeHtml(label) + '</option>';
        }).join('');
    }

    function renderUpravaSelectedInfo(item) {
        if (!item) {
            return '<div class="uprava-firmware-empty">Здесь появится список прошивок после добавления файлов.</div>';
        }

        return [
            '<div class="uprava-firmware-meta-title">' + escapeHtml(item.label || item.name || item.fileName || 'Прошивка') + '</div>',
            item.chip ? '<div class="uprava-firmware-meta-line">Чип: <code>' + escapeHtml(item.chip) + '</code></div>' : '',
            item.version ? '<div class="uprava-firmware-meta-line">Версия: <code>' + escapeHtml(item.version) + '</code></div>' : '',
            item.note ? '<div class="uprava-firmware-meta-note">' + escapeHtml(item.note) + '</div>' : ''
        ].join('');
    }

    function renderUpravaFirmwareGroup(section, group) {
        var item = getSelectedUpravaFirmware(section.id, group.id);
        var disabled = item && item.path ? '' : ' disabled';

        return [
            '<article class="uprava-firmware-panel">',
            '  <div class="uprava-firmware-panel-head">',
            '    <h3>' + escapeHtml(group.title) + '</h3>',
            '  </div>',
            '  <div class="uprava-firmware-control-row">',
            '    <select class="uprava-firmware-select" data-uprava-section="' + escapeHtml(section.id) + '" data-uprava-group="' + escapeHtml(group.id) + '"' + (group.items && group.items.length ? '' : ' disabled') + '>' + renderUpravaFirmwareOptions(section, group) + '</select>',
            '    <button type="button" class="uprava-download-button" data-uprava-section="' + escapeHtml(section.id) + '" data-uprava-group="' + escapeHtml(group.id) + '"' + disabled + '>Скачать прошивку</button>',
            '  </div>',
            '  <div class="uprava-firmware-selected-info">' + renderUpravaSelectedInfo(item) + '</div>',
            '</article>'
        ].join('');
    }

    function renderUpravaSection(section) {
        return [
            '<section class="uprava-section-card">',
            '  <h2>' + escapeHtml(section.title) + '</h2>',
            (section.groups || []).map(function (group) {
                return renderUpravaFirmwareGroup(section, group);
            }).join(''),
            '</section>'
        ].join('');
    }

    function renderUpravaPhotoRows(items, emptyText) {
        if (!items.length) {
            return '<tr><td colspan="2" class="uprava-receiver-photo-empty">' + escapeHtml(emptyText) + '</td></tr>';
        }

        return items.map(function (item) {
            var title = item.title || '';

            return [
                '<tr>',
                '  <td class="uprava-receiver-title-cell">' + escapeHtml(title) + '</td>',
                '  <td class="uprava-receiver-action-cell"><button type="button" class="uprava-receiver-photo-button" data-uprava-receiver-photo="' + escapeHtml(item.photo) + '" data-uprava-receiver-title="' + escapeHtml(title) + '">Просмотреть фото</button></td>',
                '</tr>'
            ].join('');
        }).join('');
    }

    function renderUpravaPhotosTable(title, nameHeader, emptyText, items) {
        return [
            '<section class="uprava-receiver-photo-card">',
            '  <h2>' + escapeHtml(title) + '</h2>',
            '  <table class="uprava-receiver-photo-table">',
            '    <colgroup>',
            '      <col class="uprava-receiver-title-col">',
            '      <col class="uprava-receiver-action-col">',
            '    </colgroup>',
            '    <thead>',
            '      <tr>',
            '        <th>' + escapeHtml(nameHeader) + '</th>',
            '        <th>Фото</th>',
            '      </tr>',
            '    </thead>',
            '    <tbody>' + renderUpravaPhotoRows(items, emptyText) + '</tbody>',
            '  </table>',
            '</section>'
        ].join('');
    }

    function renderUpravaReceiverPhotosTable() {
        return renderUpravaPhotosTable(
            'Фото Приемников',
            'Название приемника',
            'Фото приемников пока не добавлены.',
            upravaReceiverPhotos
        );
    }

    function renderUpravaTransmitterPhotosTable() {
        return renderUpravaPhotosTable(
            'Фото Передатчиков',
            'Название передатчика',
            'Фото передатчиков пока не добавлены.',
            upravaTransmitterPhotos
        );
    }

    function closeUpravaReceiverPhoto() {
        var overlay = document.getElementById('uprava-receiver-photo-overlay');
        if (overlay) {
            overlay.parentNode.removeChild(overlay);
        }
    }

    function openUpravaReceiverPhoto(photo, title) {
        closeUpravaReceiverPhoto();

        var overlay = document.createElement('div');
        overlay.id = 'uprava-receiver-photo-overlay';
        overlay.className = 'uprava-receiver-photo-overlay';
        overlay.innerHTML = [
            '<div class="uprava-receiver-photo-modal" role="dialog" aria-modal="true">',
            '  <button type="button" class="uprava-receiver-photo-close" aria-label="Закрыть">×</button>',
            '  <div class="uprava-receiver-photo-modal-title">' + escapeHtml(title) + '</div>',
            '  <img src="' + escapeHtml(photo) + '" alt="' + escapeHtml(title) + '">',
            '</div>'
        ].join('');

        document.body.appendChild(overlay);
    }

    function setUpravaMessage(text, status) {
        var message = document.getElementById('uprava-message');
        if (!message) {
            return;
        }

        message.textContent = text || '';
        message.className = 'uprava-message' + (status ? ' is-' + status : '');
    }

    function getUpravaSuggestedName(item) {
        var source = item.fileName || item.path || item.label || 'firmware.bin';
        return String(source).split(/[\\/]/).pop() || 'firmware.bin';
    }

    function getUpravaFileExtension(name) {
        var match = String(name || '').match(/\.([A-Za-z0-9]+)$/);
        return match ? match[1].toLowerCase() : 'bin';
    }

    function saveUpravaBlob(fileEntry, blob) {
        return new Promise(function (resolve, reject) {
            fileEntry.createWriter(function (writer) {
                var truncated = false;

                writer.onerror = function (error) {
                    reject(error || new Error('Не удалось записать файл.'));
                };

                writer.onwriteend = function () {
                    if (!truncated) {
                        truncated = true;
                        writer.write(blob);
                        return;
                    }

                    resolve();
                };

                writer.truncate(0);
            }, function (error) {
                reject(error || new Error('Не удалось открыть файл для записи.'));
            });
        });
    }

    function chooseUpravaSaveFile(item, blob) {
        var suggestedName = getUpravaSuggestedName(item);
        var extension = getUpravaFileExtension(suggestedName);
        var accepts = [{ description: 'Firmware files', extensions: [extension] }];

        chrome.fileSystem.chooseEntry({ type: 'saveFile', suggestedName: suggestedName, accepts: accepts }, function (entry) {
            if (typeof checkChromeRuntimeError === 'function' && checkChromeRuntimeError()) {
                setUpravaMessage('Сохранение отменено.', 'neutral');
                return;
            }

            if (!entry) {
                setUpravaMessage('Сохранение отменено.', 'neutral');
                return;
            }

            saveUpravaBlob(entry, blob)
                .then(function () {
                    if (chrome.fileSystem && chrome.fileSystem.getDisplayPath) {
                        chrome.fileSystem.getDisplayPath(entry, function (displayPath) {
                            setUpravaMessage('Прошивка сохранена: ' + displayPath, 'ok');
                        });
                    } else {
                        setUpravaMessage('Прошивка сохранена.', 'ok');
                    }
                })
                .catch(function (error) {
                    setUpravaMessage((error && error.message) || 'Не удалось сохранить прошивку.', 'error');
                });
        });
    }

    function downloadSelectedUpravaFirmware(sectionId, groupId) {
        var item = getSelectedUpravaFirmware(sectionId, groupId);
        if (!item || !item.path) {
            setUpravaMessage('Прошивка пока не добавлена.', 'error');
            return;
        }

        setUpravaMessage('Подготовка файла прошивки...', 'neutral');
        fetch(item.path, { cache: 'no-store' })
            .then(function (response) {
                if (!response.ok) {
                    throw new Error('Не удалось прочитать файл прошивки: ' + response.status);
                }

                return response.arrayBuffer();
            })
            .then(function (buffer) {
                chooseUpravaSaveFile(item, new Blob([buffer], { type: 'application/octet-stream' }));
            })
            .catch(function (error) {
                setUpravaMessage((error && error.message) || 'Не удалось подготовить прошивку.', 'error');
            });
    }

    function renderUpravaTab() {
        var content = document.getElementById("content");
        if (!content) {
            return;
        }

        content.innerHTML = [
            '<div class="tab-uprava">',
            '  <div class="content_wrapper">',
            '    <div class="vtx-ready-header uprava-header">',
            '      <h1>' + upravaTabText + '</h1>',
            '      <button class="vtx-ready-help">БАЗА ЗНАНИЙ</button>',
            '    </div>',
            '    <div class="uprava-layout">',
            upravaFirmwareSections.map(renderUpravaSection).join(''),
            '    </div>',
            renderUpravaReceiverPhotosTable(),
            renderUpravaTransmitterPhotosTable(),
            '    <div id="uprava-message" class="uprava-message"></div>',
            '  </div>',
            '</div>'
        ].join("");
    }

    function renderEscConfiguratorTab() {
        var content = document.getElementById("content");
        if (!content) {
            return;
        }

        content.innerHTML = [
            '<div class="tab-esc-configurator">',
            '  <div class="esc-configurator-toolbar">',
            '    <button type="button" id="esc-configurator-back-button" class="esc-configurator-back-button">Вернуться в конфигуратор</button>',
            '    <div class="esc-configurator-title">ESC Configurator</div>',
            '    <button type="button" id="esc-configurator-hide-cookie-button" class="esc-configurator-open-button">\u0423\u0431\u0440\u0430\u0442\u044c \u043d\u0438\u0436\u043d\u0435\u0435 \u043e\u043a\u043d\u043e</button>',
'    <button type="button" id="esc-configurator-refresh-button" class="esc-configurator-open-button">\u041e\u0431\u043d\u043e\u0432\u0438\u0442\u044c \u0441\u0442\u0440\u0430\u043d\u0438\u0446\u0443</button>',
            '    <button type="button" id="esc-configurator-open-browser-button" class="esc-configurator-open-button">Открыть сайт</button>',
            '  </div>',
            '  <div class="esc-configurator-frame-wrap">',
            '    <webview id="esc-configurator-webview" class="esc-configurator-frame esc-configurator-webview" src="https://esc-configurator.com/" partition="persist:rus-config-donetsk-esc" allowpopups></webview>',
            '    <iframe id="esc-configurator-frame" class="esc-configurator-frame esc-configurator-iframe" src="about:blank" allow="serial; usb; hid; clipboard-read; clipboard-write; fullscreen" referrerpolicy="no-referrer"></iframe>',
            '  </div>',
            '</div>'
        ].join("");

        window.setTimeout(configureEscConfiguratorEmbed, 0);
    }

    function configureEscConfiguratorEmbed() {
        var webview = document.getElementById("esc-configurator-webview");
        var iframe = document.getElementById("esc-configurator-frame");

        if (!webview || !iframe) {
            return;
        }

        var webviewSupported = typeof webview.reload === "function" || typeof webview.executeScript === "function";
        if (webviewSupported) {
            iframe.style.display = "none";
            webview.style.display = "block";

            try {
                webview.addEventListener("loadstop", function () {
});
            } catch (error) {
            }
            return;
        }

        webview.style.display = "none";
        iframe.style.display = "block";
        if (!iframe.getAttribute("src") || iframe.getAttribute("src") === "about:blank") {
            iframe.setAttribute("src", "https://esc-configurator.com/");
        }
    }

    function reloadEscConfiguratorPage() {
        var webview = document.getElementById("esc-configurator-webview");
        var iframe = document.getElementById("esc-configurator-frame");
        var url = "https://esc-configurator.com/";

        if (webview && webview.style.display !== "none") {
            try {
                if (typeof webview.reload === "function") {
                    webview.reload();
                    return;
                }
            } catch (error) {
            }

            webview.setAttribute("src", url);
            return;
        }

        if (iframe) {
            iframe.setAttribute("src", url);
        }
    }

    function getElrsConfiguratorSwitchText() {
        return elrsConfiguratorCurrentUrl === elrsConfiguratorWebFlasherUrl ? "ELRS Configurator" : "Web Flasher";
    }

    function getElrsConfiguratorTargetUrl() {
        return elrsConfiguratorCurrentUrl === elrsConfiguratorWebFlasherUrl ? elrsConfiguratorMainUrl : elrsConfiguratorWebFlasherUrl;
    }

    function updateElrsConfiguratorSwitchButton() {
        var button = document.getElementById("elrs-configurator-switch-button");
        if (!button) {
            return;
        }

        button.textContent = getElrsConfiguratorSwitchText();
        button.title = elrsConfiguratorCurrentUrl === elrsConfiguratorWebFlasherUrl
            ? "Вернуться на elrsweb.ru"
            : "Открыть ExpressLRS Web Flasher";
    }

    function setElrsConfiguratorUrl(url) {
        var nextUrl = url || elrsConfiguratorMainUrl;
        var webview = document.getElementById("elrs-configurator-webview");
        var iframe = document.getElementById("elrs-configurator-frame");

        elrsConfiguratorCurrentUrl = nextUrl;

        if (webview && webview.style.display !== "none") {
            webview.setAttribute("src", nextUrl);
        }

        if (iframe && (!webview || webview.style.display === "none")) {
            iframe.setAttribute("src", nextUrl);
        }

        updateElrsConfiguratorSwitchButton();
    }

    function renderElrsConfiguratorTab() {
        var content = document.getElementById("content");
        if (!content) {
            return;
        }

        content.innerHTML = [
            '<div class="tab-elrs-configurator">',
            '  <div class="elrs-configurator-toolbar">',
            '    <button type="button" id="elrs-configurator-back-button" class="elrs-configurator-back-button">Вернуться в конфигуратор</button>',
            '    <div class="elrs-configurator-title">ELRS Configurator</div>',
            '    <button type="button" id="elrs-configurator-switch-button" class="elrs-configurator-switch-button">' + getElrsConfiguratorSwitchText() + '</button>',
            '  </div>',
            '  <div class="elrs-configurator-frame-wrap">',
            '    <webview id="elrs-configurator-webview" class="elrs-configurator-frame elrs-configurator-webview" src="about:blank" partition="persist:rus-config-donetsk-elrs" allowpopups></webview>',
            '    <iframe id="elrs-configurator-frame" class="elrs-configurator-frame elrs-configurator-iframe" src="' + elrsConfiguratorCurrentUrl + '" allow="serial *; usb *; hid *; clipboard-read *; clipboard-write *; fullscreen *" referrerpolicy="no-referrer"></iframe>',
            '  </div>',
            '</div>'
        ].join("");

        updateElrsConfiguratorSwitchButton();
        window.setTimeout(configureElrsConfiguratorEmbed, 0);
    }

    function configureElrsConfiguratorEmbed() {
        var webview = document.getElementById("elrs-configurator-webview");
        var iframe = document.getElementById("elrs-configurator-frame");

        if (!webview || !iframe) {
            return;
        }

        webview.style.display = "none";
        iframe.style.display = "block";
        iframe.setAttribute("src", elrsConfiguratorCurrentUrl);
        updateElrsConfiguratorSwitchButton();
    }

    function renderGuidesTab() {
        var content = document.getElementById("content");
        if (!content) {
            return;
        }

        content.innerHTML = [
            '<div class="tab-guides">',
            '  <div class="guides-toolbar">',
            '    <button type="button" id="guides-back-button" class="guides-back-button">Вернуться в конфигуратор</button>',
            '    <div class="guides-title">Руководства</div>',
            '  </div>',
            '  <div class="guides-frame-wrap">',
            '    <webview id="guides-webview" class="guides-frame guides-webview" src="' + guidesUrl + '" partition="persist:rus-config-donetsk-guides" allowpopups></webview>',
            '    <iframe id="guides-frame" class="guides-frame guides-iframe" src="about:blank" allow="serial; usb; hid; clipboard-read; clipboard-write; fullscreen" referrerpolicy="no-referrer"></iframe>',
            '  </div>',
            '</div>'
        ].join("");

        window.setTimeout(configureGuidesEmbed, 0);
    }

    function configureGuidesEmbed() {
        var webview = document.getElementById("guides-webview");
        var iframe = document.getElementById("guides-frame");

        if (!webview || !iframe) {
            return;
        }

        var webviewSupported = typeof webview.reload === "function" || typeof webview.executeScript === "function";
        if (webviewSupported) {
            iframe.style.display = "none";
            webview.style.display = "block";
            webview.setAttribute("src", guidesUrl);
            return;
        }

        webview.style.display = "none";
        iframe.style.display = "block";
        iframe.setAttribute("src", guidesUrl);
    }

    function getG13RememberLogin() {
        try {
            return localStorage.getItem(g13RememberLoginStorageKey) !== "false";
        } catch (error) {
            return true;
        }
    }

    function setG13RememberLogin(enabled) {
        try {
            localStorage.setItem(g13RememberLoginStorageKey, enabled ? "true" : "false");
        } catch (error) {
        }
    }

    function runG13WebviewScript(code) {
        var webview = document.getElementById("g13-webview");

        if (!webview || webview.style.display === "none" || typeof webview.executeScript !== "function") {
            return false;
        }

        try {
            webview.executeScript({ code: code });
            return true;
        } catch (error) {
            try {
                webview.executeScript(code);
                return true;
            } catch (innerError) {
                return false;
            }
        }
    }

    function getG13CredentialHelperCode() {
        return [
            "(function(){",
            "  var rememberEnabled = " + (getG13RememberLogin() ? "true" : "false") + ";",
            "  var STORE_KEY = 'rusConfigDonetskG13SavedLogin';",
            "  window.__rusConfigDonetskG13RememberLogin = rememberEnabled;",
            "  function visible(input) {",
            "    if (!input || input.disabled || input.readOnly) { return false; }",
            "    var rect = input.getBoundingClientRect();",
            "    var style = window.getComputedStyle ? window.getComputedStyle(input) : null;",
            "    return rect.width > 0 && rect.height > 0 && (!style || (style.display !== 'none' && style.visibility !== 'hidden'));",
            "  }",
            "  function getFields() {",
            "    var inputs = Array.prototype.slice.call(document.querySelectorAll('input'));",
            "    var password = inputs.filter(function(input) { return String(input.type || '').toLowerCase() === 'password' && visible(input); })[0];",
            "    if (!password) { return {}; }",
            "    var loginInputs = inputs.filter(function(input) {",
            "      var type = String(input.type || 'text').toLowerCase();",
            "      return input !== password && visible(input) && ['text', 'email', 'tel', 'search', 'number'].indexOf(type) !== -1;",
            "    });",
            "    var beforePassword = loginInputs.filter(function(input) { return inputs.indexOf(input) < inputs.indexOf(password); });",
            "    return { login: beforePassword.pop() || loginInputs[0], password: password };",
            "  }",
            "  function getSaved() {",
            "    try { return JSON.parse(localStorage.getItem(STORE_KEY) || '{}') || {}; } catch (error) { return {}; }",
            "  }",
            "  function dispatchInput(input) {",
            "    try { input.dispatchEvent(new Event('input', { bubbles: true })); } catch (error) {}",
            "    try { input.dispatchEvent(new Event('change', { bubbles: true })); } catch (error) {}",
            "  }",
            "  function fill() {",
            "    if (!window.__rusConfigDonetskG13RememberLogin) { return; }",
            "    var saved = getSaved();",
            "    var fields = getFields();",
            "    if (fields.login && saved.login && !fields.login.value) { fields.login.value = saved.login; dispatchInput(fields.login); }",
            "    if (fields.password && saved.password && !fields.password.value) { fields.password.value = saved.password; dispatchInput(fields.password); }",
            "  }",
            "  function save() {",
            "    if (!window.__rusConfigDonetskG13RememberLogin) { return; }",
            "    var fields = getFields();",
            "    if (!fields.login || !fields.password || !fields.login.value || !fields.password.value) { return; }",
            "    try { localStorage.setItem(STORE_KEY, JSON.stringify({ login: fields.login.value, password: fields.password.value, updatedAt: Date.now() })); } catch (error) {}",
            "  }",
            "  if (!window.__rusConfigDonetskG13HelperInstalled) {",
            "    window.__rusConfigDonetskG13HelperInstalled = true;",
            "    document.addEventListener('submit', save, true);",
            "    document.addEventListener('change', function(event) { if (event.target && event.target.tagName === 'INPUT') { save(); } }, true);",
            "    document.addEventListener('blur', function(event) { if (event.target && event.target.tagName === 'INPUT') { save(); } }, true);",
            "  }",
            "  fill();",
            "  window.setTimeout(fill, 500);",
            "  window.setTimeout(fill, 1500);",
            "}());"
        ].join("\n");
    }

    function injectG13CredentialHelper() {
        runG13WebviewScript(getG13CredentialHelperCode());
    }

    function clearG13SavedLogin() {
        var button = document.getElementById("g13-clear-login-button");
        var code = [
            "(function(){",
            "  try { localStorage.removeItem('rusConfigDonetskG13SavedLogin'); } catch (error) {}",
            "  Array.prototype.slice.call(document.querySelectorAll('input[type=password]')).forEach(function(input) { input.value = ''; try { input.dispatchEvent(new Event('input', { bubbles: true })); } catch (error) {} });",
            "  return true;",
            "}());"
        ].join("\n");

        runG13WebviewScript(code);

        if (button) {
            button.textContent = "Сброшено";
            window.setTimeout(function () {
                if (button) {
                    button.textContent = "Сбросить вход";
                }
            }, 1500);
        }
    }

    function renderG13Tab() {
        var content = document.getElementById("content");
        if (!content) {
            return;
        }

        content.innerHTML = [
            '<div class="tab-g13">',
            '  <div class="g13-toolbar">',
            '    <button type="button" id="g13-back-button" class="g13-back-button">Вернуться в конфигуратор</button>',
            '    <div class="g13-title">G13</div>',
            '    <label class="g13-remember-control"><input id="g13-remember-login-checkbox" type="checkbox"' + (getG13RememberLogin() ? ' checked' : '') + '><span>Запомнить вход</span></label>',
            '    <button type="button" id="g13-clear-login-button" class="g13-clear-login-button">Сбросить вход</button>',
            '  </div>',
            '  <div class="g13-frame-wrap">',
            '    <webview id="g13-webview" class="g13-frame g13-webview" src="about:blank" partition="persist:rus-config-donetsk-g13" allowpopups></webview>',
            '    <iframe id="g13-frame" class="g13-frame g13-iframe" src="' + g13Url + '" allow="usb *; serial *; hid *; clipboard-read *; clipboard-write *; fullscreen *" referrerpolicy="no-referrer"></iframe>',
            '  </div>',
            '</div>'
        ].join("");

        window.setTimeout(configureG13Embed, 0);
    }

    function configureG13Embed() {
        var webview = document.getElementById("g13-webview");
        var iframe = document.getElementById("g13-frame");

        if (!webview || !iframe) {
            return;
        }

        webview.style.display = "none";
        iframe.style.display = "block";
        iframe.setAttribute("src", g13Url);
    }

    function hideEscConfiguratorBottomPanel() {
        var webview = document.getElementById("esc-configurator-webview");
        if (!webview || typeof webview.executeScript !== "function") {
            return;
        }

        var code = [
            "(function(){",
            "  var hidden = 0;",
            "  var vw = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0);",
            "  var vh = Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0);",
            "  function rectFits(rect) {",
            "    return rect && rect.width >= vw * 0.35 && rect.height >= 12 && rect.height <= 210 && rect.bottom >= vh - 45 && rect.top >= vh - 260;",
            "  }",
            "  function hideNode(node) {",
            "    if (!node || node === document.body || node === document.documentElement || node.id === 'root') { return; }",
            "    node.setAttribute('data-rcd-esc-bottom-hidden', 'true');",
            "    node.style.setProperty('display', 'none', 'important');",
            "    node.style.setProperty('height', '0', 'important');",
            "    node.style.setProperty('min-height', '0', 'important');",
            "    node.style.setProperty('max-height', '0', 'important');",
            "    node.style.setProperty('overflow', 'hidden', 'important');",
            "    node.style.setProperty('padding', '0', 'important');",
            "    node.style.setProperty('margin', '0', 'important');",
            "    node.style.setProperty('border', '0', 'important');",
            "    hidden += 1;",
            "  }",
            "  function bestBottomParent(node) {",
            "    var best = null;",
            "    var bestArea = 0;",
            "    var current = node;",
            "    while (current && current !== document.body && current !== document.documentElement) {",
            "      var rect = current.getBoundingClientRect();",
            "      if (rectFits(rect)) {",
            "        var area = rect.width * rect.height;",
            "        if (area >= bestArea) { best = current; bestArea = area; }",
            "      }",
            "      current = current.parentElement;",
            "    }",
            "    return best;",
            "  }",
            "  function hideFromPoint(x, y) {",
            "    if (!document.elementsFromPoint) { return; }",
            "    var stack = document.elementsFromPoint(x, y) || [];",
            "    stack.forEach(function(node){",
            "      var best = bestBottomParent(node);",
            "      if (best) { hideNode(best); }",
            "    });",
            "  }",
            "  var xs = [8, Math.round(vw * 0.22), Math.round(vw * 0.5), Math.round(vw * 0.78), vw - 8];",
            "  var ys = [vh - 8, vh - 32, vh - 62, vh - 96, vh - 128];",
            "  ys.forEach(function(y){ xs.forEach(function(x){ hideFromPoint(x, y); }); });",
            "  var selectors = [",
            "    '#log', '.log', '.logger', '.debug-log', '.debug-console', '#statusbar', '#status_bar', '.statusbar', '.status-bar', '.status_bar', '#bottom-bar', '.bottom-bar', '.app-footer', 'footer',",
            "    '[data-rcd-esc-bottom-hidden]', '[class*=bottom]', '[id*=bottom]', '[class*=status]', '[id*=status]', '[class*=log]', '[id*=log]', '[class*=debug]', '[id*=debug]'",
            "  ].join(',');",
            "  Array.prototype.slice.call(document.querySelectorAll(selectors)).forEach(function(node){",
            "    if (rectFits(node.getBoundingClientRect())) { hideNode(bestBottomParent(node) || node); }",
            "  });",
            "  if (document.body) {",
            "    document.body.style.setProperty('padding-bottom', '0', 'important');",
            "    document.body.style.setProperty('margin-bottom', '0', 'important');",
            "  }",
            "  window.dispatchEvent(new Event('resize'));",
            "  return hidden;",
            "})();"
        ].join("");

        function executeCleanup() {
            try {
                webview.executeScript({ code: code });
            } catch (error) {
                try {
                    webview.executeScript(code);
                } catch (innerError) {
                }
            }
        }

        executeCleanup();
        [200, 650, 1200].forEach(function (delay) {
            window.setTimeout(executeCleanup, delay);
        });
    }

    function setEscConfiguratorCompactButtonFeedback() {
        var button = document.getElementById("esc-configurator-hide-cookie-button");
        if (!button) {
            return;
        }

        button.textContent = "\u041d\u0438\u0436\u043d\u0435\u0435 \u043e\u043a\u043d\u043e \u0443\u0431\u0440\u0430\u043d\u043e";
        window.setTimeout(function () {
            if (button && button.parentNode) {
                button.textContent = "\u0423\u0431\u0440\u0430\u0442\u044c \u043d\u0438\u0436\u043d\u0435\u0435 \u043e\u043a\u043d\u043e";
            }
        }, 1600);
    }
    function returnToLandingTab() {
        var landingLink = document.querySelector("#tabs .tab_landing a") || document.querySelector("#tabs ul.mode-disconnected li:not(.rus-config-donetsk-esc-configurator) a");
        if (landingLink && typeof landingLink.click === "function") {
            landingLink.click();
            return;
        }

        try {
            if (window.$) {
                $("#content").load("./tabs/landing.html", function () {
                    if (window.i18n && typeof i18n.localizePage === "function") {
                        i18n.localizePage();
                    }
                });
            }
        } catch (error) {
        }
    }

    function openExternalUrl(url) {
        try {
            if (window.nw && nw.Shell && typeof nw.Shell.openExternal === "function") {
                nw.Shell.openExternal(url);
                return;
            }
        } catch (error) {
        }

        window.open(url, "_blank");
    }

    function openEscConfiguratorInBrowser() {
        openExternalUrl("https://esc-configurator.com/");
    }
    function getProgramUpdateNodeApi() {
        var nodeRequire = null;
        try {
            nodeRequire = window.require || (typeof require !== "undefined" ? require : null);
        } catch (error) {
            nodeRequire = null;
        }

        if (!nodeRequire) {
            throw new Error("Node API недоступен. Обновление работает только в настольной версии приложения.");
        }

        return {
            fs: nodeRequire("fs"),
            path: nodeRequire("path"),
            childProcess: nodeRequire("child_process")
        };
    }

    function getProgramUpdateCurrentVersionText() {
        try {
            if (window.CONFIGURATOR && typeof CONFIGURATOR.getDisplayVersion === "function") {
                return CONFIGURATOR.getDisplayVersion();
            }
        } catch (error) {
        }

        return "RUS Config Donetsk Version 1.0";
    }

    function normalizeProgramVersion(value) {
        var match = String(value || "").match(/\d+(?:\.\d+)*/);
        return match ? match[0] : "0";
    }

    function compareProgramVersions(left, right) {
        var a = normalizeProgramVersion(left).split(".").map(function (part) { return parseInt(part, 10) || 0; });
        var b = normalizeProgramVersion(right).split(".").map(function (part) { return parseInt(part, 10) || 0; });
        var length = Math.max(a.length, b.length, 3);

        for (var index = 0; index < length; index += 1) {
            var leftPart = a[index] || 0;
            var rightPart = b[index] || 0;

            if (leftPart > rightPart) {
                return 1;
            }

            if (leftPart < rightPart) {
                return -1;
            }
        }

        return 0;
    }

    function getProgramUpdateAppRoot(api) {
        try {
            if (typeof process !== "undefined" && process.execPath) {
                return api.path.dirname(process.execPath);
            }
        } catch (error) {
        }

        try {
            if (typeof process !== "undefined" && typeof process.cwd === "function") {
                return process.cwd();
            }
        } catch (error) {
        }

        return ".";
    }

    function isProgramUpdateUrl(value) {
        return /^https?:\/\//i.test(String(value || ""));
    }

    function normalizeProgramUpdateManifestSource(value) {
        var text = String(value || "").trim();
        var match = text.match(/^https:\/\/api\.github\.com\/repos\/([^\/]+)\/([^\/]+)\/contents\/(.+?)(?:\?(.+))?$/i);

        if (!match) {
            return text;
        }

        var owner = match[1];
        var repo = match[2];
        var filePath = match[3];
        var branch = "main";

        try {
            var params = new URLSearchParams(match[4] || "");
            branch = params.get("ref") || branch;
        } catch (error) {
        }

        return "https://raw.githubusercontent.com/" + owner + "/" + repo + "/" + branch + "/" + filePath;
    }

    function getProgramUpdateSource() {
        var api = getProgramUpdateNodeApi();
        var appRoot = getProgramUpdateAppRoot(api);
        var sourceConfigPath = api.path.join(appRoot, programUpdateSourceFileName);
        var source = programUpdateManifestPath;
        var authHeader = "";

        try {
            if (api.fs.existsSync(sourceConfigPath)) {
                var config = JSON.parse(api.fs.readFileSync(sourceConfigPath, "utf8").replace(/^\uFEFF/, ""));
                source = config.manifest || config.url || source;
                authHeader = config.authorization || config.authHeader || "";

                if (!authHeader && config.token) {
                    authHeader = /^(Bearer|token|Basic)\s+/i.test(config.token)
                        ? config.token
                        : ("Bearer " + config.token);
                }
            }
        } catch (error) {
            throw new Error("Не удалось прочитать update-source.json: " + ((error && error.message) || error));
        }

        source = normalizeProgramUpdateManifestSource(source);

        return {
            manifest: source,
            configPath: sourceConfigPath,
            isRemote: isProgramUpdateUrl(source),
            authHeader: authHeader
        };
    }

    function readProgramUpdateUrlText(url, source) {
        var api = getProgramUpdateNodeApi();
        var command = [
            "$ProgressPreference = 'SilentlyContinue'",
            "[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)",
            "$OutputEncoding = [Console]::OutputEncoding",
            "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12",
            "$headers = @{}",
            "$headers['User-Agent'] = 'RUS-Config-Donetsk-Updater'",
            "if ($env:RCD_UPDATE_AUTH) { $headers['Authorization'] = $env:RCD_UPDATE_AUTH }",
            "if ($env:RCD_UPDATE_URL -like 'https://api.github.com/repos/*/contents/*') { $headers['Accept'] = 'application/vnd.github.raw+json' }",
            "if ($headers.Count -gt 0) { $response = Invoke-WebRequest -UseBasicParsing -Uri $env:RCD_UPDATE_URL -Headers $headers } else { $response = Invoke-WebRequest -UseBasicParsing -Uri $env:RCD_UPDATE_URL }",
            "$content = $response.Content",
            "if ($content -is [byte[]]) { [Text.Encoding]::UTF8.GetString($content) } else { $content }"
        ].join("; ");
        var output = api.childProcess.execFileSync("powershell.exe", ["-NoProfile", "-Command", command], {
            encoding: "utf8",
            windowsHide: true,
            env: Object.assign({}, process.env, {
                RCD_UPDATE_URL: url,
                RCD_UPDATE_AUTH: source && source.authHeader ? source.authHeader : ""
            })
        });

        return output;
    }

    function resolveProgramUpdatePackage(info, source) {
        var packageName = info.packageUrl || info.packagePath || info.package || info.file || "";
        if (!packageName) {
            return;
        }

        if (source.isRemote) {
            info.resolvedPackageUrl = isProgramUpdateUrl(packageName)
                ? packageName
                : new URL(packageName, source.manifest).href;
            info.resolvedPackageDisplay = info.resolvedPackageUrl;
            return;
        }

        var api = getProgramUpdateNodeApi();
        info.resolvedPackagePath = api.path.isAbsolute(packageName)
            ? packageName
            : api.path.join(api.path.dirname(source.manifest), packageName);
        info.resolvedPackageDisplay = info.resolvedPackagePath;
    }

    function getProgramUpdateDisplayName(value) {
        var text = String(value || "").trim();
        if (!text) {
            return "";
        }

        if (isProgramUpdateUrl(text)) {
            try {
                var url = new URL(text);
                var urlParts = url.pathname.split("/").filter(Boolean);
                return decodeURIComponent(urlParts[urlParts.length - 1] || text);
            } catch (error) {
            }
        }

        var cleanText = text.replace(/[?#].*$/, "");
        var parts = cleanText.split(/[\\/]/).filter(Boolean);
        return parts.length ? parts[parts.length - 1] : text;
    }
    function readProgramUpdateManifest() {
        var api = getProgramUpdateNodeApi();
        var source = getProgramUpdateSource();
        var raw = "";

        if (source.isRemote) {
            raw = readProgramUpdateUrlText(source.manifest, source);
        } else {
            if (!api.fs.existsSync(source.manifest)) {
                throw new Error("Файл обновления не найден: " + source.manifest);
            }

            raw = api.fs.readFileSync(source.manifest, "utf8");
        }

        var manifestText = String(raw || "").replace(/^\uFEFF/, "").trim();
        if (!manifestText) {
            throw new Error("version.json пустой или недоступен. Проверь интернет или публичную ссылку обновлений.");
        }

        var info;
        try {
            info = JSON.parse(manifestText);
        } catch (error) {
            throw new Error("version.json получен, но это не JSON: " + ((error && error.message) || error));
        }
        info.updateSource = source;
        resolveProgramUpdatePackage(info, source);
        return info;
    }
    function renderProgramUpdateNotes(notes) {
        if (!Array.isArray(notes) || !notes.length) {
            return '<div class="program-update-muted">Описание изменений пока не заполнено.</div>';
        }

        return '<ul class="program-update-notes">' + notes.map(function (note) {
            return '<li>' + escapeHtml(note) + '</li>';
        }).join("") + '</ul>';
    }

    function setProgramUpdateMessage(text, status) {
        var box = document.getElementById("program-update-message");
        if (!box) {
            return;
        }

        box.textContent = text || "";
        box.className = "program-update-message" + (status ? " is-" + status : "");
    }

    function renderProgramUpdateTab() {
        var content = document.getElementById("content");
        if (!content) {
            return;
        }

        var currentText = getProgramUpdateCurrentVersionText();
        var currentVersion = normalizeProgramVersion(currentText);
        var manifest = null;
        var errorText = "";
        var isNewVersion = false;
        var packageExists = false;
        var source = null;
        try {
            source = getProgramUpdateSource();
            manifest = readProgramUpdateManifest();
            isNewVersion = compareProgramVersions(manifest.version || manifest.title, currentVersion) > 0;

            if (manifest.resolvedPackageUrl) {
                packageExists = true;
            } else if (manifest.resolvedPackagePath) {
                var api = getProgramUpdateNodeApi();
                packageExists = api.fs.existsSync(manifest.resolvedPackagePath);
            }
        } catch (error) {
            errorText = (error && error.message) || "Не удалось проверить обновление.";
        }

        var manifestVersion = manifest ? escapeHtml(manifest.title || manifest.version || "Версия не указана") : "Нет данных";
        var packagePath = manifest && manifest.resolvedPackageDisplay ? manifest.resolvedPackageDisplay : "";
        var manifestPath = source && source.manifest ? source.manifest : programUpdateManifestPath;
        var packageDisplayName = getProgramUpdateDisplayName(packagePath);
        var manifestDisplayName = getProgramUpdateDisplayName(manifestPath);
        var configDisplayName = source && source.configPath ? getProgramUpdateDisplayName(source.configPath) : "";
        var statusText = errorText
            ? errorText
            : (isNewVersion
                ? (packageExists ? "Найдена новая версия, можно обновлять." : "Найдена новая версия, но zip-пакет не найден.")
                : "Установлена актуальная версия.");
        var statusClass = errorText || (isNewVersion && !packageExists) ? "error" : (isNewVersion ? "ok" : "neutral");

        content.innerHTML = [
            '<div class="tab-program-update">',
            '  <div class="content_wrapper">',
            '    <div class="vtx-ready-header program-update-header">',
            '      <h1>' + programUpdateTabText + '</h1>',
            '      <button type="button" id="program-update-check-button" class="program-update-header-button">Проверить</button>',
            '    </div>',
            '    <section class="program-update-card">',
            '      <div class="program-update-grid">',
            '        <div class="program-update-version-box">',
            '          <span>Текущая версия</span>',
            '          <strong>' + escapeHtml(currentText) + '</strong>',
            '        </div>',
            '        <div class="program-update-version-box">',
            '          <span>Версия обновления</span>',
            '          <strong>' + manifestVersion + '</strong>',
            '        </div>',
            '      </div>',
            '      <div id="program-update-message" class="program-update-message is-' + statusClass + '">' + escapeHtml(statusText) + '</div>',
            '      <div class="program-update-path-row">',
            '        <span>Источник версии</span>',
            '        <code>' + escapeHtml(manifestDisplayName) + '</code>',
            '      </div>',
            packageDisplayName ? '      <div class="program-update-path-row"><span>Пакет обновления</span><code>' + escapeHtml(packageDisplayName) + '</code></div>' : '',
            configDisplayName ? '      <div class="program-update-path-row"><span>Настройка источника</span><code>' + escapeHtml(configDisplayName) + '</code></div>' : '',
            '      <div class="program-update-actions">',
            '        <button type="button" id="program-update-run-button" class="program-update-button primary"' + ((isNewVersion && packageExists) ? '' : ' disabled') + '>Обновить программу</button>',
            '      </div>',
            '      <div class="program-update-notes-box">',
            '        <h2>Что изменится</h2>',
            manifest ? renderProgramUpdateNotes(manifest.notes) : '<div class="program-update-muted">Проверь интернет или публичный источник обновлений в update-source.json.</div>',
            '      </div>',
            '    </section>',
            '  </div>',
            '</div>'
        ].join("");
    }

    function closeForProgramUpdate() {
        window.setTimeout(function () {
            try {
                if (window.nw && nw.App && typeof nw.App.quit === "function") {
                    nw.App.quit();
                } else {
                    window.close();
                }
            } catch (error) {
                window.close();
            }
        }, 800);
    }

    function startProgramUpdate() {
        try {
            var api = getProgramUpdateNodeApi();
            var appRoot = getProgramUpdateAppRoot(api);

            var manifest = readProgramUpdateManifest();
            var currentVersion = normalizeProgramVersion(getProgramUpdateCurrentVersionText());

            if (compareProgramVersions(manifest.version || manifest.title, currentVersion) <= 0) {
                setProgramUpdateMessage("Новая версия не найдена.", "neutral");
                return;
            }

            if (!manifest.resolvedPackageUrl && (!manifest.resolvedPackagePath || !api.fs.existsSync(manifest.resolvedPackagePath))) {
                setProgramUpdateMessage("Zip-пакет обновления не найден.", "error");
                return;
            }

            var updaterPath = api.path.join(appRoot, "rus-config-donetsk-updater.ps1");
            var launcherPath = api.path.join(appRoot, "rus-config-donetsk-update-launcher.cmd");
            var exePath = api.path.join(appRoot, "RUS Config Donetsk.exe");

            if (!api.fs.existsSync(updaterPath)) {
                setProgramUpdateMessage("Файл updater не найден: " + updaterPath, "error");
                return;
            }

            setProgramUpdateMessage("Обновление запущено. Сейчас откроется окно установки, программа закроется и запустится заново.", "ok");

            var requestPath = api.path.join(appRoot, "update-request.json");
            var updateRequest = {
                AppRoot: appRoot,
                ExePath: exePath,
                CallerProcessId: (typeof process !== "undefined" && process.pid) ? process.pid : 0
            };
            if (manifest.resolvedPackageUrl) {
                updateRequest.PackageUrl = manifest.resolvedPackageUrl;
            } else {
                updateRequest.PackagePath = manifest.resolvedPackagePath;
            }

            api.fs.writeFileSync(requestPath, JSON.stringify(updateRequest, null, 2), "utf8");

            var updaterEnv = Object.assign({}, process.env);
            if (manifest.updateSource && manifest.updateSource.authHeader) {
                updaterEnv.RCD_UPDATE_AUTH = manifest.updateSource.authHeader;
            }

            try {
                api.fs.appendFileSync(
                    api.path.join(appRoot, "update-launch.log"),
                    new Date().toISOString() + " starting updater for " + (manifest.resolvedPackageUrl || manifest.resolvedPackagePath || "") + "\n",
                    "utf8"
                );
            } catch (logError) {
            }

            var child;
            if (api.fs.existsSync(launcherPath)) {
                child = api.childProcess.spawn("cmd.exe", ["/d", "/c", "start", "RUS Config Donetsk Update", launcherPath], {
                    cwd: appRoot,
                    detached: true,
                    stdio: "ignore",
                    windowsHide: false,
                    env: updaterEnv
                });
            } else {
                child = api.childProcess.spawn("powershell.exe", [
                    "-NoProfile",
                    "-STA",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-File",
                    updaterPath,
                    "-RequestFile",
                    requestPath
                ], {
                    cwd: appRoot,
                    detached: true,
                    stdio: "ignore",
                    windowsHide: false,
                    env: updaterEnv
                });
            }
            child.unref();

            closeForProgramUpdate();
        } catch (error) {
            setProgramUpdateMessage((error && error.message) || "Не удалось запустить обновление.", "error");
        }
    }
    function activateTab(tabItem, renderContent) {
        document.querySelectorAll("#tabs li").forEach(function (item) {
            item.classList.remove("active");
        });
        tabItem.classList.add("active");
        if (renderContent !== renderOfflineFirmwareTab) {
            stopOfflineFirmwareDfuPolling();
        }
        renderContent();
    }

    document.addEventListener("click", function (event) {
        var button = event.target.closest(".uprava-receiver-photo-button");
        if (!button) {
            return;
        }

        event.preventDefault();
        openUpravaReceiverPhoto(button.getAttribute("data-uprava-receiver-photo"), button.getAttribute("data-uprava-receiver-title"));
    });

    document.addEventListener("click", function (event) {
        if (event.target.closest(".uprava-receiver-photo-close") || event.target.classList.contains("uprava-receiver-photo-overlay")) {
            closeUpravaReceiverPhoto();
        }
    });

    document.addEventListener("keydown", function (event) {
        if (event.key === "Escape") {
            closeUpravaReceiverPhoto();
        }
    });

    document.addEventListener("click", function (event) {
        var link = event.target.closest("#tabs .rus-config-donetsk-vtx-tables a");
        if (!link) {
            return;
        }

        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        activateTab(link.closest("li"), renderVtxTablesTab);
    }, true);

    document.addEventListener("click", function (event) {
        var link = event.target.closest("#tabs .rus-config-donetsk-ready-dumps a");
        if (!link) {
            return;
        }

        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        activateTab(link.closest("li"), renderReadyDumpsTab);
    }, true);
    document.addEventListener("click", function (event) {
        var link = event.target.closest("#tabs .rus-config-donetsk-offline-firmware a");
        if (!link) {
            return;
        }

        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        activateTab(link.closest("li"), renderOfflineFirmwareTab);
    }, true);


    document.addEventListener("click", function (event) {
        var link = event.target.closest("#tabs .rus-config-donetsk-uprava a");
        if (!link) {
            return;
        }

        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        activateTab(link.closest("li"), renderUpravaTab);
    }, true);
    document.addEventListener("click", function (event) {
        var link = event.target.closest("#tabs .rus-config-donetsk-esc-configurator a");
        if (!link) {
            return;
        }

        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        activateTab(link.closest("li"), renderEscConfiguratorTab);
    }, true);

    document.addEventListener("click", function (event) {
        var link = event.target.closest("#tabs .rus-config-donetsk-elrs-configurator a");
        if (!link) {
            return;
        }

        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        elrsConfiguratorCurrentUrl = elrsConfiguratorMainUrl;
        activateTab(link.closest("li"), renderElrsConfiguratorTab);
    }, true);

    document.addEventListener("click", function (event) {
        var link = event.target.closest("#tabs .rus-config-donetsk-guides a");
        if (!link) {
            return;
        }

        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        activateTab(link.closest("li"), renderGuidesTab);
    }, true);

    document.addEventListener("click", function (event) {
        var link = event.target.closest("#tabs .rus-config-donetsk-g13 a");
        if (!link) {
            return;
        }

        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        activateTab(link.closest("li"), renderG13Tab);
    }, true);

    document.addEventListener("click", function (event) {
        if (!event.target.closest("#esc-configurator-back-button")) {
            return;
        }

        event.preventDefault();
        returnToLandingTab();
    });

    document.addEventListener("click", function (event) {
        if (!event.target.closest("#esc-configurator-open-browser-button")) {
            return;
        }

        event.preventDefault();
        openEscConfiguratorInBrowser();
    });
    document.addEventListener("click", function (event) {
        if (!event.target.closest("#esc-configurator-refresh-button")) {
            return;
        }

        event.preventDefault();
        reloadEscConfiguratorPage();
    });
    document.addEventListener("click", function (event) {
        if (!event.target.closest("#elrs-configurator-back-button")) {
            return;
        }

        event.preventDefault();
        returnToLandingTab();
    });
    document.addEventListener("click", function (event) {
        if (!event.target.closest("#elrs-configurator-switch-button")) {
            return;
        }

        event.preventDefault();
        setElrsConfiguratorUrl(getElrsConfiguratorTargetUrl());
    });
    document.addEventListener("click", function (event) {
        if (!event.target.closest("#guides-back-button")) {
            return;
        }

        event.preventDefault();
        returnToLandingTab();
    });
    document.addEventListener("click", function (event) {
        if (!event.target.closest("#g13-back-button")) {
            return;
        }

        event.preventDefault();
        returnToLandingTab();
    });
    document.addEventListener("change", function (event) {
        if (event.target.id !== "g13-remember-login-checkbox") {
            return;
        }

        setG13RememberLogin(Boolean(event.target.checked));
        injectG13CredentialHelper();
    });
    document.addEventListener("click", function (event) {
        if (!event.target.closest("#g13-clear-login-button")) {
            return;
        }

        event.preventDefault();
        clearG13SavedLogin();
    });
    document.addEventListener("click", function (event) {
        if (!event.target.closest("#esc-configurator-hide-cookie-button")) {
            return;
        }
        event.preventDefault();
        hideEscConfiguratorBottomPanel();
        setEscConfiguratorCompactButtonFeedback();
    });
    document.addEventListener("click", function (event) {
        var link = event.target.closest("#tabs .rus-config-donetsk-program-update a");
        if (!link) {
            return;
        }

        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        activateTab(link.closest("li"), renderProgramUpdateTab);
    }, true);

    document.addEventListener("click", function (event) {
        if (!event.target.closest("#program-update-check-button")) {
            return;
        }

        renderProgramUpdateTab();
    });

    document.addEventListener("click", function (event) {
        if (!event.target.closest("#program-update-run-button")) {
            return;
        }

        startProgramUpdate();
    });

    document.addEventListener("change", function (event) {
        var select = event.target.closest(".uprava-firmware-select");
        if (!select) {
            return;
        }

        selectedUpravaFirmware[getUpravaGroupKey(select.dataset.upravaSection, select.dataset.upravaGroup)] = Number(select.value || 0);
        renderUpravaTab();
    });

    document.addEventListener("click", function (event) {
        var button = event.target.closest(".uprava-download-button");
        if (!button) {
            return;
        }

        downloadSelectedUpravaFirmware(button.dataset.upravaSection, button.dataset.upravaGroup);
    });
    document.addEventListener("change", function (event) {
        if (event.target.id !== "offline-firmware-target-select") {
            return;
        }

        selectedOfflineFirmwareIndex = Number(event.target.value || 0);
        updateOfflineFirmwareTargetInfo();
        setOfflineFirmwareMessage('', '');
    });

    document.addEventListener("click", function (event) {
        if (!event.target.closest("#offline-firmware-detect-button")) {
            return;
        }

        detectOfflineFirmwareTarget();
    });

    document.addEventListener("click", function (event) {
        if (!event.target.closest("#offline-firmware-enter-dfu-button")) {
            return;
        }

        enterOfflineFirmwareDfu();
    });

    document.addEventListener("click", function (event) {
        if (!event.target.closest("#offline-firmware-install-button")) {
            return;
        }

        installOfflineFirmware();
    });
    document.addEventListener("change", function (event) {
        if (event.target.id !== "dump-drone-select") {
            return;
        }

        selectedDumpIndex = Number(event.target.value || 0);
        selectedDumpControllerIndex = 0;
        renderReadyDumpsTab();
    });

    document.addEventListener("change", function (event) {
        if (event.target.id !== "dump-controller-select") {
            return;
        }

        selectedDumpControllerIndex = Number(event.target.value || 0);
        renderReadyDumpsTab();
    });

    document.addEventListener("click", function (event) {
        if (!event.target.closest("#dump-load-button")) {
            return;
        }

        loadSelectedDump();
    });
    document.addEventListener("change", function (event) {
        if (event.target.id !== "vtx-ready-select") {
            return;
        }

        selectedIndex = Number(event.target.value || 0);
        renderVtxTablesTab();
    });

    document.addEventListener("change", function (event) {
        var control = event.target.closest(".vtx-rule-control");
        if (!control) {
            return;
        }

        var card = control.closest(".vtx-rule-card");
        var rule = vtxRules[Number(card && card.dataset.ruleIndex)];
        if (!rule) {
            return;
        }

        var field = control.dataset.field;
        if (field === "rangeStart" || field === "rangeEnd") {
            rule[field] = clampRangeValue(control.value, rule[field]);
            control.value = rule[field];
        } else {
            rule[field] = parseInt(control.value, 10) || 0;
        }

        if (field === "band") {
            rule.channel = 0;
            renderVtxTablesTab();
            return;
        }

        refreshCliPreview();
    });

    document.addEventListener("input", function (event) {
        var control = event.target.closest(".vtx-rule-control");
        if (!control || (control.dataset.field !== "rangeStart" && control.dataset.field !== "rangeEnd")) {
            return;
        }

        var card = control.closest(".vtx-rule-card");
        var rule = vtxRules[Number(card && card.dataset.ruleIndex)];
        if (!rule) {
            return;
        }

        rule[control.dataset.field] = control.value;
        refreshCliPreview();
    });

    document.addEventListener("click", function (event) {
        if (event.target.closest("#vtx-add-rule")) {
            vtxRules.push(createDefaultRule(vtxRules.length));
            renderVtxTablesTab();
            return;
        }

        var removeButton = event.target.closest("[data-remove-rule]");
        if (!removeButton) {
            return;
        }

        vtxRules.splice(Number(removeButton.dataset.removeRule), 1);
        renderVtxTablesTab();
    });

    document.addEventListener("click", function (event) {
        if (event.target.id !== "vtx-copy-table") {
            return;
        }

        var cli = document.getElementById("vtx-ready-cli");
        if (cli && navigator.clipboard) {
            navigator.clipboard.writeText(cli.textContent);
        }
    });
    document.addEventListener("DOMContentLoaded", function () {
        ensureTab();
        setInterval(ensureTab, 1000);
    });
}());


































