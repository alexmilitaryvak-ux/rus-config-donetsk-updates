﻿param(
    [Parameter(Mandatory = $true)][string]$AppRoot,
    [string]$PackagePath,
    [string]$PackageUrl,
    [Parameter(Mandatory = $true)][string]$ExePath,
    [int]$CallerProcessId = 0
)

$ErrorActionPreference = 'Stop'
$script:ProgressEnabled = $false
$script:ProgressForm = $null
$script:ProgressLabel = $null
$script:ProgressBar = $null

function Write-UpdateLog {
    param([string]$Text)
    $logPath = Join-Path $AppRoot 'update.log'
    $line = ('{0} {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Text)
    Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
}

function Initialize-ProgressWindow {
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
        Add-Type -AssemblyName System.Drawing -ErrorAction Stop
        [System.Windows.Forms.Application]::EnableVisualStyles()

        $form = New-Object System.Windows.Forms.Form
        $form.Text = 'RUS Config Donetsk - обновление'
        $form.Width = 540
        $form.Height = 190
        $form.StartPosition = 'CenterScreen'
        $form.FormBorderStyle = 'FixedDialog'
        $form.MaximizeBox = $false
        $form.MinimizeBox = $false
        $form.ControlBox = $false
        $form.TopMost = $true
        $form.BackColor = [System.Drawing.Color]::FromArgb(38, 43, 40)

        $title = New-Object System.Windows.Forms.Label
        $title.Text = 'Обновление программы'
        $title.ForeColor = [System.Drawing.Color]::White
        $title.Font = New-Object System.Drawing.Font('Segoe UI', 13, [System.Drawing.FontStyle]::Bold)
        $title.Location = New-Object System.Drawing.Point(20, 16)
        $title.Size = New-Object System.Drawing.Size(480, 28)

        $status = New-Object System.Windows.Forms.Label
        $status.Text = 'Подготовка обновления...'
        $status.ForeColor = [System.Drawing.Color]::FromArgb(255, 196, 18)
        $status.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
        $status.Location = New-Object System.Drawing.Point(20, 55)
        $status.Size = New-Object System.Drawing.Size(480, 42)

        $bar = New-Object System.Windows.Forms.ProgressBar
        $bar.Minimum = 0
        $bar.Maximum = 100
        $bar.Value = 4
        $bar.Style = 'Continuous'
        $bar.Location = New-Object System.Drawing.Point(20, 103)
        $bar.Size = New-Object System.Drawing.Size(480, 22)

        $hint = New-Object System.Windows.Forms.Label
        $hint.Text = 'Пожалуйста, дождись завершения. Программа откроется сама.'
        $hint.ForeColor = [System.Drawing.Color]::Gainsboro
        $hint.Font = New-Object System.Drawing.Font('Segoe UI', 8)
        $hint.Location = New-Object System.Drawing.Point(20, 132)
        $hint.Size = New-Object System.Drawing.Size(480, 20)

        $form.Controls.Add($title)
        $form.Controls.Add($status)
        $form.Controls.Add($bar)
        $form.Controls.Add($hint)
        $form.Show()
        [System.Windows.Forms.Application]::DoEvents()

        $script:ProgressEnabled = $true
        $script:ProgressForm = $form
        $script:ProgressLabel = $status
        $script:ProgressBar = $bar
    } catch {
        $script:ProgressEnabled = $false
        Write-UpdateLog ("Progress window unavailable: " + $_.Exception.Message)
    }
}

function Set-UpdateProgress {
    param(
        [int]$Value,
        [string]$Message
    )

    Write-UpdateLog $Message

    if (-not $script:ProgressEnabled) {
        return
    }

    try {
        if ($Value -lt 0) { $Value = 0 }
        if ($Value -gt 100) { $Value = 100 }
        $script:ProgressBar.Value = $Value
        $script:ProgressLabel.Text = $Message
        [System.Windows.Forms.Application]::DoEvents()
    } catch {
    }
}

function Close-ProgressWindow {
    if (-not $script:ProgressEnabled) {
        return
    }

    try {
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 900
        $script:ProgressForm.Close()
        $script:ProgressForm.Dispose()
    } catch {
    }
}

function Show-UpdateFailure {
    param([string]$Message)

    if ($script:ProgressEnabled) {
        try {
            $script:ProgressLabel.ForeColor = [System.Drawing.Color]::FromArgb(255, 84, 84)
            $script:ProgressLabel.Text = 'Обновление не выполнено.'
            $script:ProgressBar.Value = 100
            [System.Windows.Forms.Application]::DoEvents()
            [System.Windows.Forms.MessageBox]::Show(
                "Обновление не выполнено.`r`n`r`n$Message`r`n`r`nСейчас откроется update.log.",
                'RUS Config Donetsk',
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            ) | Out-Null
            $script:ProgressForm.Close()
            $script:ProgressForm.Dispose()
        } catch {
        }
    }
}

function Get-AppProcesses {
    param([string]$TargetExePath)

    $targetFullPath = $null
    try {
        $targetFullPath = [System.IO.Path]::GetFullPath($TargetExePath)
    } catch {
        $targetFullPath = $TargetExePath
    }

    $targetName = [System.IO.Path]::GetFileNameWithoutExtension($TargetExePath)

    Get-Process -ErrorAction SilentlyContinue | Where-Object {
        if ($_.Id -eq $PID) {
            return $false
        }

        $matched = $false
        try {
            if ($_.Path) {
                $processPath = [System.IO.Path]::GetFullPath($_.Path)
                if ($processPath -ieq $targetFullPath) {
                    $matched = $true
                }
            }
        } catch {
        }

        if (-not $matched -and $_.ProcessName -eq $targetName) {
            $matched = $true
        }

        return $matched
    }
}

function Wait-AppToClose {
    param(
        [int]$TimeoutSeconds,
        [switch]$Force
    )

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    while ((Get-Date) -lt $deadline) {
        $running = @(Get-AppProcesses -TargetExePath $ExePath)
        if ($running.Count -eq 0) {
            return $true
        }

        Start-Sleep -Milliseconds 500
        if ($script:ProgressEnabled) {
            [System.Windows.Forms.Application]::DoEvents()
        }
    }

    $left = @(Get-AppProcesses -TargetExePath $ExePath)
    if ($left.Count -eq 0) {
        return $true
    }

    if ($Force) {
        Set-UpdateProgress 18 'Закрываю зависший процесс приложения...'
        foreach ($process in $left) {
            try {
                Stop-Process -Id $process.Id -Force -ErrorAction Stop
            } catch {
                Write-UpdateLog ("Failed to stop process " + $process.Id + ": " + $_.Exception.Message)
            }
        }
        Start-Sleep -Seconds 2
    }

    return (@(Get-AppProcesses -TargetExePath $ExePath).Count -eq 0)
}

try {
    Write-UpdateLog "Update started. PackagePath: $PackagePath PackageUrl: $PackageUrl CallerProcessId: $CallerProcessId"

    if (-not (Test-Path -LiteralPath $AppRoot -PathType Container)) {
        throw "AppRoot not found: $AppRoot"
    }

    Initialize-ProgressWindow
    Set-UpdateProgress 5 'Подготовка обновления...'

    if ($CallerProcessId -gt 0) {
        Set-UpdateProgress 10 'Закрываю RUS Config Donetsk...'
        try {
            Wait-Process -Id $CallerProcessId -Timeout 35 -ErrorAction SilentlyContinue
        } catch {
            Write-UpdateLog ("Caller wait skipped: " + $_.Exception.Message)
        }
    }

    Set-UpdateProgress 15 'Проверяю, что программа закрыта...'
    if (-not (Wait-AppToClose -TimeoutSeconds 25)) {
        if (-not (Wait-AppToClose -TimeoutSeconds 5 -Force)) {
            throw "RUS Config Donetsk did not close. Close it and run update again."
        }
    }

    $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('rus-config-donetsk-update-' + [guid]::NewGuid().ToString('N'))
    $extractRoot = Join-Path $tempRoot 'package'
    New-Item -ItemType Directory -Force -Path $extractRoot | Out-Null

    if (-not [string]::IsNullOrWhiteSpace($PackageUrl)) {
        $downloadPath = Join-Path $tempRoot 'update-package.zip'
        Set-UpdateProgress 28 'Скачиваю пакет обновления...'
        $ProgressPreference = 'SilentlyContinue'
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $headers = @{}
        if (-not [string]::IsNullOrWhiteSpace($env:RCD_UPDATE_AUTH)) {
            $headers['Authorization'] = $env:RCD_UPDATE_AUTH
        }
        if ($PackageUrl -like 'https://api.github.com/repos/*/contents/*') {
            $headers['Accept'] = 'application/vnd.github.raw+json'
        }

        if ($headers.Count -gt 0) {
            Invoke-WebRequest -UseBasicParsing -Uri $PackageUrl -Headers $headers -OutFile $downloadPath
        } else {
            Invoke-WebRequest -UseBasicParsing -Uri $PackageUrl -OutFile $downloadPath
        }
        $PackagePath = $downloadPath
        Write-UpdateLog ("Package downloaded. Size: " + (Get-Item -LiteralPath $PackagePath).Length)
    }

    if ([string]::IsNullOrWhiteSpace($PackagePath) -or -not (Test-Path -LiteralPath $PackagePath -PathType Leaf)) {
        throw "Package not found: $PackagePath"
    }

    Add-Type -AssemblyName System.IO.Compression.FileSystem

    Set-UpdateProgress 45 'Проверяю пакет обновления...'
    $zip = [System.IO.Compression.ZipFile]::OpenRead($PackagePath)
    try {
        $extractRootFull = [System.IO.Path]::GetFullPath($extractRoot)
        foreach ($entry in $zip.Entries) {
            if ([string]::IsNullOrWhiteSpace($entry.FullName)) {
                continue
            }

            $target = [System.IO.Path]::GetFullPath((Join-Path $extractRoot $entry.FullName))
            if (-not $target.StartsWith($extractRootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
                throw "Unsafe path in update package: $($entry.FullName)"
            }
        }
    } finally {
        $zip.Dispose()
    }

    Set-UpdateProgress 58 'Распаковываю файлы...'
    [System.IO.Compression.ZipFile]::ExtractToDirectory($PackagePath, $extractRoot)

    Set-UpdateProgress 68 'Создаю резервную копию...'
    $backupRoot = Join-Path $AppRoot ('backup\before-update-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
    New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null

    $files = Get-ChildItem -LiteralPath $extractRoot -Recurse -File
    Write-UpdateLog ("Files in package: " + $files.Count)

    foreach ($file in $files) {
        $relative = $file.FullName.Substring($extractRoot.Length).TrimStart('\', '/')
        if ($relative -ieq 'update-source.json') {
            Write-UpdateLog 'Skipped update-source.json'
            continue
        }

        $destination = Join-Path $AppRoot $relative
        if (Test-Path -LiteralPath $destination -PathType Leaf) {
            $backupDestination = Join-Path $backupRoot $relative
            $backupParent = Split-Path -Parent $backupDestination
            if ($backupParent) {
                New-Item -ItemType Directory -Force -Path $backupParent | Out-Null
            }
            Copy-Item -LiteralPath $destination -Destination $backupDestination -Force
        }
    }

    Set-UpdateProgress 80 'Устанавливаю обновление...'
    foreach ($file in $files) {
        $relative = $file.FullName.Substring($extractRoot.Length).TrimStart('\', '/')
        if ($relative -ieq 'update-source.json') {
            continue
        }

        $destination = Join-Path $AppRoot $relative
        $destinationParent = Split-Path -Parent $destination
        if ($destinationParent) {
            New-Item -ItemType Directory -Force -Path $destinationParent | Out-Null
        }
        Copy-Item -LiteralPath $file.FullName -Destination $destination -Force
        Write-UpdateLog "Updated: $relative"
    }

    Remove-Item -LiteralPath $tempRoot -Recurse -Force
    Write-UpdateLog "Update finished. Backup: $backupRoot"

    Set-UpdateProgress 96 'Запускаю RUS Config Donetsk...'
    if (Test-Path -LiteralPath $ExePath -PathType Leaf) {
        Start-Process -FilePath $ExePath -WorkingDirectory $AppRoot
    }

    Set-UpdateProgress 100 'Готово. Программа запускается...'
    Close-ProgressWindow
} catch {
    $message = $_.Exception.Message
    Write-UpdateLog ("Update failed: " + $message)
    Show-UpdateFailure $message
    try {
        Start-Process -FilePath 'notepad.exe' -ArgumentList (Join-Path $AppRoot 'update.log')
    } catch {
    }
    throw
}
